# RapLab Pro 3.0 — Expert Rap System

RapLab Pro 3.0 est une application mobile hors ligne destinée à l’apprentissage avancé du rap : écriture, rimes, rythme, flow, freestyle, interprétation, studio, performance et construction de morceaux.

## Installation dans HTMLtoAPK

1. Décompresser `RapLab-Pro-3.0-EXPERT-HTMLtoAPK.zip`.
2. Importer **uniquement les fichiers contenus dans ce ZIP propre**.
3. Utiliser `index.html` comme page principale.
4. Activer JavaScript, DOM Storage, IndexedDB, l’accès aux fichiers, la lecture audio et les Blob URL.
5. Activer le microphone et la caméra.
6. Conserver le même package Android que la version précédente pour permettre la mise à jour.

Permissions Android recommandées :

```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.INTERNET" />
```

Le WebView doit transmettre les autorisations avec `WebChromeClient.onPermissionRequest` et prendre en charge `onShowFileChooser` pour importer plusieurs beats.

## Nouveautés de la version 3.0

### Expert Academy

- 12 modules de maîtrise et 48 validations pratiques
- Pocket et microtiming
- Cadences avancées
- Triolets et polymétrie
- Rimes multisyllabiques
- Densité et respiration
- Storytelling cinématographique
- Hooks professionnels
- Delivery et identité vocale
- Doublages et ad-libs
- Arrangement dynamique
- Présence scénique
- Création d’une démo professionnelle

### Flow Architect

- Grille rythmique de 16 pas
- Accents indépendants
- Swing réglable
- BPM réglable
- Lecture sonore du pattern
- Sauvegarde et réouverture des patterns
- Champ de syllabes pour transformer la grille en flow

### Ear Training

- Reconnaissance des croches droites
- Syncopes
- Triolets
- Flow aéré
- Double-time
- Exercices générés et statistiques

### Technique Lab

- Mesure des syllabes et de la densité
- Détection des lignes nécessitant une respiration
- Schéma de rimes
- Familles sonores liées
- Échos internes
- Génération de chaînes multisyllabiques

### Écriture experte

- Punchline Lab avec structures, contraste, images et diagnostic de chute
- Story Map en cinq étapes
- Ajout du plan narratif dans les projets
- Refrains, rimes, analyse, projets et historique déjà présents dans la 2.5

### Beat Vault — mémoire permanente

- Import simultané de plusieurs beats
- MP3, WAV, M4A, AAC, OGG, WebM et FLAC selon les codecs du téléphone
- Stockage des fichiers audio dans IndexedDB
- Fonctionnement hors connexion
- Nom, BPM, tonalité, style, humeur, tags et collection
- Favoris
- Recherche et filtres
- Reprise à la dernière position écoutée
- Compteur de lectures
- Vitesse d’entraînement de 65 à 125 %
- Boucles de 2, 4, 8 ou 16 mesures
- Analyse locale approximative du BPM
- Forme d’onde mémorisée
- Association d’un beat à un projet
- Export et partage du fichier original
- Estimation de l’espace utilisé
- Demande de stockage durable à Android lorsqu’elle est disponible

### Outils conservés de la 2.5

- Rap Academy 12 semaines
- Flow Scan
- Mixeur quatre pistes et export WAV
- Comparaison de prises
- Studio micro
- Enregistrement vidéo et téléprompteur
- Battle Trainer
- Freestyle dix niveaux
- Hook Lab
- Métronome, diction et souffle
- Projets, versions, carnet d’idées, statistiques, badges et sauvegardes

## Stockage des beats

Les beats sont enregistrés dans la base IndexedDB privée de l’application Android. Ils restent en mémoire après la fermeture et le redémarrage de l’application.

Ils peuvent toutefois être supprimés dans les situations suivantes :

- effacement manuel des données de l’application ;
- désinstallation de l’APK ;
- nettoyage forcé du stockage par Android lorsque l’espace devient critique et que le stockage durable n’a pas été accordé.

Le bouton **Verrouiller le stockage** demande à Android une conservation durable lorsqu’elle est prise en charge. Les fichiers audio ne sont pas intégrés à l’export JSON, afin d’éviter une sauvegarde énorme. Chaque beat peut être exporté séparément.

## Migration

La V3 réutilise la même base locale que les versions 2.0 et 2.5. Les projets, textes, statistiques, prises, beats et performances déjà présents sont conservés lorsque l’APK est installée comme une mise à jour avec le même package et la même signature.

## Mise à jour 3.1 — Tutoriel

Cette édition est construite à partir des ressources exactes de l’APK RapLab Pro 3.0 Expert fourni (`versionCode 206645417`). Elle ne repart pas de la V2.0 ni de la V2.5.

Le tutoriel apparaît au premier lancement. Il peut être relancé avec le bouton `?` ou depuis `Profil > Tutoriel`.
