# RapLab Pro

Application mobile hors ligne pour apprendre et pratiquer le rap.

## Installation dans HTMLtoAPK

1. Décompresser le ZIP.
2. Importer le dossier complet, avec `index.html` comme page de départ.
3. Autoriser JavaScript, le stockage local, IndexedDB et l’accès au microphone.
4. Dans le projet Android généré, vérifier que le manifeste contient :
   `<uses-permission android:name="android.permission.RECORD_AUDIO" />`
5. Le WebView doit accepter la demande de permission micro via `WebChromeClient.onPermissionRequest`.
6. Pour le partage des enregistrements, activer l’intent Android de partage des fichiers. Sans cela, l’application utilise le téléchargement classique en solution de secours.

## Fonctions

- Programme quotidien et XP
- Écriture et analyse de texte locale
- Métronome de 55 à 180 BPM
- Exercices de flow et placement
- Respiration 4-2-8
- Freestyle avec sujets et contraintes
- Enregistrement micro et bibliothèque locale
- Partage des prises
- Export/import de la progression
- Fonctionnement hors connexion

Les fichiers audio sont stockés dans IndexedDB sur l’appareil. Effacer les données de l’application supprime les prises.
