# RapLab Pro 2.0 — Rap Academy

## Installation dans HTMLtoAPK

1. Décompressez `RapLab-Pro-2.0-HTMLtoAPK.zip`.
2. Importez **tout le dossier**, pas seulement `index.html`.
3. Définissez `index.html` comme page d’entrée.
4. Activez JavaScript, DOM Storage, Local Storage, IndexedDB, accès aux fichiers et lecture audio.
5. Autorisez le microphone.

Permission Android indispensable :

```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
```

Le WebView doit également transmettre la demande de permission avec `WebChromeClient.onPermissionRequest`.

Pour l’import des instrumentales et le partage des prises, votre wrapper Android doit accepter :
- le sélecteur de fichiers HTML (`input type=file`) ;
- les URL Blob ;
- l’Intent Android de partage ;
- les téléchargements déclenchés par le WebView.

## Nouveautés 2.0

- Rap Academy complète sur 12 semaines et 48 leçons
- Coach local selon la compétence la plus faible
- Projets de morceaux avec statuts, structure, BPM, paroles, notes et versions
- Atelier d’écriture avec analyse, syllabes, régularité et carte colorée des rimes
- Dictionnaire de rimes et assonances hors ligne
- Carnet d’inspiration
- Freestyle progressif sur 10 niveaux
- Exercices de diction, flow, métronome et souffle
- Beat Lab avec import audio, BPM, Tap Tempo et boucles de 4/8/16 mesures
- Studio micro, bibliothèque de prises et partage
- Profil artistique, statistiques, badges et sauvegardes
- Migration automatique de la progression RapLab V1

## Stockage

La progression, les textes, les projets et les notes sont enregistrés dans Local Storage.
Les instrumentales et les enregistrements sont stockés dans IndexedDB.
Effacer les données de l’application Android supprimera ces contenus.

## Limites techniques

L’analyse du texte est locale et indicative.
La détection automatique exacte du BPM et le mixage multipiste final ne sont pas inclus dans cette version afin de préserver la compatibilité et les performances dans un WebView Android.
