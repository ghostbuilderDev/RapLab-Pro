# RapLab Pro 2.5 — Studio & Performance

Application mobile hors ligne pour apprendre le rap, écrire, s’entraîner, enregistrer et produire une maquette.

## Installation dans HTMLtoAPK

1. Décompressez le ZIP.
2. Importez **tout le dossier** dans HTMLtoAPK.
3. Utilisez `index.html` comme page d’entrée.
4. Activez JavaScript, DOM Storage, Local Storage, IndexedDB, accès aux fichiers, lecture audio et vidéo.
5. Autorisez le microphone et la caméra.

Permissions Android recommandées :

```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.CAMERA" />
```

Le WebView doit gérer :
- `WebChromeClient.onPermissionRequest` pour le micro et la caméra ;
- `WebChromeClient.onShowFileChooser` pour importer les instrumentales et sauvegardes ;
- le partage Android des fichiers ;
- les téléchargements Blob ;
- IndexedDB et DOM Storage.

## Nouveautés de la version 2.5

### Flow Scan
- enregistrement local du signal du microphone ;
- détection des attaques d’énergie ;
- mesure des écarts à une grille au tempo ;
- score de précision, régularité, continuité et dynamique ;
- timeline visuelle des attaques ;
- historique des analyses.

### Mixeur 4 pistes
- instrumentale ;
- voix principale ;
- doublage ;
- ad-libs ;
- réglage du volume et du décalage ;
- mute par piste ;
- presets voix Clean, Punch, Warm et Airy ;
- prévisualisation ;
- sauvegarde des configurations ;
- véritable export WAV par mixage hors ligne.

### Comparaison de prises
- durée ;
- énergie moyenne ;
- pourcentage de silence ;
- dynamique ;
- nombre d’attaques ;
- niveau de pic ;
- affichage des formes d’onde ;
- conseils comparatifs.

### Hook Lab
- créateur de refrains ;
- styles hymne, mélodique, sombre, minimal et appel-réponse ;
- versions 4 ou 8 mesures ;
- score de répétition, régularité et simplicité ;
- insertion directe dans un projet.

### Battle Trainer
- adversaire virtuel ;
- attaque et mot imposé ;
- chronomètre ;
- analyse de la réponse écrite ;
- score technique et conseils.

### Mode Performance
- caméra frontale ;
- mode miroir ;
- prompteur réglable ;
- indications scéniques ;
- enregistrement vidéo ;
- bibliothèque locale ;
- partage de la performance.

## Compatibilité avec la version 2.0

La progression, les projets, les textes, les beats et les prises de la version 2.0 sont conservés. La version 2.5 ajoute automatiquement les nouveaux champs au premier démarrage.

## Stockage local

- Local Storage : progression, projets, textes, analyses et configurations.
- IndexedDB : instrumentales, prises audio et performances vidéo.

Effacer les données Android de l’application efface aussi ces contenus.

## Limites techniques honnêtes

Le Flow Scan détecte les attaques d’énergie, pas les syllabes avec une reconnaissance linguistique complète. Son résultat dépend du micro, du bruit ambiant et de l’utilisation d’un casque.

Le mixeur exporte un WAV local. Les projets très longs ou les gros fichiers peuvent dépasser la mémoire disponible d’un téléphone. Une limite de dix minutes est appliquée au rendu.

L’analyse de prise est un indicateur acoustique. Elle ne remplace pas l’écoute artistique, le jugement de la diction ou celui de l’émotion.
