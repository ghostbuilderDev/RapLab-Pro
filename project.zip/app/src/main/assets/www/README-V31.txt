RAPLAB V31 HTMLtoAPK
Le bouton REC n'utilise plus getUserMedia. Sans pont Android natif, il ouvre l'enregistreur audio du téléphone et importe la prise.
