
"use strict";

/* =========================
   RapLab Pro 2.5 Extension
   ========================= */

const V25_VERSION = "2.5";
const V25_oldRenderHome = renderHome;
const V25_oldRenderAcademy = renderAcademy;
const V25_oldRenderCreate = renderCreate;
const V25_oldRenderStudio = renderStudio;
const V25_oldRenderProfile = renderProfile;
const V25_oldAfterRender = afterRender;
const V25_oldMergeState = mergeState;

function v25Ensure(s){
  s.version = 2.5;
  s.flowAnalyses ||= [];
  s.mixProjects ||= [];
  s.lastRefrain ||= null;
  s.performanceSettings ||= {speed:28,fontSize:25,mirror:true};
  s.stats ||= {};
  for(const k of ["flowScans","mixes","battles","performances"]){
    if(typeof s.stats[k] !== "number") s.stats[k]=0;
  }
  return s;
}
mergeState = function(x){ return v25Ensure(V25_oldMergeState(x)); };
v25Ensure(state);
save();

db = function(){
  return new Promise((resolve,reject)=>{
    const r=indexedDB.open("raplab_v2_db",3);
    r.onupgradeneeded=()=>{
      const d=r.result;
      if(!d.objectStoreNames.contains("recordings"))d.createObjectStore("recordings",{keyPath:"id",autoIncrement:true});
      if(!d.objectStoreNames.contains("beats"))d.createObjectStore("beats",{keyPath:"id",autoIncrement:true});
      if(!d.objectStoreNames.contains("performances"))d.createObjectStore("performances",{keyPath:"id",autoIncrement:true});
    };
    r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);
  });
};

const V25_BATTLE_LINES = [
  ["Tu parles de sommet, mais t’as peur de la première marche.","marche","Retourne l’image du sommet contre l’adversaire."],
  ["Ton flow suit le train, le mien construit les rails.","rails","Réponds avec une comparaison liée au mouvement."],
  ["Tu veux la lumière sans traverser la nuit.","nuit","Transforme la faiblesse supposée en force."],
  ["Tes mots font du bruit, mais ne laissent aucune trace.","trace","Termine par une chute très courte."],
  ["Tu copies les codes pendant que j’écris les règles.","règles","Utilise une opposition claire entre toi et lui."],
  ["Ton courage disparaît dès que le tempo accélère.","tempo","Change de débit sur la dernière mesure."],
  ["Tu rêves d’une couronne mais tu refuses le poids.","poids","Place le mot imposé sans le mettre en fin de ligne."],
  ["Ton reflet fait le show, ton histoire reste vide.","miroir","Réponds avec une image visuelle."]
];

const V25_REFRAIN_TEMPLATES = {
  "Hymne":[
    "{HOOK} — on avance encore",
    "Même quand {K2}, on garde le cap",
    "{HOOK} — plus fort que le décor",
    "On tombe, on revient, personne nous rattrape"
  ],
  "Mélodique":[
    "{HOOK}, j’entends ton écho",
    "Entre {K2} et la nuit, je cherche les mots",
    "{HOOK}, même quand tout s’efface",
    "Je garde un peu de lumière au fond de l’espace"
  ],
  "Sombre":[
    "{HOOK} dans le noir",
    "{K2} sur les murs, silence dans le regard",
    "{HOOK}, personne ne vient",
    "Alors je marche seul jusqu’au prochain matin"
  ],
  "Minimal":[
    "{HOOK}",
    "Encore {HOOK}",
    "{K2} dans la tête",
    "{HOOK}, rien ne m’arrête"
  ],
  "Appel-réponse":[
    "Qui veut {HOOK} ? — Nous",
    "Qui traverse {K2} ? — Nous",
    "Même quand la route plie — Debout",
    "{HOOK} — jusqu’au bout"
  ]
};

let V25_flowSession=null;
let V25_flowRAF=0;
let V25_flowCountdownTimer=0;
let V25_compareCache=null;
let V25_previewAudios=[];
let V25_performanceStream=null;
let V25_performanceRecorder=null;
let V25_performanceChunks=[];
let V25_performanceBlob=null;
let V25_teleRAF=0;
let V25_teleStart=0;
let V25_perfTimer=0;
let V25_perfStart=0;
let V25_battleTimer=0;
let V25_battleSeconds=30;
let V25_currentBattle=null;


const V25_oldGo = go;
go = function(r){
  if(route==="studio"&&sub.studio==="flowcheck"&&V25_flowSession)v25StopFlowScan(true);
  if(route==="studio"&&sub.studio==="performance"&&r!=="studio"){
    cancelAnimationFrame(V25_teleRAF);V25_teleRAF=0;clearInterval(V25_perfTimer);
    if(V25_performanceStream){V25_performanceStream.getTracks().forEach(x=>x.stop());V25_performanceStream=null;}
  }
  v25StopPreview();
  V25_oldGo(r);
};

renderHome = function(){
  return V25_oldRenderHome()+`
  <div class="section-head"><h2>Studio 2.5</h2><span>Nouveaux outils professionnels</span></div>
  <div class="grid">
    <div class="card project-card" onclick="route='studio';sub.studio='flowcheck';renderRoute()"><span class="pill purple">Nouveau</span><h3 style="margin-top:9px">Flow Scan</h3><p>Mesure les attaques, la continuité, la dynamique et les écarts au tempo.</p></div>
    <div class="card project-card" onclick="route='studio';sub.studio='mixer';renderRoute()"><span class="pill purple">Nouveau</span><h3 style="margin-top:9px">Mixeur 4 pistes</h3><p>Beat, voix principale, doublage, ad-libs et export WAV local.</p></div>
    <div class="card project-card" onclick="route='create';sub.create='refrain';renderRoute()"><h3>Créateur de refrain</h3><p>Génère, teste et enregistre une accroche mémorisable.</p></div>
    <div class="card project-card" onclick="route='academy';sub.academy='battle';renderRoute()"><h3>Battle Trainer</h3><p>Réponds à un adversaire virtuel avec chrono et score technique.</p></div>
  </div>`;
};

renderAcademy = function(){
  const t=tabs("academy",[["program","Programme"],["flow","Flow"],["diction","Diction"],["souffle","Souffle"],["freestyle","Freestyle"],["battle","Battle"]]);
  let body="";
  if(sub.academy==="program")body=renderProgram();
  else if(sub.academy==="flow")body=renderFlowLab();
  else if(sub.academy==="diction")body=renderDiction();
  else if(sub.academy==="souffle")body=renderBreath();
  else if(sub.academy==="freestyle")body=renderFreestyle();
  else body=v25RenderBattle();
  return `<div class="section-head"><h2>Rap Academy 2.5</h2><span>Formation, battle et performance</span></div>${t}${body}`;
};

renderCreate = function(){
  const t=tabs("create",[["projects","Projets"],["write","Écriture"],["rhymes","Rimes"],["refrain","Refrain"],["notes","Carnet"]]);
  let body="";
  if(sub.create==="projects")body=renderProjects();
  else if(sub.create==="editor")body=renderProjectEditor();
  else if(sub.create==="write")body=renderWriting();
  else if(sub.create==="rhymes")body=renderRhymes();
  else if(sub.create==="refrain")body=v25RenderRefrain();
  else body=renderNotes();
  return `<div class="section-head"><h2>Créer</h2><span>Écriture, refrains et projets</span></div>${t}${body}`;
};

renderStudio = function(){
  const t=tabs("studio",[["beats","Beat Lab"],["record","Enregistrer"],["flowcheck","Flow Scan"],["mixer","Mixeur"],["compare","Comparer"],["performance","Performance"],["takes","Prises"]]);
  let body="";
  if(sub.studio==="beats")body=renderBeatLab();
  else if(sub.studio==="record")body=renderRecorder();
  else if(sub.studio==="flowcheck")body=v25RenderFlowScan();
  else if(sub.studio==="mixer")body=v25RenderMixer();
  else if(sub.studio==="compare")body=v25RenderCompare();
  else if(sub.studio==="performance")body=v25RenderPerformance();
  else body=renderTakesOnly();
  return `<div class="section-head"><h2>Studio mobile 2.5</h2><span>Analyse, mixage et vidéo</span></div>${t}${body}`;
};

renderProfile = function(){
  return V25_oldRenderProfile()+`
  <div class="section-head"><h3>Activité 2.5</h3><span>Outils avancés</span></div>
  <div class="grid3">
    <div class="card"><span class="metric-label">Flow Scans</span><div class="metric">${state.stats.flowScans}</div></div>
    <div class="card"><span class="metric-label">Mixages</span><div class="metric">${state.stats.mixes}</div></div>
    <div class="card"><span class="metric-label">Battles</span><div class="metric">${state.stats.battles}</div></div>
    <div class="card"><span class="metric-label">Performances</span><div class="metric">${state.stats.performances}</div></div>
  </div>`;
};

afterRender = function(){
  V25_oldAfterRender();
  if(route==="studio"&&sub.studio==="mixer")setTimeout(v25LoadMixerOptions,10);
  if(route==="studio"&&sub.studio==="compare")setTimeout(v25LoadCompareOptions,10);
  if(route==="studio"&&sub.studio==="flowcheck"&&state.flowAnalyses.length)setTimeout(()=>v25DrawFlowResult(state.flowAnalyses[0]),20);
  if(route==="studio"&&sub.studio==="performance")setTimeout(v25LoadPerformanceLibrary,20);
  if(route==="create"&&sub.create==="refrain"&&state.lastRefrain)setTimeout(v25RenderLastRefrain,10);
};

/* ---------- Refrain Creator ---------- */
function v25RenderRefrain(){
  const projects=state.projects.map(p=>`<option value="${p.id}">${esc(p.title)}</option>`).join("");
  return `<div class="hero"><span class="eyebrow">Hook Lab</span><h1>Construis un refrain mémorisable.</h1><p>Une phrase centrale, peu de mots et une variation claire valent souvent mieux qu’un texte trop chargé.</p></div>
  <div class="section-head"><h3>Générateur guidé</h3><span>Analyse locale</span></div>
  <div class="card">
    <div class="field"><label>Phrase centrale ou idée principale</label><input id="hookMain" placeholder="Ex. Rien ne m’arrête"></div>
    <div class="two-fields"><div class="field"><label>Mot secondaire</label><input id="hookKeyword" placeholder="Ex. tempête"></div>
    <div class="field"><label>Style</label><select id="hookStyle">${Object.keys(V25_REFRAIN_TEMPLATES).map(x=>`<option>${x}</option>`).join("")}</select></div></div>
    <div class="two-fields"><div class="field"><label>Longueur</label><select id="hookLength"><option value="4">4 mesures</option><option value="8">8 mesures</option></select></div>
    <div class="field"><label>Projet cible</label><select id="hookProject"><option value="">Aucun projet</option>${projects}</select></div></div>
    <div class="row"><button class="btn primary" onclick="v25GenerateRefrain()">Générer</button><button class="btn" onclick="v25HookPrompt()">Trouver une idée</button></div>
  </div>
  <div id="hookResult"></div>`;
}
function v25HookPrompt(){
  const ideas=["On revient toujours","Je garde la lumière","Plus rien à perdre","Jusqu’au dernier train","On avance encore","Le silence nous connaît"];
  $("#hookMain").value=ideas[Math.floor(Math.random()*ideas.length)];
  $("#hookKeyword").value=["orage","distance","nuit","mémoire","béton","avenir"][Math.floor(Math.random()*6)];
}
function v25GenerateRefrain(){
  let hook=$("#hookMain").value.trim(),k2=$("#hookKeyword").value.trim()||"la nuit",style=$("#hookStyle").value,len=+$("#hookLength").value;
  if(!hook)hook="On avance encore";
  const base=V25_REFRAIN_TEMPLATES[style].map(x=>x.replaceAll("{HOOK}",hook).replaceAll("{K2}",k2));
  let lines=[...base];if(len===8)lines=lines.concat(base.map((x,i)=>i%2===0?x:x.replace(k2,hook.toLowerCase())));
  const words=lines.flatMap(x=>(x.match(/[A-Za-zÀ-ÿœŒ'-]+/g)||[]).map(norm)).filter(Boolean),unique=new Set(words).size;
  const repetition=Math.round((1-unique/Math.max(1,words.length))*100);
  const avg=lines.reduce((a,x)=>a+x.split(/\s+/).length,0)/lines.length;
  const lengths=lines.map(x=>x.split(/\s+/).length),mean=avg,sd=Math.sqrt(lengths.reduce((a,x)=>a+(x-mean)**2,0)/lengths.length);
  const regularity=Math.max(0,Math.round(100-sd*18));
  const simplicity=Math.max(0,Math.min(100,Math.round(115-avg*8)));
  const score=Math.round(repetition*.34+regularity*.33+simplicity*.33);
  state.lastRefrain={text:lines.join("\n"),style,hook,k2,score,repetition,regularity,simplicity,date:Date.now(),projectId:$("#hookProject").value||null};
  save();v25RenderLastRefrain();addXp(8,"ecriture");
}
function v25RenderLastRefrain(){
  const r=state.lastRefrain,z=$("#hookResult");if(!z||!r)return;
  z.innerHTML=`<div class="section-head"><h3>Proposition</h3><span>Score de mémorisation ${r.score}/100</span></div>
  <div class="card"><div class="refrain-output">${esc(r.text)}</div>
  <div class="memorability" style="margin-top:12px"><div><b>${r.score}</b><small>Score global</small></div><div><b>${r.repetition}%</b><small>Répétition</small></div><div><b>${r.regularity}%</b><small>Régularité</small></div><div><b>${r.simplicity}%</b><small>Simplicité</small></div></div>
  <div class="row" style="margin-top:13px"><button class="btn primary" onclick="v25InsertHook()">Ajouter au projet</button><button class="btn" onclick="copyText(state.lastRefrain.text)">Copier</button><button class="btn" onclick="v25GenerateRefrain()">Variante</button></div></div>`;
}
function v25InsertHook(){
  const r=state.lastRefrain;if(!r)return;
  let id=r.projectId||$("#hookProject")?.value;if(!id){toast("Choisis un projet cible");return}
  const p=state.projects.find(x=>x.id===id);if(!p)return;
  p.lyrics=(p.lyrics?`${p.lyrics}\n\n`:"")+`[REFRAIN]\n${r.text}`;p.updated=Date.now();p.status=p.status==="Idée"?"Écriture":p.status;save();toast("Refrain ajouté au projet");
}

/* ---------- Battle Trainer ---------- */
function v25NewBattle(){
  const b=V25_BATTLE_LINES[Math.floor(Math.random()*V25_BATTLE_LINES.length)];
  V25_currentBattle={line:b[0],word:b[1],tip:b[2],date:Date.now()};V25_battleSeconds=30;
}
function v25RenderBattle(){
  if(!V25_currentBattle)v25NewBattle();
  return `<div class="battle-stage"><div class="battle-avatar">🤖</div><span class="pill purple">Adversaire virtuel</span>
  <div class="battle-line" style="margin-top:13px">« ${esc(V25_currentBattle.line)} »</div>
  <p class="muted" style="margin-top:12px">Mot imposé</p><div class="battle-word">${esc(V25_currentBattle.word)}</div>
  <div id="battleTimer" class="timer">${formatTime(V25_battleSeconds)}</div>
  <div class="row" style="justify-content:center"><button class="btn" onclick="v25NewBattle();renderRoute()">Nouvelle attaque</button><button id="battleBtn" class="btn primary" onclick="v25ToggleBattle()">▶ Répondre</button></div></div>
  <div class="section-head"><h3>Ta réponse</h3><span>4 à 8 mesures</span></div>
  <div class="card"><textarea id="battleText" placeholder="Écris ou retranscris ta réponse ici..."></textarea>
  <div class="row" style="margin-top:11px"><button class="btn purple" onclick="v25ScoreBattle()">Analyser la réponse</button><button class="btn" onclick="toast('${escAttr(V25_currentBattle.tip)}')">Conseil</button></div></div>
  <div id="battleResult"></div>`;
}
function v25ToggleBattle(){
  if(V25_battleTimer){clearInterval(V25_battleTimer);V25_battleTimer=0;$("#battleBtn").textContent="▶ Reprendre";return}
  if(V25_battleSeconds<=0)V25_battleSeconds=30;$("#battleBtn").textContent="Ⅱ Pause";
  V25_battleTimer=setInterval(()=>{V25_battleSeconds--;$("#battleTimer").textContent=formatTime(V25_battleSeconds);if(V25_battleSeconds<=0){clearInterval(V25_battleTimer);V25_battleTimer=0;$("#battleBtn").textContent="Temps écoulé";toast("Place ta dernière punchline")}},1000);
}
function v25ScoreBattle(){
  const text=$("#battleText").value.trim();if(!text)return toast("Écris ta réponse");
  const lines=text.split("\n").map(x=>x.trim()).filter(Boolean),hasWord=norm(text).includes(norm(V25_currentBattle.word));
  const ends=lines.map(ending),ec={};ends.forEach(x=>ec[x]=(ec[x]||0)+1);const rh=Math.round(ends.filter(x=>ec[x]>=2).length/Math.max(1,lines.length)*100);
  const constraint=hasWord?100:0,structure=Math.min(100,lines.length*20);
  const tokens=(text.match(/[A-Za-zÀ-ÿœŒ'-]+/g)||[]).map(norm),density=Math.min(100,Math.round(tokens.filter(x=>x.length>3&&!STOP.has(x)).length/Math.max(1,lines.length)*12));
  const replyWords=["tu","toi","ton","tes","mais","pendant","alors","quand"];const comeback=Math.min(100,replyWords.filter(x=>tokens.includes(x)).length*24);
  const score=Math.round(constraint*.25+structure*.20+rh*.25+density*.15+comeback*.15);
  state.stats.battles++;state.stats.sessions++;state.stats.minutes+=2;addXp(12,"freestyle");save();
  $("#battleResult").innerHTML=`<div class="section-head"><h3>Score d’entraînement</h3><span>Indicateur technique</span></div><div class="card"><div class="score-big">${score}</div>
  <div class="analysis-grid"><div class="analysis-cell"><b>${constraint}%</b><small>Mot imposé</small></div><div class="analysis-cell"><b>${structure}%</b><small>Structure</small></div><div class="analysis-cell"><b>${rh}%</b><small>Rimes</small></div><div class="analysis-cell"><b>${density}%</b><small>Densité</small></div><div class="analysis-cell"><b>${comeback}%</b><small>Réponse directe</small></div></div>
  <div class="advice">${score>=75?"Réponse solide. Travaille maintenant l’interprétation et la chute finale.":hasWord?"La contrainte est respectée. Renforce la structure et les rimes liées.":"Le mot imposé manque : entraîne-toi à l’intégrer sans casser la phrase."}</div></div>`;
}

/* ---------- Flow Scan ---------- */
function v25RenderFlowScan(){
  const last=state.flowAnalyses[0];
  return `<div class="v25-banner"><b>Analyse indicative, entièrement locale</b><span class="small muted">Le téléphone mesure les attaques d’énergie de la voix et leur proximité avec une grille rythmique. Un casque améliore nettement le résultat.</span></div>
  <div class="section-head"><h3>Réglages</h3><span>${state.stats.flowScans} analyse(s)</span></div>
  <div class="card">
    <div class="two-fields"><div class="field"><label>BPM</label><input id="scanBpm" type="number" min="55" max="180" value="${state.settings.metronomeBpm||90}"></div>
    <div class="field"><label>Grille analysée</label><select id="scanSubdivision"><option value="1">Temps</option><option value="2" selected>Croches</option><option value="4">Double-croches</option></select></div></div>
    <div class="two-fields"><div class="field"><label>Durée</label><select id="scanDuration"><option value="20">20 secondes</option><option value="30" selected>30 secondes</option><option value="60">60 secondes</option></select></div>
    <div class="field"><label>Sensibilité micro</label><input id="scanThreshold" type="range" min="0.015" max="0.12" step="0.005" value="0.045"></div></div>
    <div class="scan-live"><div id="scanPulse" class="scan-pulse"><div style="text-align:center"><b id="scanStatus">Prêt</b><br><span id="scanClock" class="muted">4 temps de départ</span></div></div></div>
    <div class="row" style="justify-content:center;margin-top:12px"><button id="scanBtn" class="btn primary" onclick="v25StartFlowScan()">Démarrer le Flow Scan</button><button class="btn" onclick="v25StopFlowScan(true)">Arrêter</button></div>
  </div>
  <div id="flowResult">${last?v25FlowResultHtml(last):""}</div>`;
}
function v25Click(freq=850){
  try{const c=audioCtx||new (window.AudioContext||window.webkitAudioContext)(),o=c.createOscillator(),g=c.createGain();o.frequency.value=freq;g.gain.setValueAtTime(.16,c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+.06);o.connect(g).connect(c.destination);o.start();o.stop(c.currentTime+.065)}catch(e){}
}
async function v25StartFlowScan(){
  if(V25_flowSession)return toast("Analyse déjà en cours");
  try{
    const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false}});
    const ctx=new (window.AudioContext||window.webkitAudioContext)();await ctx.resume();
    const source=ctx.createMediaStreamSource(stream),an=ctx.createAnalyser();an.fftSize=1024;an.smoothingTimeConstant=.15;source.connect(an);
    const bpm=Math.max(55,Math.min(180,+$("#scanBpm").value||90)),sub=+$("#scanSubdivision").value,duration=+$("#scanDuration").value,threshold=+$("#scanThreshold").value;
    V25_flowSession={stream,ctx,an,bpm,sub,duration,threshold,onsets:[],energies:[],lastOnset:-1,active:false,start:0,prev:0,frames:0,silent:0};
    $("#scanBtn").disabled=true;let count=4;$("#scanStatus").textContent=count;$("#scanClock").textContent="Compte à rebours";v25Click(1050);
    V25_flowCountdownTimer=setInterval(()=>{count--;if(count>0){$("#scanStatus").textContent=count;v25Click(count===1?1100:850)}else{clearInterval(V25_flowCountdownTimer);V25_flowCountdownTimer=0;v25BeginFlowCapture()}},60000/bpm);
  }catch(e){V25_flowSession=null;toast("Micro inaccessible. Vérifie la permission audio.")}
}
function v25BeginFlowCapture(){
  const s=V25_flowSession;if(!s)return;s.active=true;s.start=performance.now();$("#scanStatus").textContent="RAP";$("#scanClock").textContent="00:00";
  const data=new Float32Array(s.an.fftSize);
  const loop=()=>{
    if(!V25_flowSession||!s.active)return;
    s.an.getFloatTimeDomainData(data);let sum=0;for(let i=0;i<data.length;i++)sum+=data[i]*data[i];const rms=Math.sqrt(sum/data.length),t=(performance.now()-s.start)/1000;
    s.energies.push(rms);s.frames++;if(rms<s.threshold*.52)s.silent++;
    const pulse=$("#scanPulse");if(pulse)pulse.classList.toggle("hot",rms>s.threshold);
    if(rms>s.threshold&&s.prev<s.threshold*.72&&(t-s.lastOnset)>.095){s.onsets.push({t,e:rms});s.lastOnset=t}
    s.prev=rms;if($("#scanClock"))$("#scanClock").textContent=formatTime(Math.floor(t));
    if(t>=s.duration)v25StopFlowScan(false);else V25_flowRAF=requestAnimationFrame(loop);
  };loop();
}
function v25StopFlowScan(cancel=false){
  clearInterval(V25_flowCountdownTimer);V25_flowCountdownTimer=0;cancelAnimationFrame(V25_flowRAF);
  const s=V25_flowSession;if(!s)return;
  s.active=false;s.stream.getTracks().forEach(t=>t.stop());s.ctx.close().catch(()=>{});
  V25_flowSession=null;if($("#scanBtn"))$("#scanBtn").disabled=false;if($("#scanPulse"))$("#scanPulse").classList.remove("hot");
  if(cancel||s.onsets.length<2){if($("#scanStatus"))$("#scanStatus").textContent="Prêt";toast(cancel?"Analyse arrêtée":"Pas assez d’attaques détectées");return}
  const step=(60/s.bpm)/s.sub,errors=s.onsets.map(o=>Math.abs(o.t-Math.round(o.t/step)*step));
  const avgError=errors.reduce((a,b)=>a+b,0)/errors.length,precision=Math.max(0,Math.round(100-avgError/(step/2)*100));
  const intervals=s.onsets.slice(1).map((o,i)=>o.t-s.onsets[i].t),im=intervals.reduce((a,b)=>a+b,0)/Math.max(1,intervals.length),isd=Math.sqrt(intervals.reduce((a,x)=>a+(x-im)**2,0)/Math.max(1,intervals.length));
  const regularity=Math.max(0,Math.round(100-Math.min(1,isd/Math.max(.08,im))*100));
  const silence=Math.round(s.silent/Math.max(1,s.frames)*100),continuity=Math.max(0,100-Math.max(0,silence-28)*2);
  const em=s.energies.reduce((a,b)=>a+b,0)/s.energies.length,esd=Math.sqrt(s.energies.reduce((a,x)=>a+(x-em)**2,0)/s.energies.length),dynamics=Math.min(100,Math.round(esd/Math.max(.001,em)*115));
  const score=Math.round(precision*.45+regularity*.25+continuity*.20+dynamics*.10),density=+(s.onsets.length/(s.duration*s.bpm/60)).toFixed(2);
  const result={id:uid(),date:Date.now(),bpm:s.bpm,sub:s.sub,duration:s.duration,onsets:s.onsets,precision,regularity,continuity,dynamics,silence,density,avgError:Math.round(avgError*1000),score};
  state.flowAnalyses.unshift(result);state.flowAnalyses=state.flowAnalyses.slice(0,20);state.stats.flowScans++;state.stats.sessions++;state.stats.minutes+=Math.max(1,Math.round(s.duration/60));state.skills.flow=Math.min(100,state.skills.flow+2);save();
  $("#flowResult").innerHTML=v25FlowResultHtml(result);v25DrawFlowResult(result);$("#scanStatus").textContent="Terminé";$("#scanClock").textContent=`Score ${score}/100`;addXp(15,"flow");
}
function v25FlowResultHtml(r){
  return `<div class="section-head"><h3>Résultat du Flow Scan</h3><span>${r.bpm} BPM · erreur moyenne ${r.avgError} ms</span></div>
  <div class="card"><div class="score-big">${r.score}</div>
  <div class="analysis-grid"><div class="analysis-cell"><b>${r.precision}%</b><small>Précision grille</small></div><div class="analysis-cell"><b>${r.regularity}%</b><small>Régularité</small></div><div class="analysis-cell"><b>${r.continuity}%</b><small>Continuité</small></div><div class="analysis-cell"><b>${r.dynamics}%</b><small>Dynamique</small></div><div class="analysis-cell"><b>${r.density}</b><small>Attaques / temps</small></div><div class="analysis-cell"><b>${r.silence}%</b><small>Silence détecté</small></div></div>
  <div id="flowTimeline" class="flow-timeline" style="margin-top:13px"></div><div class="flow-legend"><span><i style="background:var(--purple)"></i>Temps forts</span><span><i style="background:var(--pink)"></i>Attaques de voix</span></div>
  <div class="advice">${v25FlowAdvice(r)}</div></div>`;
}
function v25FlowAdvice(r){
  const a=[];if(r.precision<65)a.push("Travaille plus lentement et vise d’abord les temps forts.");if(r.regularity<60)a.push("Répète un pattern court avant de varier le débit.");if(r.silence>48)a.push("Les pauses sont nombreuses : garde des mots de liaison pour ne pas perdre le flux.");if(r.dynamics<25)a.push("Accentue davantage certains mots importants.");if(!a.length)a.push("Placement solide. Essaie maintenant le même texte avec des départs en contretemps.");return a.join(" ");
}
function v25DrawFlowResult(r){
  const z=$("#flowTimeline");if(!z)return;const beat=60/r.bpm,total=Math.min(r.duration,beat*16),divs=Math.ceil(total/(beat/r.sub));
  z.innerHTML=Array.from({length:divs+1},(_,i)=>`<i class="flow-gridline ${i%(r.sub*4)===0?"strong":""}" style="left:${i/divs*100}%"></i>`).join("")+
  r.onsets.filter(o=>o.t<=total).map(o=>`<i class="flow-onset" style="left:${o.t/total*100}%;height:${Math.max(12,Math.min(120,o.e*850))}px"></i>`).join("");
}

/* ---------- Take Comparison ---------- */
function v25RenderCompare(){
  return `<div class="card"><div class="two-fields"><div class="field"><label>Prise A</label><select id="takeA"><option>Chargement...</option></select></div><div class="field"><label>Prise B</label><select id="takeB"><option>Chargement...</option></select></div></div>
  <button class="btn primary" onclick="v25CompareTakes()">Analyser et comparer</button></div><div id="compareResult"></div>`;
}
async function v25LoadCompareOptions(){
  const all=(await dbAll("recordings")).sort((a,b)=>b.date-a.date),opts=all.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join("");
  if($("#takeA"))$("#takeA").innerHTML=`<option value="">Choisir</option>${opts}`;
  if($("#takeB"))$("#takeB").innerHTML=`<option value="">Choisir</option>${opts}`;
}
async function v25DecodeBlob(blob){
  const c=new (window.AudioContext||window.webkitAudioContext)(),ab=await blob.arrayBuffer(),buf=await c.decodeAudioData(ab.slice(0));await c.close();return buf;
}
function v25AudioMetrics(buf){
  const ch=buf.getChannelData(0),step=Math.max(256,Math.floor(buf.sampleRate*.02)),rms=[],wave=[];
  let max=0,attacks=0,prev=0;
  for(let i=0;i<ch.length;i+=step){let sum=0,p=0;const end=Math.min(ch.length,i+step);for(let j=i;j<end;j++){sum+=ch[j]*ch[j];p=Math.max(p,Math.abs(ch[j]))}const v=Math.sqrt(sum/(end-i));rms.push(v);max=Math.max(max,p);if(v>.045&&prev<.027)attacks++;prev=v;if(wave.length<90||i%(step*Math.ceil(ch.length/step/90))===0)wave.push(v)}
  const avg=rms.reduce((a,b)=>a+b,0)/rms.length,sorted=[...rms].sort((a,b)=>a-b),p20=sorted[Math.floor(sorted.length*.2)]||0,p90=sorted[Math.floor(sorted.length*.9)]||0;
  const silence=Math.round(rms.filter(x=>x<.018).length/rms.length*100),dynamic=Math.round(Math.min(100,(p90-p20)*650)),energy=Math.round(Math.min(100,avg*650));
  return {duration:buf.duration,energy,peak:Math.round(max*100),silence,attacks,dynamic,wave};
}
async function v25CompareTakes(){
  const a=+$("#takeA").value,b=+$("#takeB").value;if(!a||!b||a===b)return toast("Choisis deux prises différentes");
  $("#compareResult").innerHTML='<div class="card empty" style="margin-top:12px">Analyse audio en cours…</div>';
  try{
    const all=await dbAll("recordings"),A=all.find(x=>x.id===a),B=all.find(x=>x.id===b),[ba,bb]=await Promise.all([v25DecodeBlob(A.blob),v25DecodeBlob(B.blob)]),ma=v25AudioMetrics(ba),mb=v25AudioMetrics(bb);
    V25_compareCache={A:{...A,m:ma},B:{...B,m:mb}};
    const continuityA=100-ma.silence,continuityB=100-mb.silence,scoreA=continuityA*.35+ma.dynamic*.25+ma.energy*.20+Math.min(100,ma.attacks*2)*.20,scoreB=continuityB*.35+mb.dynamic*.25+mb.energy*.20+Math.min(100,mb.attacks*2)*.20;
    const win=scoreA===scoreB?"":scoreA>scoreB?"A":"B";
    $("#compareResult").innerHTML=`<div class="section-head"><h3>Comparaison</h3><span>Mesures acoustiques, pas jugement artistique</span></div>
    <div class="compare-layout"><div class="take-panel ${win==="A"?"compare-win":""}"><span class="pill">Prise A</span><h3>${esc(A.name)}</h3><canvas id="waveA" class="mini-wave" width="500" height="100"></canvas></div>
    <div class="take-panel ${win==="B"?"compare-win":""}"><span class="pill">Prise B</span><h3>${esc(B.name)}</h3><canvas id="waveB" class="mini-wave" width="500" height="100"></canvas></div></div>
    <div class="compare-table" style="margin-top:11px"><div class="head">Mesure</div><div class="head">A</div><div class="head">B</div>
    ${[["Durée",formatClock(ma.duration),formatClock(mb.duration)],["Énergie",ma.energy+"%",mb.energy+"%"],["Silence",ma.silence+"%",mb.silence+"%"],["Dynamique",ma.dynamic+"%",mb.dynamic+"%"],["Attaques",ma.attacks,mb.attacks],["Pic",ma.peak+"%",mb.peak+"%"]].map(x=>x.map(y=>`<div>${y}</div>`).join("")).join("")}</div>
    <div class="advice">${v25CompareAdvice(ma,mb,A.name,B.name)}</div>`;
    setTimeout(()=>{v25DrawWave($("#waveA"),ma.wave);v25DrawWave($("#waveB"),mb.wave)},20);
  }catch(e){$("#compareResult").innerHTML='<div class="card advice">Impossible de décoder l’une des prises sur cet appareil.</div>'}
}
function v25CompareAdvice(a,b,an,bn){
  const parts=[];if(Math.abs(a.silence-b.silence)>8)parts.push(`${a.silence<b.silence?an:bn} est plus continue.`);if(Math.abs(a.dynamic-b.dynamic)>10)parts.push(`${a.dynamic>b.dynamic?an:bn} présente davantage de variations d’énergie.`);if(Math.abs(a.energy-b.energy)>12)parts.push(`${a.energy>b.energy?an:bn} est globalement plus puissante.`);if(!parts.length)parts.push("Les deux prises sont proches : choisis selon la diction, l’émotion et le placement.");return parts.join(" ");
}
function v25DrawWave(c,data){if(!c)return;const x=c.getContext("2d"),w=c.width,h=c.height;x.clearRect(0,0,w,h);const g=x.createLinearGradient(0,0,w,0);g.addColorStop(0,"#ff3b6b");g.addColorStop(1,"#8f5cff");x.fillStyle=g;const bw=w/data.length;data.forEach((v,i)=>{const bh=Math.max(2,v*h*7);x.fillRect(i*bw,(h-bh)/2,Math.max(1,bw-1),bh)})}

/* ---------- Four-track Mixer ---------- */
function v25RenderMixer(){
  return `<div class="v25-banner"><b>Mixeur local 4 pistes</b><span class="small muted">Prévisualise puis exporte un fichier WAV. Le rendu peut demander beaucoup de mémoire pour les morceaux longs.</span></div>
  <div class="section-head"><h3>Projet de mix</h3><span>${state.mixProjects.length} configuration(s)</span></div>
  <div class="card"><div class="two-fields"><div class="field"><label>Nom du mix</label><input id="mixName" value="Maquette ${new Date().toLocaleDateString("fr-FR")}"></div><div class="field"><label>Configuration sauvegardée</label><select id="mixSaved" onchange="v25LoadMixProject(this.value)"><option value="">Nouvelle configuration</option>${state.mixProjects.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join("")}</select></div></div></div>
  <div class="section-head"><h3>Pistes</h3><span>Volume, décalage et traitement</span></div>
  <div id="mixTracks" class="studio-grid">
    ${v25TrackHtml(0,"Instrumentale","beat",false)}
    ${v25TrackHtml(1,"Voix principale","recording",true)}
    ${v25TrackHtml(2,"Doublage","recording",true)}
    ${v25TrackHtml(3,"Ad-libs","recording",true)}
  </div>
  <div class="mixer-master" style="margin-top:12px"><div class="row"><button class="btn primary" onclick="v25PreviewMix()">▶ Prévisualiser</button><button class="btn" onclick="v25StopPreview()">■ Stop</button><button class="btn purple" onclick="v25SaveMixProject()">Sauvegarder</button><button class="btn green" onclick="v25ExportMix()">Exporter WAV</button></div><div id="mixProgress" class="export-progress hidden"><i></i></div><p id="mixStatus" class="small muted" style="margin-top:7px"></p></div>`;
}
function v25TrackHtml(i,label,type,voice){
  return `<div class="track"><div class="track-head"><b><i class="track-dot"></i>${label}</b><label class="pill"><input id="mixMute${i}" type="checkbox" style="width:auto"> Muet</label></div>
  <div class="track-controls"><div><label>Source<select id="mixSource${i}" data-type="${type}"><option value="">Aucune</option></select></label></div>
  <div><label>Volume<input id="mixVolume${i}" type="range" min="0" max="1.3" step=".05" value="${i===0?".85":"1"}"></label></div>
  <div><label>Décalage (s)<input id="mixOffset${i}" type="number" min="0" max="60" step=".1" value="0"></label></div>
  ${voice?`<div style="grid-column:1/-1"><label>Preset voix<select id="mixPreset${i}"><option>Clean</option><option>Punch</option><option>Warm</option><option>Airy</option></select></label></div>`:""}</div></div>`;
}
async function v25LoadMixerOptions(){
  const [beats,recs]=await Promise.all([dbAll("beats"),dbAll("recordings")]);
  for(let i=0;i<4;i++){const s=$(`#mixSource${i}`);if(!s)continue;const arr=i===0?beats:recs;s.innerHTML='<option value="">Aucune</option>'+arr.sort((a,b)=>b.date-a.date).map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join("")}
}
function v25GetMixConfig(){
  return {id:uid(),name:$("#mixName").value.trim()||"Maquette",date:Date.now(),tracks:[0,1,2,3].map(i=>({type:i===0?"beat":"recording",sourceId:+$(`#mixSource${i}`).value||null,volume:+$(`#mixVolume${i}`).value,mute:$(`#mixMute${i}`).checked,offset:+$(`#mixOffset${i}`).value||0,preset:i===0?null:$(`#mixPreset${i}`).value}))};
}
function v25SaveMixProject(){
  const c=v25GetMixConfig(),old=state.mixProjects.find(x=>x.name===c.name);if(old)Object.assign(old,c,{id:old.id});else state.mixProjects.unshift(c);state.mixProjects=state.mixProjects.slice(0,20);save(true);toast("Configuration du mix sauvegardée");
}
async function v25LoadMixProject(id){
  const c=state.mixProjects.find(x=>x.id===id);if(!c)return;$("#mixName").value=c.name;
  c.tracks.forEach((t,i)=>{$(`#mixSource${i}`).value=t.sourceId||"";$(`#mixVolume${i}`).value=t.volume;$(`#mixMute${i}`).checked=t.mute;$(`#mixOffset${i}`).value=t.offset;if(i>0)$(`#mixPreset${i}`).value=t.preset||"Clean"});
}
async function v25MixSources(config){
  const [beats,recs]=await Promise.all([dbAll("beats"),dbAll("recordings")]),ctx=new (window.AudioContext||window.webkitAudioContext)();
  const loaded=[];
  for(const t of config.tracks){if(!t.sourceId||t.mute)continue;const x=(t.type==="beat"?beats:recs).find(a=>a.id===t.sourceId);if(!x)continue;const buf=await ctx.decodeAudioData((await x.blob.arrayBuffer()).slice(0));loaded.push({...t,name:x.name,blob:x.blob,buf})}
  await ctx.close();return loaded;
}
async function v25PreviewMix(){
  v25StopPreview();const cfg=v25GetMixConfig();try{const [beats,recs]=await Promise.all([dbAll("beats"),dbAll("recordings")]);
  for(const t of cfg.tracks){if(!t.sourceId||t.mute)continue;const x=(t.type==="beat"?beats:recs).find(a=>a.id===t.sourceId);if(!x)continue;const a=new Audio(URL.createObjectURL(x.blob));a.volume=Math.min(1,t.volume);V25_previewAudios.push(a);setTimeout(()=>a.play().catch(()=>{}),t.offset*1000)}
  $("#mixStatus").textContent="Prévisualisation en cours. Les presets sont appliqués uniquement à l’export WAV."}catch(e){toast("Prévisualisation impossible")}}
function v25StopPreview(){V25_previewAudios.forEach(a=>{a.pause();URL.revokeObjectURL(a.src)});V25_previewAudios=[];if($("#mixStatus"))$("#mixStatus").textContent=""}
function v25ApplyVoiceChain(ctx,source,preset){
  let node=source;const hp=ctx.createBiquadFilter();hp.type="highpass";hp.frequency.value=preset==="Warm"?70:95;node.connect(hp);node=hp;
  if(preset==="Punch"){const eq=ctx.createBiquadFilter();eq.type="peaking";eq.frequency.value=2200;eq.Q.value=1;eq.gain.value=3.5;node.connect(eq);node=eq}
  if(preset==="Warm"){const eq=ctx.createBiquadFilter();eq.type="lowshelf";eq.frequency.value=220;eq.gain.value=2.2;node.connect(eq);node=eq}
  if(preset==="Airy"){const eq=ctx.createBiquadFilter();eq.type="highshelf";eq.frequency.value=7500;eq.gain.value=3;node.connect(eq);node=eq}
  const comp=ctx.createDynamicsCompressor();comp.threshold.value=preset==="Punch"?-20:-15;comp.knee.value=18;comp.ratio.value=preset==="Punch"?4:2.5;comp.attack.value=.006;comp.release.value=.18;node.connect(comp);return comp;
}
async function v25ExportMix(){
  const cfg=v25GetMixConfig(),bar=$("#mixProgress"),fill=$("#mixProgress i"),status=$("#mixStatus");bar.classList.remove("hidden");fill.style.width="8%";status.textContent="Décodage des pistes…";
  try{
    const loaded=await v25MixSources(cfg);if(!loaded.length)throw new Error("empty");
    const length=Math.max(...loaded.map(x=>x.buf.duration+x.offset));if(length>600)throw new Error("long");
    fill.style.width="30%";status.textContent="Préparation du rendu audio…";
    const sr=44100,off=new OfflineAudioContext(2,Math.ceil(length*sr),sr),master=off.createDynamicsCompressor();master.threshold.value=-3;master.ratio.value=8;master.connect(off.destination);
    loaded.forEach(t=>{const s=off.createBufferSource();s.buffer=t.buf;const gain=off.createGain();gain.gain.value=t.volume;s.connect(gain);const last=t.type==="recording"?v25ApplyVoiceChain(off,gain,t.preset||"Clean"):gain;last.connect(master);s.start(t.offset)});
    fill.style.width="55%";status.textContent="Mixage hors ligne…";const rendered=await off.startRendering();fill.style.width="85%";status.textContent="Création du WAV…";
    const wav=v25EncodeWav(rendered),blob=new Blob([wav],{type:"audio/wav"}),name=`${safeName(cfg.name)}.wav`,file=new File([blob],name,{type:"audio/wav"});
    fill.style.width="100%";state.stats.mixes++;state.stats.sessions++;state.stats.minutes+=Math.max(1,Math.round(length/60));addXp(20,"studio");save();
    if(navigator.canShare?.({files:[file]}))await navigator.share({title:cfg.name,files:[file]}).catch(()=>downloadBlob(blob,name));else downloadBlob(blob,name);
    status.textContent="Export WAV terminé.";setTimeout(()=>bar.classList.add("hidden"),1800);
  }catch(e){bar.classList.add("hidden");status.textContent=e.message==="long"?"Projet trop long pour le mixage mobile (10 min maximum).":"Ajoute au moins une piste compatible.";toast("Export impossible")}
}
function v25EncodeWav(buffer){
  const n=buffer.numberOfChannels,len=buffer.length*n*2,out=new ArrayBuffer(44+len),v=new DataView(out);let p=0;
  const w=s=>{for(let i=0;i<s.length;i++)v.setUint8(p++,s.charCodeAt(i))},u16=x=>{v.setUint16(p,x,true);p+=2},u32=x=>{v.setUint32(p,x,true);p+=4};
  w("RIFF");u32(36+len);w("WAVE");w("fmt ");u32(16);u16(1);u16(n);u32(buffer.sampleRate);u32(buffer.sampleRate*n*2);u16(n*2);u16(16);w("data");u32(len);
  const ch=Array.from({length:n},(_,i)=>buffer.getChannelData(i));
  for(let i=0;i<buffer.length;i++)for(let c=0;c<n;c++){let s=Math.max(-1,Math.min(1,ch[c][i]));v.setInt16(p,s<0?s*32768:s*32767,true);p+=2}return out;
}

/* ---------- Camera Performance ---------- */
function v25RenderPerformance(){
  const projectOptions=state.projects.map(p=>`<option value="${p.id}">${esc(p.title)}</option>`).join("");
  return `<div class="card"><div class="two-fields"><div class="field"><label>Charger les paroles d’un projet</label><select id="perfProject" onchange="v25LoadProjectLyrics(this.value)"><option value="">Texte libre</option>${projectOptions}</select></div>
  <div class="field"><label>Vitesse du prompteur</label><input id="perfSpeed" type="range" min="8" max="70" value="${state.performanceSettings.speed}" oninput="state.performanceSettings.speed=+this.value;save()"></div></div>
  <div class="field"><label>Texte du prompteur</label><textarea id="perfText" style="min-height:150px" placeholder="Colle les paroles ici..."></textarea></div>
  <div class="row"><label class="pill"><input id="perfMirror" type="checkbox" style="width:auto" ${state.performanceSettings.mirror?"checked":""} onchange="v25ToggleMirror(this.checked)"> Mode miroir</label>
  <button class="btn" onclick="v25StartCamera()">Activer la caméra</button></div></div>
  <div class="section-head"><h3>Scène d’entraînement</h3><span>Regard, posture et mémorisation</span></div>
  <div id="performanceStage" class="performance-stage ${state.performanceSettings.mirror?"mirror":""}"><video id="perfVideo" autoplay playsinline muted></video><div class="teleprompter"><div class="stage-guide"></div><div id="teleText" class="teleprompter-text"></div></div><div id="stageCue" class="stage-cue">Prêt</div>
  <div class="stage-actions"><button class="btn" onclick="v25ToggleTeleprompter()">▶ Prompteur</button><button id="perfRecordBtn" class="btn primary" onclick="v25TogglePerformanceRecord()">● Vidéo</button></div></div>
  <div id="perfLast" class="hidden card" style="margin-top:11px"><video id="perfPlayback" controls style="width:100%;max-height:420px;background:#000;border-radius:14px"></video><div class="row" style="margin-top:9px"><button class="btn green" onclick="v25SharePerformance()">Partager / enregistrer</button></div></div>
  <div class="section-head"><h3>Performances enregistrées</h3><span>${state.stats.performances}</span></div><div id="performanceLibrary" class="card"><div class="empty">Chargement...</div></div>`;
}
function v25LoadProjectLyrics(id){const p=state.projects.find(x=>x.id===id);if(p)$("#perfText").value=p.lyrics}
function v25ToggleMirror(on){state.performanceSettings.mirror=on;save();$("#performanceStage").classList.toggle("mirror",on)}
async function v25StartCamera(){
  try{if(V25_performanceStream)V25_performanceStream.getTracks().forEach(x=>x.stop());V25_performanceStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"user",width:{ideal:720},height:{ideal:1280}},audio:true});$("#perfVideo").srcObject=V25_performanceStream;$("#stageCue").textContent="Caméra active"}catch(e){toast("Caméra ou micro inaccessible")}
}
function v25ToggleTeleprompter(){
  if(V25_teleRAF){cancelAnimationFrame(V25_teleRAF);V25_teleRAF=0;$("#stageCue").textContent="Pause";return}
  const text=$("#perfText").value.trim();if(!text)return toast("Ajoute des paroles");$("#teleText").textContent=text;$("#teleText").style.transform="translateY(0px)";V25_teleStart=performance.now();
  const startY=0,speed=state.performanceSettings.speed;
  const loop=now=>{const y=-(now-V25_teleStart)/1000*speed;$("#teleText").style.transform=`translateY(${startY+y}px)`;$("#stageCue").textContent=["Regard caméra","Respire","Projette","Articule"][Math.floor((now-V25_teleStart)/9000)%4];V25_teleRAF=requestAnimationFrame(loop)};V25_teleRAF=requestAnimationFrame(loop);
}
async function v25TogglePerformanceRecord(){
  if(V25_performanceRecorder?.state==="recording"){V25_performanceRecorder.stop();return}
  if(!V25_performanceStream)await v25StartCamera();if(!V25_performanceStream)return;
  try{
    const opt={};if(MediaRecorder.isTypeSupported("video/webm;codecs=vp8,opus"))opt.mimeType="video/webm;codecs=vp8,opus";
    V25_performanceChunks=[];V25_performanceRecorder=new MediaRecorder(V25_performanceStream,opt);
    V25_performanceRecorder.ondataavailable=e=>{if(e.data.size)V25_performanceChunks.push(e.data)};
    V25_performanceRecorder.onstop=async()=>{clearInterval(V25_perfTimer);$("#perfRecordBtn").textContent="● Vidéo";V25_performanceBlob=new Blob(V25_performanceChunks,{type:V25_performanceRecorder.mimeType||"video/webm"});$("#perfPlayback").src=URL.createObjectURL(V25_performanceBlob);$("#perfLast").classList.remove("hidden");
      await dbAdd("performances",{name:`Performance ${new Date().toLocaleString("fr-FR")}`,blob:V25_performanceBlob,type:V25_performanceBlob.type,date:Date.now(),projectId:$("#perfProject").value||null});state.stats.performances++;state.stats.sessions++;addXp(18,"studio");save();v25LoadPerformanceLibrary()};
    V25_performanceRecorder.start(1000);V25_perfStart=Date.now();$("#perfRecordBtn").textContent="■ Arrêter";V25_perfTimer=setInterval(()=>{$("#stageCue").textContent=`REC ${formatTime(Math.floor((Date.now()-V25_perfStart)/1000))}`},500);
  }catch(e){toast("Enregistrement vidéo non pris en charge")}
}
function v25SharePerformance(){if(!V25_performanceBlob)return;const file=new File([V25_performanceBlob],`performance-raplab-${Date.now()}.webm`,{type:V25_performanceBlob.type});if(navigator.canShare?.({files:[file]}))navigator.share({title:"Performance RapLab",files:[file]}).catch(()=>{});else downloadBlob(V25_performanceBlob,file.name)}
async function v25LoadPerformanceLibrary(){
  const z=$("#performanceLibrary");if(!z)return;let all=[];try{all=(await dbAll("performances")).sort((a,b)=>b.date-a.date)}catch(e){}
  z.innerHTML=all.length?all.map(x=>`<div class="video-item lesson"><div class="lesson-index">▶</div><div style="min-width:0"><b>${esc(x.name)}</b><p class="small">${new Date(x.date).toLocaleString("fr-FR")}</p><video controls src="${URL.createObjectURL(x.blob)}"></video></div><button class="btn small red" onclick="v25DeletePerformance(${x.id})">Suppr.</button></div>`).join(""):'<div class="empty">Aucune vidéo de performance.</div>';
}
async function v25DeletePerformance(id){if(!confirm("Supprimer cette vidéo ?"))return;await dbDelete("performances",id);v25LoadPerformanceLibrary()}

/* Save upgraded state once extension is loaded */
v25Ensure(state);
save();
renderRoute();
