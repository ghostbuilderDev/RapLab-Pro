RAPLAB AI START 2.4

- Tutoriel vocal débutant complet en 12 étapes.
- Explication de toute la navigation et du parcours de création.
- Mode avancé verrouillé jusqu’à deux objectifs : tutoriel terminé + premier projet sauvegardé.
- Déblocage automatique et écran de progression.
- Tutoriel vocal Pro en 10 étapes dans le mode avancé.
- Retour permanent vers le mode simple.
- Voix personnelle toujours enregistrable pour les étapes du tutoriel débutant.
