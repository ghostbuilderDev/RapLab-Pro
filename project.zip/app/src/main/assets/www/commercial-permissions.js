
(function(){
  function state(){return window.NativeAndroid&&NativeAndroid.getPermissionState?NativeAndroid.getPermissionState():{camera:false,microphone:false,notifications:false}}
  function label(v){return v?'Autorisé':'À autoriser'}
  function render(){
    const s=state(), btn=document.getElementById('permissionFab');
    if(btn){const ok=s.camera&&s.microphone;btn.textContent=ok?'Micro & caméra OK':'Activer micro/caméra';btn.classList.toggle('ok',ok)}
    ['camera','microphone','notifications'].forEach(k=>{const el=document.getElementById('perm-'+k);if(el){el.textContent=label(!!s[k]);el.style.color=s[k]?'#38d996':'#ff9a55'}})
  }
  function open(){document.getElementById('permissionPanel').classList.add('open');render()}
  function close(){document.getElementById('permissionPanel').classList.remove('open')}
  window.RapLabPermissions={open,close,render,request:function(){NativeAndroid.requestMediaPermissions();setTimeout(render,600)},settings:function(){NativeAndroid.openAppSettings()}};
  document.addEventListener('DOMContentLoaded',function(){
    document.body.insertAdjacentHTML('beforeend',`<button id="permissionFab" class="permission-fab" onclick="RapLabPermissions.open()">Activer micro/caméra</button><div id="permissionPanel" class="permission-panel" onclick="if(event.target===this)RapLabPermissions.close()"><section class="permission-card"><h2>Autorisations RapLab Pro</h2><p>Le studio audio utilise le microphone. Le mode performance utilise la caméra et le microphone. Aucune capture n'est envoyée sans action de ta part.</p><div class="permission-row"><span>Microphone</span><span id="perm-microphone" class="permission-badge"></span></div><div class="permission-row"><span>Caméra</span><span id="perm-camera" class="permission-badge"></span></div><div class="permission-row"><span>Notifications</span><span id="perm-notifications" class="permission-badge"></span></div><div class="permission-actions"><button class="permission-primary" onclick="RapLabPermissions.request()">Autoriser maintenant</button><button class="permission-secondary" onclick="RapLabPermissions.settings()">Ouvrir les réglages Android</button><button class="permission-secondary" onclick="RapLabPermissions.close()">Fermer</button></div></section></div>`);
    render();
  });
  window.addEventListener('raplab-permissions-changed',render);
})();
