(function () {
  'use strict';

  const current = {
    camera: false,
    microphone: false,
    notifications: typeof Notification !== 'undefined' && Notification.permission === 'granted'
  };

  function nativeBridge() {
    return (window.NativeAndroid && typeof window.NativeAndroid === 'object')
      ? window.NativeAndroid
      : null;
  }

  async function refreshBrowserPermissions() {
    if (!navigator.permissions || typeof navigator.permissions.query !== 'function') return;
    const checks = [
      ['camera', 'camera'],
      ['microphone', 'microphone'],
      ['notifications', 'notifications']
    ];
    await Promise.all(checks.map(async ([key, name]) => {
      try {
        const status = await navigator.permissions.query({ name: name });
        current[key] = status.state === 'granted';
        status.onchange = function () {
          current[key] = status.state === 'granted';
          render();
        };
      } catch (_) {
        // Certaines versions d'Android WebView ne permettent pas la requête.
      }
    }));
  }

  function readNativeState() {
    const bridge = nativeBridge();
    if (!bridge || typeof bridge.getPermissionState !== 'function') return;
    try {
      const state = bridge.getPermissionState();
      if (state && typeof state === 'object') Object.assign(current, state);
    } catch (_) {}
  }

  function label(value) {
    return value ? 'Autorisé' : 'À autoriser';
  }

  function render() {
    readNativeState();
    const button = document.getElementById('permissionFab');
    if (button) {
      const ok = current.camera && current.microphone;
      button.textContent = ok ? 'Micro & caméra OK' : 'Activer micro/caméra';
      button.classList.toggle('ok', ok);
    }
    ['camera', 'microphone', 'notifications'].forEach(function (key) {
      const element = document.getElementById('perm-' + key);
      if (!element) return;
      element.textContent = label(Boolean(current[key]));
      element.style.color = current[key] ? '#38d996' : '#ff9a55';
    });
  }

  function open() {
    const panel = document.getElementById('permissionPanel');
    if (panel) panel.classList.add('open');
    refreshBrowserPermissions().finally(render);
  }

  function close() {
    const panel = document.getElementById('permissionPanel');
    if (panel) panel.classList.remove('open');
  }

  async function request() {
    const bridge = nativeBridge();
    if (bridge && typeof bridge.requestMediaPermissions === 'function') {
      try {
        bridge.requestMediaPermissions();
        setTimeout(render, 700);
        return;
      } catch (_) {}
    }

    if (!navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia !== 'function') {
      alert('Cette version Android ne permet pas l’accès au micro et à la caméra. Mets à jour Android System WebView puis réessaie.');
      return;
    }

    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
      current.microphone = true;
      current.camera = true;
    } catch (error) {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        current.microphone = true;
      } catch (_) {}
      alert('Autorise RapLab Pro dans Réglages Android > Applications > RapLab Pro > Autorisations, puis relance le test.');
    } finally {
      if (stream) stream.getTracks().forEach(function (track) { track.stop(); });
      refreshBrowserPermissions().finally(render);
    }
  }

  function settings() {
    const bridge = nativeBridge();
    if (bridge && typeof bridge.openAppSettings === 'function') {
      try {
        bridge.openAppSettings();
        return;
      } catch (_) {}
    }
    alert('Ouvre Réglages Android > Applications > RapLab Pro > Autorisations, puis active Microphone et Caméra.');
  }

  window.RapLabPermissions = { open, close, render, request, settings };

  document.addEventListener('DOMContentLoaded', function () {
    if (document.getElementById('permissionPanel')) return;
    document.body.insertAdjacentHTML('beforeend',
      '<button id="permissionFab" class="permission-fab" type="button">Activer micro/caméra</button>' +
      '<div id="permissionPanel" class="permission-panel">' +
        '<section class="permission-card" role="dialog" aria-modal="true" aria-labelledby="permissionTitle">' +
          '<h2 id="permissionTitle">Autorisations RapLab Pro</h2>' +
          '<p>Le studio utilise le microphone. Le mode performance utilise la caméra et le microphone. Aucune capture n’est envoyée sans ton action.</p>' +
          '<div class="permission-row"><span>Microphone</span><span id="perm-microphone" class="permission-badge"></span></div>' +
          '<div class="permission-row"><span>Caméra</span><span id="perm-camera" class="permission-badge"></span></div>' +
          '<div class="permission-row"><span>Notifications</span><span id="perm-notifications" class="permission-badge"></span></div>' +
          '<div class="permission-actions">' +
            '<button id="requestPermissionsButton" class="permission-primary" type="button">Autoriser maintenant</button>' +
            '<button id="openSettingsButton" class="permission-secondary" type="button">Ouvrir les réglages Android</button>' +
            '<button id="closePermissionsButton" class="permission-secondary" type="button">Fermer</button>' +
          '</div>' +
        '</section>' +
      '</div>'
    );
    document.getElementById('permissionFab').addEventListener('click', open);
    document.getElementById('requestPermissionsButton').addEventListener('click', request);
    document.getElementById('openSettingsButton').addEventListener('click', settings);
    document.getElementById('closePermissionsButton').addEventListener('click', close);
    document.getElementById('permissionPanel').addEventListener('click', function (event) {
      if (event.target === this) close();
    });
    refreshBrowserPermissions().finally(render);
  });

  window.addEventListener('raplab-permissions-changed', function (event) {
    if (event.detail && typeof event.detail === 'object') Object.assign(current, event.detail);
    render();
  });
})();
