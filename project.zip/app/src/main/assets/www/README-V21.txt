RAPLAB START 5.0 — VERSION SIMPLE

Objectif principal : aider un débutant à créer son premier couplet en 4 étapes.
1. Choisir/importer un beat
2. Choisir un thème et recevoir des idées originales
3. Écrire 8 mesures avec compteur approximatif de syllabes
4. S'entraîner et enregistrer sa voix

Le mode avancé historique reste accessible via expert.html.
Aucun texte protégé de rappeur n'est intégré. Les exemples et amorces sont originaux.
Le microphone n'est demandé qu'au moment d'appuyer sur REC.
