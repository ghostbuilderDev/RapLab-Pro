"use strict";
(()=>{
const steps=[
 {title:"Bienvenue dans le mode avancé",text:"Tu as acquis les bases. Ici, RapLab t'aide à travailler comme un artiste : technique, régularité, création, enregistrement et analyse.",route:"home",selector:".screen"},
 {title:"L'Academy",text:"L'Academy organise ta progression. Commence par les exercices proposés dans l'ordre. Ils développent respiration, diction, rythme, écriture et interprétation.",route:"academy",selector:".screen"},
 {title:"Les exercices de flow",text:"Le flow est la manière de placer les mots sur le rythme. Travaille lentement, puis augmente la difficulté seulement quand ta voix reste régulière.",route:"academy",selector:".screen"},
 {title:"Créer sans perdre ton identité",text:"L'espace Créer fournit des idées, structures et aides. Utilise-les pour démarrer, puis remplace toujours les éléments génériques par ton vécu et ton vocabulaire.",route:"create",selector:".screen"},
 {title:"Le studio",text:"Le studio sert à importer un beat, enregistrer plusieurs prises et comparer ton placement. Fais une prise d'essai, une prise énergique puis une prise plus posée.",route:"studio",selector:".screen"},
 {title:"Microphone et caméra",text:"Les autorisations sont demandées uniquement au moment où une fonction en a besoin. Le microphone sert aux prises audio. La caméra sert au mode performance si tu choisis de l'utiliser.",route:"studio",selector:".screen"},
 {title:"Analyser pour progresser",text:"Écoute chaque prise avec trois questions : les mots sont-ils compréhensibles, suis-je bien sur le beat, et est-ce que l'émotion correspond au texte ?",route:"studio",selector:".screen"},
 {title:"Ton profil et ta progression",text:"Le profil rassemble ton niveau, tes résultats et tes projets. Ne cherche pas seulement les points : utilise les progrès pour choisir le prochain exercice utile.",route:"profile",selector:".screen"},
 {title:"Le bon parcours",text:"Une séance efficace dure environ vingt minutes : cinq minutes de technique, dix minutes de création, puis cinq minutes d'enregistrement et d'écoute.",route:"home",selector:".bottom-nav"},
 {title:"Tu es prêt",text:"Reviens au mode simple pour créer rapidement, ou reste ici pour travailler une compétence précise. Le guide Pro reste disponible en haut de l'écran.",route:"home",selector:".topbar"}
];
let i=0;
function stop(){try{speechSynthesis.cancel()}catch{}}
function speak(){stop();if(!('speechSynthesis'in window))return;const u=new SpeechSynthesisUtterance(steps[i].text);u.lang='fr-FR';u.rate=.93;const vs=speechSynthesis.getVoices();u.voice=vs.find(v=>v.lang&&v.lang.startsWith('fr'))||null;speechSynthesis.speak(u)}
function focus(){document.querySelectorAll('.expert-focus').forEach(x=>x.classList.remove('expert-focus'));const st=steps[i];try{if(typeof go==='function')go(st.route)}catch{}setTimeout(()=>{const el=document.querySelector(st.selector);if(el){el.classList.add('expert-focus');el.scrollIntoView({behavior:'smooth',block:'center'})}},220)}
function render(auto=true){const st=steps[i];document.getElementById('agCount').textContent=`Guide Pro ${i+1}/${steps.length}`;document.getElementById('agTitle').textContent=st.title;document.getElementById('agText').textContent=st.text;document.getElementById('agBar').style.width=`${(i+1)/steps.length*100}%`;document.getElementById('agPrev').disabled=i===0;document.getElementById('agNext').textContent=i===steps.length-1?'Terminer ✓':'Suivant →';focus();if(auto)setTimeout(speak,320)}
function open(){document.getElementById('advancedGuide').classList.add('open');render(true)}
function close(){stop();document.querySelectorAll('.expert-focus').forEach(x=>x.classList.remove('expert-focus'));document.getElementById('advancedGuide').classList.remove('open');localStorage.setItem('raplab_advanced_tutorial_done','1')}
const box=document.createElement('div');box.id='advancedGuide';box.className='advanced-guide';box.innerHTML=`<div class="advanced-guide-card"><div class="advanced-guide-head"><span id="agCount"></span><button id="agClose">×</button></div><h2 id="agTitle"></h2><p id="agText"></p><div class="advanced-guide-progress"><i id="agBar"></i></div><div class="advanced-guide-controls"><button class="secondary" id="agPrev">← Précédent</button><button class="secondary repeat" id="agRepeat">🔊 Réécouter</button><button class="primary" id="agNext">Suivant →</button></div></div>`;document.body.appendChild(box);
document.getElementById('expertGuideBtn')?.addEventListener('click',()=>{i=0;open()});document.getElementById('agClose').onclick=close;document.getElementById('agRepeat').onclick=speak;document.getElementById('agPrev').onclick=()=>{if(i>0){i--;render(true)}};document.getElementById('agNext').onclick=()=>{if(i>=steps.length-1){close();return}i++;render(true)};
if(new URLSearchParams(location.search).get('tutorial')==='1'||!localStorage.getItem('raplab_advanced_tutorial_done'))setTimeout(open,700);
})();
