plugins {
    id("com.android.application")
}

android {
    namespace = "dev.ghostbuilderdev.raplabpro.raplabpro.a07mfop2"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.ghostbuilderdev.raplabpro.raplabpro.a07mfop2"
        minSdk = 24
        targetSdk = 35
        versionCode = 206647905
        versionName = "4.1-microphone-fixed"
    }

    buildTypes {
        debug {
        }

        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}


dependencies {
    implementation("androidx.webkit:webkit:1.16.0")
}
