"use strict";

/* RapLab Pro 3.1 — tutoriel guidé, ajouté sur la base exacte V3 Expert. */
const RAPLAB_TUTORIAL_VERSION="3.1";
const RAPLAB_TUTORIAL_KEY="raplab_tutorial_v31_done";
let raplabTutorialIndex=0;
let raplabTutorialRunning=false;
let raplabTutorialHighlighted=null;

const RAPLAB_TUTORIAL_STEPS=[
 {title:"Bienvenue dans RapLab Pro Expert",text:"Cette visite te montre comment passer d’une idée à un morceau, progresser techniquement et conserver tes beats sur le téléphone.",route:"home",selector:".brand"},
 {title:"Ta séance du jour",text:"Commence ici. Le programme choisit des exercices courts selon tes compétences les plus faibles et met à jour ton niveau.",route:"home",selector:".hero .btn.primary"},
 {title:"Rap Academy",text:"Le parcours principal contient 12 semaines. Termine les leçons dans l’ordre, puis utilise les modules avancés lorsque les bases deviennent naturelles.",route:"academy",group:"academy",sub:"program",selector:".bottom-nav [data-route='academy']"},
 {title:"Expert Academy V3",text:"Cette version ajoute pocket, cadences, multisyllabiques, delivery, arrangement, scène et démo professionnelle.",route:"academy",group:"academy",sub:"expert",selector:".hero, .card"},
 {title:"Flow Architect",text:"Construis un flow sur une grille de 16 pas. Active les syllabes, place les accents, règle le swing et sauvegarde tes meilleurs patterns.",route:"academy",group:"academy",sub:"flowgrid",selector:".pattern, .step-grid, .card"},
 {title:"Ear Training",text:"Entraîne ton oreille à reconnaître croches, syncopes, triolets, flow aéré et double-time avant de les reproduire.",route:"academy",group:"academy",sub:"ear",selector:".card"},
 {title:"Écriture et projets",text:"Crée un morceau, indique son BPM et sa structure, conserve plusieurs versions du texte puis associe-lui une instrumentale.",route:"create",group:"create",sub:"projects",selector:".bottom-nav [data-route='create']"},
 {title:"Technique Lab",text:"Analyse densité, respirations, régularité et rimes. Les outils avancés t’aident à cibler une correction précise avant la prochaine prise.",route:"academy",group:"academy",sub:"technique",selector:".tabs, .card"},
 {title:"Beat Vault",text:"Importe plusieurs beats. Ajoute BPM, tonalité, style, humeur, tags, favoris et collections. Les fichiers restent dans la mémoire privée de l’application.",route:"studio",group:"studio",sub:"beats",selector:".bottom-nav [data-route='studio']"},
 {title:"Studio, Flow Scan et mixeur",text:"Enregistre avec un casque, compare tes prises, mesure les attaques au tempo et prépare une maquette avec les pistes voix, doublage et ad-libs.",route:"studio",group:"studio",sub:"record",selector:".wave, .card"},
 {title:"Performance et battle",text:"Travaille l’interprétation face caméra, le téléprompteur, la récupération après un trou de mémoire et les réponses de battle fictives.",route:"academy",group:"academy",sub:"battle",selector:".card"},
 {title:"Profil, sauvegarde et aide",text:"Retrouve tes statistiques, exporte les projets en JSON et relance ce tutoriel à tout moment avec le bouton ? ou depuis le Profil.",route:"profile",selector:".profile-chip"}
];

function raplabEnsureHelpButton(){
 if(document.querySelector(".tutorial-help-fab"))return;
 const b=document.createElement("button");b.className="tutorial-help-fab";b.type="button";b.textContent="?";b.setAttribute("aria-label","Ouvrir le tutoriel RapLab");b.onclick=raplabOpenHelpCenter;document.body.appendChild(b);
}
function raplabClearHighlight(){if(raplabTutorialHighlighted){raplabTutorialHighlighted.classList.remove("tutorial-highlight");raplabTutorialHighlighted=null}}
function raplabTutorialNavigate(step){
 raplabClearHighlight();
 if(step.route)route=step.route;
 if(step.group&&step.sub)sub[step.group]=step.sub;
 renderRoute();
 setTimeout(()=>raplabApplyStep(step),140);
}
function raplabApplyStep(step){
 raplabClearHighlight();
 const target=step.selector?document.querySelector(step.selector):null;
 if(target){raplabTutorialHighlighted=target;target.classList.add("tutorial-highlight");try{target.scrollIntoView({behavior:"smooth",block:"center"})}catch(e){}}
 raplabRenderTutorialCard(step);
}
function raplabRenderTutorialCard(step){
 let card=document.getElementById("raplabTutorialCard");
 if(!card){card=document.createElement("section");card.id="raplabTutorialCard";card.className="tutorial-card";document.body.appendChild(card)}
 const first=raplabTutorialIndex===0,last=raplabTutorialIndex===RAPLAB_TUTORIAL_STEPS.length-1;
 card.innerHTML=`<div class="tutorial-top"><span class="tutorial-count">Étape ${raplabTutorialIndex+1}/${RAPLAB_TUTORIAL_STEPS.length} · V${RAPLAB_TUTORIAL_VERSION}</span><button class="tutorial-close" onclick="raplabEndTutorial(true)" aria-label="Fermer">✕</button></div><h2>${esc(step.title)}</h2><p>${esc(step.text)}</p><div class="tutorial-dots">${RAPLAB_TUTORIAL_STEPS.map((_,i)=>`<i class="${i===raplabTutorialIndex?"on":""}"></i>`).join("")}</div><div class="tutorial-actions"><button class="btn ghost" onclick="raplabEndTutorial(true)">Passer</button>${first?"":`<button class="btn" onclick="raplabTutorialPrevious()">← Précédent</button>`}<button class="btn primary" onclick="${last?"raplabCompleteTutorial()":"raplabTutorialNext()"}">${last?"Terminer":"Suivant →"}</button></div>`;
}
function raplabStartTutorial(startIndex=0){
 raplabTutorialRunning=true;raplabTutorialIndex=Math.max(0,Math.min(RAPLAB_TUTORIAL_STEPS.length-1,startIndex));raplabTutorialNavigate(RAPLAB_TUTORIAL_STEPS[raplabTutorialIndex]);
}
function raplabTutorialNext(){if(raplabTutorialIndex<RAPLAB_TUTORIAL_STEPS.length-1){raplabTutorialIndex++;raplabTutorialNavigate(RAPLAB_TUTORIAL_STEPS[raplabTutorialIndex])}else raplabCompleteTutorial()}
function raplabTutorialPrevious(){if(raplabTutorialIndex>0){raplabTutorialIndex--;raplabTutorialNavigate(RAPLAB_TUTORIAL_STEPS[raplabTutorialIndex])}}
function raplabEndTutorial(markDone=false){
 raplabTutorialRunning=false;raplabClearHighlight();document.getElementById("raplabTutorialCard")?.remove();if(markDone)localStorage.setItem(RAPLAB_TUTORIAL_KEY,"1");
}
function raplabCompleteTutorial(){localStorage.setItem(RAPLAB_TUTORIAL_KEY,"1");raplabEndTutorial(false);route="home";renderRoute();toast("Tutoriel terminé — prêt à rapper")}
function raplabResetTutorial(){localStorage.removeItem(RAPLAB_TUTORIAL_KEY);closeModal();setTimeout(()=>raplabStartTutorial(0),100)}
function raplabOpenModule(routeName,groupName,subName){closeModal();route=routeName;if(groupName&&subName)sub[groupName]=subName;renderRoute()}
function raplabOpenHelpCenter(){
 const items=[
  ["Démarrage guidé","Revoir les 12 étapes de prise en main.","raplabStartTutorial(0);closeModal()"],
  ["Programme Academy","Cours progressifs et validation des semaines.","raplabOpenModule('academy','academy','program')"],
  ["Expert Academy","Pocket, cadences, multisyllabiques et delivery.","raplabOpenModule('academy','academy','expert')"],
  ["Flow Architect","Créer et sauvegarder un pattern sur 16 pas.","raplabOpenModule('academy','academy','flowgrid')"],
  ["Écriture / projets","Créer un morceau et gérer ses versions.","raplabOpenModule('create','create','projects')"],
  ["Beat Vault","Importer, classer et analyser les instrumentales.","raplabOpenModule('studio','studio','beats')"],
  ["Enregistrement","Faire une prise micro puis la partager.","raplabOpenModule('studio','studio','record')"],
  ["Performance","Caméra, téléprompteur et présence scénique.","raplabOpenModule('studio','studio','performance')"]
 ];
 openModal(`${modalHead("Tutoriel et centre d’aide")}<p class="muted">Choisis un module ou relance la visite complète. Tes données et tes beats ne seront pas effacés.</p><div class="tutorial-help-grid" style="margin-top:13px">${items.map(x=>`<div class="tutorial-help-item" onclick="${x[2]}"><b>${esc(x[0])}</b><small>${esc(x[1])}</small></div>`).join("")}</div><div class="row" style="margin-top:14px"><button class="btn primary" onclick="closeModal();raplabStartTutorial(0)">▶ Visite complète</button><button class="btn" onclick="raplabResetTutorial()">Réafficher au prochain démarrage</button></div>`);
}

const RAPLAB_TUTORIAL_OLD_PROFILE=renderProfile;
renderProfile=function(){return RAPLAB_TUTORIAL_OLD_PROFILE()+`<div class="section-head"><h3>Tutoriel</h3><span>Prise en main V3 Expert</span></div><div class="card tutorial-profile-card"><div class="row"><div class="tutorial-step-number">?</div><div class="list-copy"><b>Visite guidée et centre d’aide</b><p class="small">Revois les fonctions de la V3, ouvre directement un module ou réactive le tutoriel de premier lancement.</p></div></div><div class="row" style="margin-top:13px"><button class="btn primary" onclick="raplabStartTutorial(0)">Lancer le tutoriel</button><button class="btn" onclick="raplabOpenHelpCenter()">Centre d’aide</button></div></div>`};

const RAPLAB_TUTORIAL_OLD_AFTER_RENDER=afterRender;
afterRender=function(){RAPLAB_TUTORIAL_OLD_AFTER_RENDER();raplabEnsureHelpButton()};

raplabEnsureHelpButton();
renderRoute();
setTimeout(()=>{if(!localStorage.getItem(RAPLAB_TUTORIAL_KEY))raplabStartTutorial(0)},650);
