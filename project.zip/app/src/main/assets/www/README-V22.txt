RAPLAB AI START V22

1. Importer ce ZIP directement dans HTMLtoAPK.
2. Le fichier index.html est à la racine.
3. Ne pas ajouter android-bridge.js dans le ZIP : HTMLtoAPK injecte son propre pont.

NOUVEAUTES
- Générateur local de paroles originales selon thème, ambiance, style, point de vue et mots personnels.
- Régénération complète ou ligne par ligne.
- Sélecteur Android audio avec import multiple depuis Téléchargements, Audio ou tout dossier visible.
- Beats stockés en IndexedDB, plus fiable que localStorage pour les gros fichiers.
- Aucun texte ni audio envoyé sur Internet.

IMPORTANT
Le sélecteur de fichiers dépend du WebView Android de HTMLtoAPK. Celui-ci doit supporter <input type=file> et onShowFileChooser.
