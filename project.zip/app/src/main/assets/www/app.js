
"use strict";
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const nowDate=()=>new Date().toISOString().slice(0,10);
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const clone=o=>JSON.parse(JSON.stringify(o));
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const escAttr=s=>esc(s).replace(/`/g,"&#096;");
const DEFAULT_STATE={
 version:2,xp:0,streak:0,lastActive:null,
 profile:{artistName:"",level:"Débutant",styles:["Boom bap"],dailyMinutes:20,goal:"Finaliser une première démo"},
 stats:{sessions:0,texts:0,bars:0,freestyles:0,recordings:0,breathSessions:0,minutes:0},
 skills:{rythme:18,ecriture:16,rimes:12,flow:14,diction:12,freestyle:10,souffle:12,studio:8},
 academy:{week:0,completed:{}},
 missions:{date:null,academy:false,write:false,free:false},
 projects:[],notes:[],savedTexts:[],history:[],
 currentProjectId:null,freestyleLevel:1,flowDrill:0,
 settings:{metronomeBpm:88,breathPattern:"4-2-8",theme:"dark"},
 lastAnalysis:null
};
let state=loadState(), route="home", sub={academy:"program",create:"projects",studio:"beats"};
let audioCtx=null, metroTimer=null, metroBeat=0, nextNoteTime=0, taps=[];
let breathRunning=false, breathHandles=[];
let freestyleSeconds=60, freestyleTimer=null;
let mediaRecorder=null, recordChunks=[], recordStart=0, recordTicker=null, currentRecordBlob=null, currentRecordId=null;
let selectedBeatId=null, selectedBeatUrl=null, loopConfig={on:false,start:0,end:0};

function loadState(){
 try{
  const v2=JSON.parse(localStorage.getItem("raplab_v2_state"));
  if(v2) return mergeState(v2);
  const v1=JSON.parse(localStorage.getItem("raplab_state"));
  if(v1){
   const migrated=clone(DEFAULT_STATE);
   migrated.xp=v1.xp||0;migrated.streak=v1.streak||0;migrated.lastActive=v1.lastActive||null;
   migrated.stats.sessions=v1.sessions||0;migrated.stats.texts=v1.texts||0;migrated.stats.freestyles=v1.freestyles||0;
   migrated.skills.ecriture=v1.skills?.ecriture||16;migrated.skills.rythme=v1.skills?.rythme||18;
   migrated.skills.flow=v1.skills?.flow||14;migrated.skills.freestyle=v1.skills?.freestyle||10;
   migrated.skills.souffle=v1.skills?.respiration||12;migrated.skills.studio=v1.skills?.studio||8;
   migrated.savedTexts=(v1.savedLyrics||[]).map(x=>({id:uid(),title:"Texte importé",text:x.text,date:x.date}));
   return migrated;
  }
 }catch(e){}
 return clone(DEFAULT_STATE);
}
function mergeState(x){
 return {...clone(DEFAULT_STATE),...x,profile:{...DEFAULT_STATE.profile,...x.profile},
 stats:{...DEFAULT_STATE.stats,...x.stats},skills:{...DEFAULT_STATE.skills,...x.skills},
 academy:{...DEFAULT_STATE.academy,...x.academy,completed:{...(x.academy?.completed||{})}},
 missions:{...DEFAULT_STATE.missions,...x.missions},settings:{...DEFAULT_STATE.settings,...x.settings},
 projects:Array.isArray(x.projects)?x.projects:[],notes:Array.isArray(x.notes)?x.notes:[],savedTexts:Array.isArray(x.savedTexts)?x.savedTexts:[]};
}
function save(render=false){
 localStorage.setItem("raplab_v2_state",JSON.stringify(state)); updateHeader(); unlockBadges();
 if(render) renderRoute();
}
function touchDay(){
 const t=nowDate();
 if(state.lastActive!==t){
  if(state.lastActive){
   const d=Math.round((new Date(t)-new Date(state.lastActive))/86400000);
   state.streak=d===1?state.streak+1:1;
  } else state.streak=1;
  state.lastActive=t;
 }
 if(state.missions.date!==t) state.missions={date:t,academy:false,write:false,free:false};
 save();
}
function addXp(n,skill){
 state.xp+=n;if(skill)state.skills[skill]=Math.min(100,(state.skills[skill]||0)+Math.max(1,Math.round(n/7)));
 save();toast(`+${n} XP`);
}
function completedWeeks(s=state){
 let n=0;for(let w=0;w<ACADEMY_WEEKS.length;w++)if(ACADEMY_WEEKS[w].lessons.every((_,i)=>s.academy.completed[`${w}-${i}`]))n++;return n;
}
function academyPercent(){
 const total=ACADEMY_WEEKS.reduce((a,w)=>a+w.lessons.length,0);
 return Math.round(Object.values(state.academy.completed).filter(Boolean).length/total*100);
}
function updateHeader(){
 const lvl=Math.floor(state.xp/100)+1;
 $("#artistMini").textContent=state.profile.artistName||"Nouvel artiste";$("#levelMini").textContent=`Niv. ${lvl}`;
 $$("[data-route]").forEach(b=>b.classList.toggle("active",b.dataset.route===route));
}
function go(r){route=r;renderRoute();window.scrollTo({top:0,behavior:"smooth"})}
function setSub(group,value){sub[group]=value;renderRoute()}
function renderRoute(){
 updateHeader();
 const map={home:renderHome,academy:renderAcademy,create:renderCreate,studio:renderStudio,profile:renderProfile};
 $("#screen").innerHTML=(map[route]||renderHome)();
 afterRender();
}
function afterRender(){
 updateHeader();
 if(route==="profile")setTimeout(drawStats,30);
 if(route==="studio"&&sub.studio==="beats")setTimeout(loadBeatLibrary,10);
 if(route==="studio"&&sub.studio==="record")setTimeout(()=>{initWave();loadRecordings()},10);
 if(route==="create"&&sub.create==="editor")setTimeout(loadEditorProject,10);
 if(route==="create"&&sub.create==="write"&&state.lastAnalysis)setTimeout(renderSavedAnalysis,10);
}
function toast(msg){
 const t=$("#toast");t.textContent=msg;t.classList.add("show");clearTimeout(window.__toast);
 window.__toast=setTimeout(()=>t.classList.remove("show"),1900);
}
function openModal(html){$("#modalBox").innerHTML=html;$("#modal").classList.add("open")}
function closeModal(){$("#modal").classList.remove("open")}
function modalBackdrop(e){if(e.target.id==="modal")closeModal()}
function modalHead(title){return `<div class="modal-head"><h2>${esc(title)}</h2><button class="close" onclick="closeModal()">✕</button></div>`}
function tabs(group,items){
 return `<div class="tabs">${items.map(([id,label])=>`<button class="tab ${sub[group]===id?"active":""}" onclick="setSub('${group}','${id}')">${label}</button>`).join("")}</div>`;
}
function skillRows(){
 const names={rythme:"Rythme",ecriture:"Écriture",rimes:"Rimes",flow:"Flow",diction:"Diction",freestyle:"Freestyle",souffle:"Souffle",studio:"Studio"};
 return Object.entries(state.skills).map(([k,v])=>`<div class="skill-row"><b>${names[k]}</b><div class="progress"><i style="width:${v}%"></i></div><span>${v}</span></div>`).join("");
}
function missionRow(key,icon,title,desc){
 const done=state.missions[key];
 return `<div class="list-item"><div class="list-icon">${icon}</div><div class="list-copy"><b>${title}</b><small>${desc}</small></div>
 <button class="check ${done?"done":""}" onclick="completeMission('${key}')">✓</button></div>`;
}
function completeMission(key){
 if(state.missions[key])return toast("Mission déjà validée aujourd’hui");
 state.missions[key]=true;const skills={academy:"rythme",write:"ecriture",free:"freestyle"};addXp(20,skills[key]);state.stats.sessions++;save(true);
}

function renderHome(){
 const level=Math.floor(state.xp/100)+1,cur=state.xp%100,pct=academyPercent();
 const current=state.projects.find(p=>p.id===state.currentProjectId)||state.projects[0];
 return `<section class="hero">
  <span class="eyebrow">Programme personnalisé</span>
  <h1>${state.profile.artistName?`Continue, ${esc(state.profile.artistName)}.`:"Construis ton identité de rappeur."}</h1>
  <p>${state.profile.goal?esc(state.profile.goal):"Une séance structurée pour progresser en écriture, rythme, flow et interprétation."}</p>
  <div class="row"><button class="btn primary" onclick="startDaily()">▶ Séance du jour</button><button class="btn" onclick="openCoach()">Coach local</button></div>
 </section>
 <div class="section-head"><h2>Progression</h2><span>🔥 ${state.streak} jour${state.streak>1?"s":""}</span></div>
 <div class="grid3">
  <div class="card"><span class="metric-label">Niveau</span><div class="metric">${level}</div><div class="progress"><i style="width:${cur}%"></i></div><p class="small">${cur}/100 XP</p></div>
  <div class="card"><span class="metric-label">Academy</span><div class="metric">${pct}%</div><div class="progress green"><i style="width:${pct}%"></i></div><p class="small">${completedWeeks()}/12 semaines</p></div>
  <div class="card"><span class="metric-label">Temps estimé</span><div class="metric">${state.stats.minutes}</div><p>minutes pratiquées</p></div>
 </div>
 <div class="section-head"><h2>Missions du jour</h2><span>60 XP possibles</span></div>
 <div class="list">
  ${missionRow("academy","▤","Une leçon Academy","Valider l’étape suivante du programme.")}
  ${missionRow("write","✍️","Écrire huit mesures","Une idée claire, une ligne par mesure.")}
  ${missionRow("free","⚡","Freestyle 60 secondes","Continuer même quand le mot parfait ne vient pas.")}
 </div>
 <div class="section-head"><h2>Compétences</h2><span>Diagnostic évolutif</span></div>
 <div class="card">${skillRows()}</div>
 <div class="section-head"><h2>Projet actif</h2><span>${state.projects.length} projet${state.projects.length>1?"s":""}</span></div>
 ${current?`<div class="card project-card" onclick="openProject('${current.id}')"><span class="pill purple">${esc(current.status)}</span><h3 style="margin-top:9px">${esc(current.title)}</h3><p>${esc(current.theme||"Aucun thème défini")} · ${current.bpm||"—"} BPM</p></div>`:
 `<div class="card empty"><p>Crée ton premier morceau pour rassembler paroles, beat, structure et prises.</p><button class="btn primary" style="margin-top:12px" onclick="newProjectModal()">Créer un projet</button></div>`}`;
}
function startDaily(){route="academy";sub.academy="program";renderRoute();toast("Commence par la prochaine leçon")}

function openCoach(){
 const weak=Object.entries(state.skills).sort((a,b)=>a[1]-b[1])[0][0];
 const label={rythme:"le rythme",ecriture:"l’écriture",rimes:"les rimes",flow:"le flow",diction:"la diction",freestyle:"le freestyle",souffle:"le souffle",studio:"le studio"}[weak];
 const plan={
 rythme:["4 min de métronome à 75 BPM","4 min avec deux syllabes par temps","Une prise de huit mesures"],
 ecriture:["Écrire huit mesures sur une seule idée","Raccourcir les lignes trop longues","Lire le texte au métronome"],
 rimes:["Choisir une famille de sons","Écrire quatre paires de rimes","Ajouter deux rimes internes"],
 flow:["Répéter un pattern simple","Déplacer un accent","Refaire le texte avec plus de silences"],
 diction:["Échauffement consonnes","Un virelangue à 70 puis 90 BPM","Une prise lente et parfaitement claire"],
 freestyle:["60 secondes de description","Trois mots imposés","90 secondes sans interruption"],
 souffle:["Trois cycles 4-2-8","Marquer les respirations d’un texte","Tenir quatre mesures sans forcer"],
 studio:["Une prise énergie","Une prise précision","Comparer et noter un seul axe"]
 }[weak];
 openModal(`${modalHead("Coach RapLab")}<p>Ta priorité actuelle est <b>${label}</b>. Voici une séance ciblée :</p>
 <div class="list" style="margin-top:12px">${plan.map((x,i)=>`<div class="list-item"><div class="list-icon">${i+1}</div><div class="list-copy"><b>${x}</b></div></div>`).join("")}</div>
 <button class="btn primary" style="margin-top:14px" onclick="closeModal();launchCoach('${weak}')">Lancer</button>`);
}
function launchCoach(weak){
 if(["rythme","flow","diction","souffle","freestyle"].includes(weak)){route="academy";sub.academy=weak==="rythme"?"flow":weak}
 else if(["ecriture","rimes"].includes(weak)){route="create";sub.create=weak==="rimes"?"rhymes":"write"}
 else {route="studio";sub.studio="record"}
 renderRoute();
}

function renderAcademy(){
 const t=tabs("academy",[["program","Programme"],["flow","Flow"],["diction","Diction"],["souffle","Souffle"],["freestyle","Freestyle"]]);
 let body="";
 if(sub.academy==="program")body=renderProgram();
 if(sub.academy==="flow")body=renderFlowLab();
 if(sub.academy==="diction")body=renderDiction();
 if(sub.academy==="souffle")body=renderBreath();
 if(sub.academy==="freestyle")body=renderFreestyle();
 return `<div class="section-head"><h2>Rap Academy</h2><span>Parcours professionnel sur 12 semaines</span></div>${t}${body}`;
}
function renderProgram(){
 const w=state.academy.week||0,week=ACADEMY_WEEKS[w],done=week.lessons.filter((_,i)=>state.academy.completed[`${w}-${i}`]).length;
 return `<div class="hero"><span class="eyebrow">Semaine ${w+1}/12 · ${esc(week.focus)}</span><h1>${esc(week.title)}</h1><p>${esc(week.desc)}</p>
 <div class="progress green"><i style="width:${done/week.lessons.length*100}%"></i></div><p class="small">${done}/${week.lessons.length} leçons validées</p></div>
 <div class="section-head"><h3>Leçons</h3><span>+15 XP chacune</span></div>
 <div class="card">${week.lessons.map((x,i)=>lessonHtml(w,i,x)).join("")}</div>
 <div class="section-head"><h3>Les 12 semaines</h3><span>${completedWeeks()} terminée(s)</span></div>
 <div class="grid">${ACADEMY_WEEKS.map((x,i)=>weekCard(x,i)).join("")}</div>`;
}
function lessonHtml(w,i,x){
 const done=!!state.academy.completed[`${w}-${i}`];
 return `<div class="lesson"><div class="lesson-index">${done?"✓":i+1}</div><div><b>${esc(x[0])}</b><p class="small">${esc(x[1])}</p></div>
 <button class="btn small ${done?"green":""}" onclick="toggleLesson(${w},${i})">${done?"Validé":"Terminer"}</button></div>`;
}
function weekCard(x,i){
 const done=x.lessons.filter((_,j)=>state.academy.completed[`${i}-${j}`]).length,pct=done/x.lessons.length*100;
 return `<div class="card week-card" onclick="selectWeek(${i})"><div class="row"><div class="week-num">${i+1}</div><div><span class="pill">${esc(x.focus)}</span><h3 style="margin-top:7px">${esc(x.title)}</h3></div></div>
 <div class="progress" style="margin-top:12px"><i style="width:${pct}%"></i></div><p class="small">${done}/${x.lessons.length} leçons</p></div>`;
}
function selectWeek(i){state.academy.week=i;save(true);window.scrollTo({top:0,behavior:"smooth"})}
function toggleLesson(w,i){
 const k=`${w}-${i}`;if(state.academy.completed[k])return toast("Leçon déjà validée");
 state.academy.completed[k]=true;state.stats.sessions++;state.stats.minutes+=5;state.missions.academy=true;
 const focus=ACADEMY_WEEKS[w].focus.toLowerCase(),skill=focus.includes("ryth")?"rythme":focus.includes("rime")?"rimes":focus.includes("flow")?"flow":focus.includes("dict")?"diction":focus.includes("free")?"freestyle":focus.includes("studio")?"studio":"ecriture";
 addXp(15,skill);save(true);
}
function renderFlowLab(){
 const d=FLOW_DRILLS[state.flowDrill%FLOW_DRILLS.length];
 return `<div class="card"><div class="tempo"><span id="bpmValue">${state.settings.metronomeBpm}</span> <small>BPM</small></div>
 <input id="bpmRange" type="range" min="55" max="180" value="${state.settings.metronomeBpm}" oninput="setBpm(this.value)">
 <div class="beat-dots">${[0,1,2,3].map(()=>`<i class="beat-dot"></i>`).join("")}</div>
 <div class="row" style="justify-content:center"><button id="metroBtn" class="btn primary" onclick="toggleMetronome()">▶ Métronome</button><button class="btn" onclick="tapTempo()">Tap tempo</button></div></div>
 <div class="section-head"><h3>${esc(d[0])}</h3><span>Exercice ${state.flowDrill+1}/${FLOW_DRILLS.length}</span></div>
 <div class="card"><div class="pattern">${esc(d[1])}</div><p style="margin-top:12px">${esc(d[2])}</p>
 <div class="row" style="margin-top:13px"><button class="btn purple" onclick="nextFlow()">Exercice suivant</button><button class="btn green" onclick="finishSkill('flow',12,5)">Terminé +12 XP</button></div></div>`;
}
function setBpm(v){state.settings.metronomeBpm=+v;$("#bpmValue").textContent=v;save()}
function scheduleClick(time,n){
 const osc=audioCtx.createOscillator(),gain=audioCtx.createGain();osc.frequency.value=n===0?1050:690;
 gain.gain.setValueAtTime(.20,time);gain.gain.exponentialRampToValueAtTime(.001,time+.055);osc.connect(gain).connect(audioCtx.destination);osc.start(time);osc.stop(time+.06);
 setTimeout(()=>$$(".beat-dot").forEach((d,i)=>{d.classList.toggle("on",i===n);d.classList.toggle("down",i===0&&n===0)}),Math.max(0,(time-audioCtx.currentTime)*1000));
}
function metroScheduler(){while(nextNoteTime<audioCtx.currentTime+.1){scheduleClick(nextNoteTime,metroBeat);nextNoteTime+=60/state.settings.metronomeBpm;metroBeat=(metroBeat+1)%4}}
function toggleMetronome(){
 if(metroTimer){clearInterval(metroTimer);metroTimer=null;$("#metroBtn").textContent="▶ Métronome";$$(".beat-dot").forEach(x=>x.classList.remove("on","down"));return}
 audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();audioCtx.resume();metroBeat=0;nextNoteTime=audioCtx.currentTime+.05;
 metroTimer=setInterval(metroScheduler,25);$("#metroBtn").textContent="■ Arrêter";
}
function tapTempo(){
 const n=performance.now();taps=taps.filter(x=>n-x<2500);taps.push(n);
 if(taps.length<2)return toast("Tape encore en rythme");
 const gaps=taps.slice(1).map((x,i)=>x-taps[i]);setBpm(Math.max(55,Math.min(180,Math.round(60000/(gaps.reduce((a,b)=>a+b,0)/gaps.length)))));
}
function nextFlow(){state.flowDrill=(state.flowDrill+1)%FLOW_DRILLS.length;save(true)}
function renderDiction(){
 const idx=(state.stats.sessions||0)%DICTION_EXERCISES.length,d=DICTION_EXERCISES[idx];
 return `<div class="hero"><span class="eyebrow">Articulation</span><h1>${esc(d[0])}</h1><p>${esc(d[2])}</p></div>
 <div class="section-head"><h3>Phrase d’entraînement</h3><span>Lis lentement avant d’accélérer</span></div>
 <div class="card"><div class="prompt">« ${esc(d[1])} »</div><div class="row"><button class="btn" onclick="speakText('${escAttr(d[1])}')">Écouter</button><button class="btn primary" onclick="startDictionTimer()">Test 45 s</button><button class="btn green" onclick="finishSkill('diction',12,4)">Validé +12 XP</button></div>
 <div id="dictionTimer" class="timer hidden">00:45</div></div>
 <div class="section-head"><h3>Routine express</h3></div><div class="card"><p>1. Relâche la mâchoire.<br>2. Fais vibrer les lèvres pendant 20 secondes.<br>3. Lis la phrase à demi-vitesse.<br>4. Augmente le BPM sans perdre les consonnes finales.</p></div>`;
}
function speakText(text){
 if(!("speechSynthesis" in window))return toast("Lecture vocale indisponible");
 speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang="fr-FR";u.rate=.75;speechSynthesis.speak(u);
}
function startDictionTimer(){
 let s=45,el=$("#dictionTimer");el.classList.remove("hidden");el.textContent="00:45";
 const iv=setInterval(()=>{s--;el.textContent=`00:${String(s).padStart(2,"0")}`;if(s<=0){clearInterval(iv);toast("Test terminé")}},1000);
}
function renderBreath(){
 return `<div class="card"><div class="breath-stage"><div id="breathCircle" class="breath-circle"><div><b id="breathPhase">Prêt</b><br><span id="breathSec" class="muted">${state.settings.breathPattern}</span></div></div></div>
 <div class="row" style="justify-content:center"><select id="breathSelect" style="width:auto" onchange="state.settings.breathPattern=this.value;save(true)"><option ${state.settings.breathPattern==="4-2-8"?"selected":""}>4-2-8</option><option ${state.settings.breathPattern==="4-4-4"?"selected":""}>4-4-4</option><option ${state.settings.breathPattern==="3-1-6"?"selected":""}>3-1-6</option></select>
 <button id="breathBtn" class="btn primary" onclick="toggleBreath()">Démarrer 3 cycles</button></div></div>
 <div class="section-head"><h3>Progression du souffle</h3><span>${state.stats.breathSessions} séance(s)</span></div>
 <div class="card"><p>Ne force jamais. L’objectif est une expiration régulière, pas de tenir jusqu’à l’inconfort. Utilise ensuite la même sensation pour finir les mesures sans perdre d’énergie.</p></div>`;
}
function toggleBreath(){breathRunning?stopBreath():startBreath()}
function startBreath(){
 breathRunning=true;$("#breathBtn").textContent="Arrêter";const nums=state.settings.breathPattern.split("-").map(Number),phases=[["Inspire",nums[0],"inhale"],["Bloque",nums[1],""],["Expire",nums[2],"exhale"]];
 let cursor=0;for(let c=0;c<3;c++)for(const p of phases){breathHandles.push(setTimeout(()=>breathPhase(...p),cursor*1000));cursor+=p[1]}
 breathHandles.push(setTimeout(()=>{stopBreath();state.stats.breathSessions++;state.stats.minutes+=Math.round(cursor/60);addXp(10,"souffle");save(true)},cursor*1000));
}
function breathPhase(name,secs,cls){
 const c=$("#breathCircle");c.className=`breath-circle ${cls}`;$("#breathPhase").textContent=name;let s=secs;$("#breathSec").textContent=`${s} s`;
 const iv=setInterval(()=>{s--;$("#breathSec").textContent=`${Math.max(0,s)} s`;if(s<=0)clearInterval(iv)},1000);breathHandles.push(iv);
}
function stopBreath(){breathRunning=false;breathHandles.forEach(clearTimeout);breathHandles=[];if($("#breathCircle")){$("#breathCircle").className="breath-circle";$("#breathPhase").textContent="Prêt";$("#breathSec").textContent=state.settings.breathPattern;$("#breathBtn").textContent="Démarrer 3 cycles"}}
function renderFreestyle(){
 const p=currentFreestylePrompt();
 return `<div class="card"><span class="pill purple">Niveau ${state.freestyleLevel}/10</span><span class="pill">${esc(p.emotion)}</span>
 <div class="prompt">${esc(p.topic)}</div><p><b>Contrainte :</b> ${esc(p.constraint)}</p><div id="freeTimer" class="timer">${formatTime(freestyleSeconds)}</div>
 <div class="row"><button class="btn" onclick="newFreestyle()">Nouveau sujet</button><button id="freeBtn" class="btn primary" onclick="toggleFreestyle()">▶ Démarrer</button></div></div>
 <div class="section-head"><h3>Progression des niveaux</h3><span>Le niveau augmente tous les 3 freestyles</span></div>
 <div class="card"><p>${freestyleRule(state.freestyleLevel)}</p><div class="progress" style="margin-top:12px"><i style="width:${(state.stats.freestyles%3)/3*100}%"></i></div></div>`;
}
let freestylePromptCache=null;
function currentFreestylePrompt(){if(!freestylePromptCache)newFreestyle();return freestylePromptCache}
function newFreestyle(render=false){
 const words=FREESTYLE_WORDS[Math.floor(Math.random()*FREESTYLE_WORDS.length)],level=state.freestyleLevel;
 const constraints=[
  "Parle sans t’arrêter pendant une minute.",
  `Place « ${words.join(" », « ")} ».`,
  `Change de sous-thème après trente secondes et place « ${words[0]} ».`,
  `Garde l’émotion imposée et place « ${words.join(" », « ")} ».`,
  "Raconte la scène du point de vue d’un personnage.",
  "Construis un début, un problème et une fin.",
  "Change clairement de flow après trente secondes.",
  "Commence lentement puis augmente le débit.",
  "Réponds à la phrase : « Tu n’iras jamais jusqu’au bout. »",
  "Tiens trois minutes avec deux changements de flow."
 ][level-1];
 freestylePromptCache={topic:FREESTYLE_TOPICS[Math.floor(Math.random()*FREESTYLE_TOPICS.length)],emotion:FREESTYLE_EMOTIONS[Math.floor(Math.random()*FREESTYLE_EMOTIONS.length)],constraint:constraints};
 if(render)renderRoute();
 return freestylePromptCache;
}
function freestyleRule(l){
 return ["Décris et associe librement les idées.","Trois mots imposés.","Changement de thème.","Émotion imposée.","Personnage imposé.","Storytelling complet.","Changement de flow.","Changement de débit.","Réponse de battle fictive.","Freestyle de trois minutes."][l-1];
}
function toggleFreestyle(){
 if(freestyleTimer){clearInterval(freestyleTimer);freestyleTimer=null;$("#freeBtn").textContent="▶ Reprendre";return}
 if(freestyleSeconds<=0)freestyleSeconds=state.freestyleLevel===10?180:60;
 $("#freeBtn").textContent="Ⅱ Pause";
 freestyleTimer=setInterval(()=>{freestyleSeconds--;$("#freeTimer").textContent=formatTime(freestyleSeconds);if(freestyleSeconds<=0){clearInterval(freestyleTimer);freestyleTimer=null;finishFreestyle()}},1000);
}
function finishFreestyle(){
 state.stats.freestyles++;state.stats.sessions++;state.stats.minutes+=state.freestyleLevel===10?3:1;state.missions.free=true;
 state.freestyleLevel=Math.min(10,Math.floor(state.stats.freestyles/3)+1);freestyleSeconds=state.freestyleLevel===10?180:60;freestylePromptCache=null;
 addXp(20,"freestyle");save(true);toast("Freestyle terminé");
}
function formatTime(s){return `${String(Math.floor(s/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`}
function finishSkill(skill,xp,minutes){state.stats.sessions++;state.stats.minutes+=minutes;addXp(xp,skill);save(true)}

function renderCreate(){
 const t=tabs("create",[["projects","Projets"],["write","Écriture"],["rhymes","Rimes"],["notes","Carnet"]]);
 let body=sub.create==="projects"?renderProjects():sub.create==="editor"?renderProjectEditor():sub.create==="write"?renderWriting():sub.create==="rhymes"?renderRhymes():renderNotes();
 return `<div class="section-head"><h2>Créer</h2><span>De l’idée au morceau</span></div>${t}${body}`;
}
function renderProjects(){
 return `<div class="row between"><span class="pill purple">${state.projects.length} projet${state.projects.length>1?"s":""}</span><button class="btn primary" onclick="newProjectModal()">+ Nouveau morceau</button></div>
 <div class="section-head"><h3>Mes morceaux</h3><span>Textes, structure et objectifs</span></div>
 ${state.projects.length?`<div class="grid">${state.projects.map(projectCard).join("")}</div>`:`<div class="card empty"><p>Aucun projet. Crée un morceau pour organiser tes paroles, ton BPM et tes versions.</p></div>`}`;
}
function projectCard(p){
 const bars=(p.lyrics||"").split("\n").filter(x=>x.trim()).length;
 return `<div class="card project-card" onclick="openProject('${p.id}')"><span class="status">${esc(p.status)}</span><h3>${esc(p.title)}</h3><p>${esc(p.theme||"Thème à définir")}</p>
 <div class="row" style="margin-top:12px"><span class="pill">${p.bpm||"—"} BPM</span><span class="pill">${bars} mesures</span><span class="pill">${esc(p.structure||"Couplet")}</span></div></div>`;
}
function newProjectModal(){
 openModal(`${modalHead("Nouveau projet")}<div class="field"><label>Titre</label><input id="newTitle" placeholder="Titre du morceau"></div>
 <div class="two-fields"><div class="field"><label>Thème</label><input id="newTheme" placeholder="Ex. ambition, famille..."></div><div class="field"><label>BPM</label><input id="newBpm" type="number" min="55" max="200" value="90"></div></div>
 <button class="btn primary" onclick="createProject()">Créer le projet</button>`);
}
function createProject(){
 const title=$("#newTitle").value.trim()||"Nouveau morceau",p={id:uid(),title,theme:$("#newTheme").value.trim(),bpm:+$("#newBpm").value||90,key:"",status:"Idée",structure:"Intro / Couplet / Refrain / Couplet / Outro",lyrics:"",notes:"",created:Date.now(),updated:Date.now(),versions:[]};
 state.projects.unshift(p);state.currentProjectId=p.id;save();closeModal();openProject(p.id);addXp(10,"ecriture");
}
function openProject(id){state.currentProjectId=id;sub.create="editor";route="create";save();renderRoute()}
function renderProjectEditor(){
 return `<div id="projectEditor"></div>`;
}
function loadEditorProject(){
 const p=state.projects.find(x=>x.id===state.currentProjectId);if(!p){sub.create="projects";renderRoute();return}
 $("#projectEditor").innerHTML=`<div class="row between"><button class="btn" onclick="setSub('create','projects')">← Projets</button><span class="pill purple">${esc(p.status)}</span></div>
 <div class="section-head"><h2>${esc(p.title)}</h2><span>Mis à jour ${new Date(p.updated).toLocaleDateString("fr-FR")}</span></div>
 <div class="card">
  <div class="two-fields"><div class="field"><label>Titre</label><input id="pTitle" value="${escAttr(p.title)}"></div><div class="field"><label>Statut</label><select id="pStatus">${["Idée","Écriture","Maquette","À réenregistrer","Mix en cours","Terminé","Publié"].map(x=>`<option ${p.status===x?"selected":""}>${x}</option>`).join("")}</select></div></div>
  <div class="two-fields"><div class="field"><label>Thème</label><input id="pTheme" value="${escAttr(p.theme)}"></div><div class="field"><label>BPM</label><input id="pBpm" type="number" min="55" max="200" value="${p.bpm||90}"></div></div>
  <div class="field"><label>Structure</label><input id="pStructure" value="${escAttr(p.structure)}"></div>
  <div class="field"><label>Paroles — une mesure par ligne</label><textarea id="pLyrics" style="min-height:310px">${esc(p.lyrics)}</textarea></div>
  <div class="field"><label>Notes de production / interprétation</label><textarea id="pNotes">${esc(p.notes)}</textarea></div>
  <div class="row"><button class="btn primary" onclick="saveProjectEditor()">Sauvegarder</button><button class="btn" onclick="versionProject()">Créer une version</button><button class="btn red" onclick="deleteProject('${p.id}')">Supprimer</button></div>
 </div>
 <div class="section-head"><h3>Versions</h3><span>${p.versions.length}</span></div>
 <div class="card">${p.versions.length?p.versions.map((v,i)=>`<div class="lesson"><div class="lesson-index">V${p.versions.length-i}</div><div><b>${new Date(v.date).toLocaleString("fr-FR")}</b><p class="small">${v.lyrics.split("\n").filter(Boolean).length} mesures</p></div><button class="btn small" onclick="restoreVersion('${p.id}',${i})">Restaurer</button></div>`).join(""):'<div class="empty">Aucune version enregistrée.</div>'}</div>`;
}
function saveProjectEditor(){
 const p=state.projects.find(x=>x.id===state.currentProjectId);if(!p)return;
 Object.assign(p,{title:$("#pTitle").value.trim()||"Sans titre",status:$("#pStatus").value,theme:$("#pTheme").value.trim(),bpm:+$("#pBpm").value||90,structure:$("#pStructure").value.trim(),lyrics:$("#pLyrics").value,notes:$("#pNotes").value,updated:Date.now()});
 state.stats.bars=Math.max(state.stats.bars,(p.lyrics||"").split("\n").filter(x=>x.trim()).length);save();toast("Projet sauvegardé");
}
function versionProject(){saveProjectEditor();const p=state.projects.find(x=>x.id===state.currentProjectId);p.versions.unshift({date:Date.now(),lyrics:p.lyrics,notes:p.notes});p.versions=p.versions.slice(0,20);save(true);toast("Version créée")}
function restoreVersion(id,i){const p=state.projects.find(x=>x.id===id),v=p?.versions[i];if(!v)return;p.lyrics=v.lyrics;p.notes=v.notes;p.updated=Date.now();save(true);toast("Version restaurée")}
function deleteProject(id){if(!confirm("Supprimer définitivement ce projet ?"))return;state.projects=state.projects.filter(x=>x.id!==id);if(state.currentProjectId===id)state.currentProjectId=null;sub.create="projects";save(true)}
function renderWriting(){
 const text=state.lastWritingDraft||"";
 return `<div class="card"><div class="field"><label>Atelier — une mesure par ligne</label><textarea id="lyricsDraft" style="min-height:300px" placeholder="Écris ton couplet ici..." oninput="state.lastWritingDraft=this.value;save()">${esc(text)}</textarea></div>
 <div class="row"><button class="btn primary" onclick="analyzeLyrics()">Analyser</button><button class="btn" onclick="writingPrompt()">Thème aléatoire</button><button class="btn" onclick="saveText()">Sauvegarder</button><button class="btn purple" onclick="createProjectFromDraft()">Créer un projet</button></div></div>
 <div id="analysisZone">${state.lastAnalysis?analysisHtml(state.lastAnalysis):""}</div>
 <div class="section-head"><h3>Textes sauvegardés</h3><span>${state.savedTexts.length}</span></div>
 <div class="card">${state.savedTexts.length?state.savedTexts.slice(0,8).map(t=>`<div class="lesson"><div class="lesson-index">✎</div><div><b>${esc(t.title)}</b><p class="small">${new Date(t.date).toLocaleDateString("fr-FR")} · ${t.text.split("\n").filter(Boolean).length} mesures</p></div><button class="btn small" onclick="loadSavedText('${t.id}')">Ouvrir</button></div>`).join(""):'<div class="empty">Aucun texte sauvegardé.</div>'}</div>`;
}
const STOP=new Set("le la les un une des de du d et en à a au aux pour par sur dans avec sans ce cet cette ces je tu il elle on nous vous ils elles mon ma mes ton ta tes son sa ses que qui quoi dont ne pas plus se me te lui leur y ou où mais donc car ni si".split(" "));
function norm(w){return w.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z]/g,"")}
function syllables(line){
 const ws=line.toLowerCase().replace(/[^a-zàâäéèêëîïôöùûüÿçœ'\-\s]/g," ").split(/\s+/).filter(Boolean);let n=0;
 ws.forEach(w=>{w=w.replace(/(?:e|es|ent)$/,"");const g=w.match(/[aeiouyàâäéèêëîïôöùûüÿœ]+/g);n+=g?g.length:1});return Math.max(1,n);
}
function ending(line){
 const w=norm((line.trim().split(/\s+/).at(-1)||""));if(!w)return "";
 const keys=Object.keys(RHYME_FAMILIES).sort((a,b)=>b.length-a.length),k=keys.find(k=>w.endsWith(norm(k)));if(k)return k;
 return w.slice(-Math.min(3,w.length));
}
function analyzeLyrics(){
 const text=$("#lyricsDraft").value.trim();if(!text)return toast("Écris quelques mesures avant l’analyse");
 const lines=text.split("\n").map(x=>x.trim()).filter(Boolean),syl=lines.map(syllables),avg=syl.reduce((a,b)=>a+b,0)/syl.length;
 const sd=Math.sqrt(syl.reduce((a,b)=>a+(b-avg)**2,0)/syl.length),regularity=Math.max(0,Math.round(100-sd*12));
 const ends=lines.map(ending),countsEnd={};ends.forEach(e=>countsEnd[e]=(countsEnd[e]||0)+1);
 const rhyme=Math.round(ends.filter(e=>countsEnd[e]>=2).length/Math.max(1,lines.length)*100);
 const words=(text.match(/[A-Za-zÀ-ÿœŒ'-]+/g)||[]).map(norm).filter(Boolean),content=words.filter(w=>!STOP.has(w)&&w.length>2),counts={};content.forEach(w=>counts[w]=(counts[w]||0)+1);
 const diversity=Math.round(new Set(content).size/Math.max(1,content.length)*100),repeats=Object.entries(counts).filter(x=>x[1]>=3).sort((a,b)=>b[1]-a[1]).slice(0,5).map(x=>x[0]);
 const length=Math.min(100,lines.length*7),score=Math.round(length*.22+regularity*.26+rhyme*.28+diversity*.24);
 const tips=[];if(lines.length<8)tips.push("Développe jusqu’à huit mesures au minimum.");if(regularity<65)tips.push("Raccourcis les lignes les plus longues.");if(rhyme<40)tips.push("Relie davantage les fins de mesures par familles sonores.");if(diversity<55)tips.push("Remplace certains mots répétés par des images plus précises.");if(!tips.length)tips.push("La structure est solide : travaille maintenant les rimes internes et les changements d’accent.");
 state.lastAnalysis={score,lines:lines.length,avg:+avg.toFixed(1),regularity,rhyme,diversity,repeats,ends,source:text,tips};state.stats.texts++;state.stats.bars+=lines.length;state.missions.write=true;state.skills.ecriture=Math.min(100,state.skills.ecriture+2);state.skills.rimes=Math.min(100,state.skills.rimes+1);addXp(10,"ecriture");save(true);
}
function analysisHtml(a){
 return `<div class="section-head"><h3>Diagnostic</h3><span>Score technique ${a.score}/100</span></div><div class="card">
 <div class="analysis-grid"><div class="analysis-cell"><b>${a.lines}</b><small>Mesures</small></div><div class="analysis-cell"><b>${a.avg}</b><small>Syllabes moy.</small></div><div class="analysis-cell"><b>${a.regularity}%</b><small>Régularité</small></div><div class="analysis-cell"><b>${a.rhyme}%</b><small>Rimes liées</small></div><div class="analysis-cell"><b>${a.diversity}%</b><small>Diversité</small></div><div class="analysis-cell"><b>${a.repeats.length?a.repeats.join(", "):"—"}</b><small>Répétitions</small></div></div>
 <div class="advice"><b>Priorité :</b> ${esc(a.tips.join(" "))}</div><div class="section-head"><h3>Carte des rimes</h3></div>${rhymePreview(a)}</div>`;
}
function rhymePreview(a){
 const groups={},palette={};let c=0;a.ends.forEach(e=>{if(!groups[e])groups[e]=0;groups[e]++;if(groups[e]===2)palette[e]=c++%6});
 const lines=a.source.split("\n").filter(x=>x.trim());
 return `<div class="rhyme-preview">${lines.map((line,i)=>{const parts=line.trim().split(/\s+/),last=parts.pop()||"",e=a.ends[i],cls=groups[e]>=2?`rhyme-word rhyme-c${palette[e]}`:"";return `${esc(parts.join(" "))} <span class="${cls}">${esc(last)}</span>`}).join("\n")}</div>`;
}
function renderSavedAnalysis(){const z=$("#analysisZone");if(z&&state.lastAnalysis)z.innerHTML=analysisHtml(state.lastAnalysis)}
function writingPrompt(){toast(WRITING_PROMPTS[Math.floor(Math.random()*WRITING_PROMPTS.length)])}
function saveText(){
 const text=$("#lyricsDraft").value.trim();if(!text)return toast("Aucun texte à sauvegarder");
 const title=prompt("Titre du texte :","Texte "+new Date().toLocaleDateString("fr-FR"))||"Sans titre";state.savedTexts.unshift({id:uid(),title,text,date:Date.now()});state.savedTexts=state.savedTexts.slice(0,50);save(true);toast("Texte sauvegardé");
}
function loadSavedText(id){const t=state.savedTexts.find(x=>x.id===id);if(!t)return;state.lastWritingDraft=t.text;save(true)}
function createProjectFromDraft(){
 const text=$("#lyricsDraft").value.trim();if(!text)return toast("Le texte est vide");
 const p={id:uid(),title:"Nouveau morceau",theme:"",bpm:90,key:"",status:"Écriture",structure:"Couplet / Refrain / Couplet",lyrics:text,notes:"",created:Date.now(),updated:Date.now(),versions:[]};
 state.projects.unshift(p);state.currentProjectId=p.id;save();openProject(p.id);
}
function renderRhymes(){
 return `<div class="card"><div class="field"><label>Mot ou fin de phrase</label><input id="rhymeQuery" placeholder="Ex. lumière" oninput="searchRhymes()"></div>
 <div class="row"><button class="btn primary" onclick="searchRhymes()">Chercher</button><button class="btn" onclick="randomRhyme()">Famille aléatoire</button></div></div>
 <div id="rhymeResults"><div class="card empty" style="margin-top:12px">Entre un mot pour rechercher des rimes et des assonances.</div></div>
 <div class="section-head"><h3>Conseil</h3></div><div class="card"><p>Choisis d’abord le sens de la mesure. Utilise ensuite la famille sonore comme contrainte créative, sans sacrifier la phrase uniquement pour obtenir une rime.</p></div>`;
}
function searchRhymes(){
 const raw=$("#rhymeQuery").value.trim();if(!raw)return;
 const w=norm(raw.split(/\s+/).at(-1)),keys=Object.keys(RHYME_FAMILIES).sort((a,b)=>b.length-a.length);
 let key=keys.find(k=>w.endsWith(norm(k)));if(!key)key=keys.find(k=>norm(k).slice(-2)===w.slice(-2));
 const exact=key?RHYME_FAMILIES[key]:[],near=keys.filter(k=>k!==key&&norm(k).slice(-1)===w.slice(-1)).slice(0,3).flatMap(k=>RHYME_FAMILIES[k].slice(0,4));
 const multis=exact.slice(0,6).map(x=>`${["garder","changer","suivre","chercher","viser","porter"][Math.floor(Math.random()*6)]} ${x}`);
 $("#rhymeResults").innerHTML=`<div class="section-head"><h3>${key?`Famille « ${esc(key)} »`:"Sons proches"}</h3><span>${exact.length} résultats principaux</span></div>
 <div class="card"><h3>Rimes</h3><div class="word-cloud">${(exact.length?exact:near).map(x=>`<button class="word" onclick="copyWord('${escAttr(x)}')">${esc(x)}</button>`).join("")||"<p>Aucune famille exacte. Essaie un autre mot.</p>"}</div>
 ${near.length?`<h3 style="margin-top:17px">Assonances proches</h3><div class="word-cloud">${near.map(x=>`<button class="word" onclick="copyWord('${escAttr(x)}')">${esc(x)}</button>`).join("")}</div>`:""}
 ${multis.length?`<h3 style="margin-top:17px">Pistes multisyllabiques</h3><div class="word-cloud">${multis.map(x=>`<button class="word" onclick="copyWord('${escAttr(x)}')">${esc(x)}</button>`).join("")}</div>`:""}</div>`;
}
function randomRhyme(){const keys=Object.keys(RHYME_FAMILIES),k=keys[Math.floor(Math.random()*keys.length)];$("#rhymeQuery").value=RHYME_FAMILIES[k][0];searchRhymes()}
function copyWord(w){navigator.clipboard?.writeText(w).then(()=>toast("Copié : "+w)).catch(()=>toast(w))}
function renderNotes(){
 return `<div class="card"><div class="field"><label>Idée rapide</label><textarea id="noteText" placeholder="Punchline, thème, titre, mélodie décrite..."></textarea></div>
 <div class="two-fields"><div class="field"><label>Type</label><select id="noteType"><option>Idée</option><option>Punchline</option><option>Titre</option><option>Refrain</option><option>Thème</option></select></div><div class="field"><label>Tags</label><input id="noteTags" placeholder="Ex. sombre, scène"></div></div>
 <button class="btn primary" onclick="addNote()">Ajouter au carnet</button></div>
 <div class="section-head"><h3>Carnet d’inspiration</h3><span>${state.notes.length} note${state.notes.length>1?"s":""}</span></div>
 <div class="list">${state.notes.length?state.notes.map(n=>`<div class="card note"><div class="row between"><span class="pill">${esc(n.type)}</span><button class="btn small red" onclick="deleteNote('${n.id}')">Suppr.</button></div><p style="margin-top:10px;color:white">${esc(n.text)}</p><small class="muted">${esc(n.tags||"")} · ${new Date(n.date).toLocaleDateString("fr-FR")}</small></div>`).join(""):'<div class="card empty">Capture ici les idées avant qu’elles disparaissent.</div>'}</div>`;
}
function addNote(){const text=$("#noteText").value.trim();if(!text)return toast("Écris une idée");state.notes.unshift({id:uid(),text,type:$("#noteType").value,tags:$("#noteTags").value.trim(),date:Date.now()});save(true);toast("Idée ajoutée")}
function deleteNote(id){state.notes=state.notes.filter(x=>x.id!==id);save(true)}

function renderStudio(){
 const t=tabs("studio",[["beats","Beat Lab"],["record","Enregistrer"],["takes","Prises"]]);
 let body=sub.studio==="beats"?renderBeatLab():sub.studio==="record"?renderRecorder():renderTakesOnly();
 return `<div class="section-head"><h2>Studio mobile</h2><span>Instrumentales et prises locales</span></div>${t}${body}`;
}
function renderBeatLab(){
 return `<div class="row between"><span class="pill purple">Bibliothèque locale</span><button class="btn primary" onclick="$('#beatFilePicker').click()">+ Importer un beat</button></div>
 <div id="selectedBeat"></div><div class="section-head"><h3>Mes instrumentales</h3><span>MP3, WAV, M4A selon le téléphone</span></div><div id="beatLibrary" class="card"><div class="empty">Chargement...</div></div>`;
}
function renderRecorder(){
 return `<div class="card"><div id="wave" class="wave">${Array.from({length:30},()=>"<i></i>").join("")}</div><div id="recordTimer" class="timer">00:00</div>
 <div class="row" style="justify-content:center"><button id="recordBtn" class="btn primary" onclick="toggleRecording()">● Enregistrer</button></div>
 <audio id="lastRecordAudio" controls class="hidden"></audio><div id="lastRecordActions" class="row hidden" style="margin-top:10px;justify-content:center"><button class="btn green" onclick="shareCurrentRecord()">Partager / enregistrer</button><button class="btn" onclick="renameCurrentRecord()">Renommer</button></div>
 <p class="small muted" style="margin-top:12px">Le beat peut jouer en parallèle depuis le Beat Lab. Utilise un casque pour éviter sa reprise par le micro.</p></div>
 <div class="section-head"><h3>Checklist</h3></div><div class="card"><p>Échauffe la diction · marque les respirations · fais une prise énergie · puis une prise précision · compare un seul critère à la fois.</p></div>`;
}
function renderTakesOnly(){return `<div id="recordingsList" class="card"><div class="empty">Chargement...</div></div>`}
function initWave(){}
function db(){
 return new Promise((resolve,reject)=>{const r=indexedDB.open("raplab_v2_db",2);r.onupgradeneeded=()=>{const d=r.result;if(!d.objectStoreNames.contains("recordings"))d.createObjectStore("recordings",{keyPath:"id",autoIncrement:true});if(!d.objectStoreNames.contains("beats"))d.createObjectStore("beats",{keyPath:"id",autoIncrement:true})};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});
}
async function dbAdd(store,obj){const d=await db();return new Promise((res,rej)=>{const r=d.transaction(store,"readwrite").objectStore(store).add(obj);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
async function dbAll(store){const d=await db();return new Promise((res,rej)=>{const r=d.transaction(store).objectStore(store).getAll();r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
async function dbDelete(store,id){const d=await db();return new Promise((res,rej)=>{const r=d.transaction(store,"readwrite").objectStore(store).delete(id);r.onsuccess=res;r.onerror=()=>rej(r.error)})}
async function dbPut(store,obj){const d=await db();return new Promise((res,rej)=>{const r=d.transaction(store,"readwrite").objectStore(store).put(obj);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
async function importBeat(e){
 const file=e.target.files[0];if(!file)return;if(file.size>120*1024*1024)return toast("Fichier trop lourd : limite conseillée 120 Mo");
 try{await dbAdd("beats",{name:file.name.replace(/\.[^.]+$/,""),blob:file,type:file.type,bpm:90,date:Date.now()});toast("Instrumentale importée");if(route==="studio")loadBeatLibrary()}catch(err){toast("Import impossible sur cet appareil")}e.target.value="";
}
async function loadBeatLibrary(){
 const box=$("#beatLibrary");if(!box)return;let beats=[];try{beats=(await dbAll("beats")).sort((a,b)=>b.date-a.date)}catch(e){}
 box.innerHTML=beats.length?beats.map(b=>`<div class="lesson"><div class="lesson-index">♫</div><div><b>${esc(b.name)}</b><p class="small">${b.bpm||90} BPM · ${new Date(b.date).toLocaleDateString("fr-FR")}</p></div><div class="row"><button class="btn small" onclick="selectBeat(${b.id})">Ouvrir</button><button class="btn small red" onclick="removeBeat(${b.id})">Suppr.</button></div></div>`).join(""):'<div class="empty">Aucune instrumentale. Importe un fichier audio depuis le téléphone.</div>';
 if(selectedBeatId)selectBeat(selectedBeatId,false);
}
async function selectBeat(id,scroll=true){
 const beats=await dbAll("beats"),b=beats.find(x=>x.id===id);if(!b)return;selectedBeatId=id;if(selectedBeatUrl)URL.revokeObjectURL(selectedBeatUrl);selectedBeatUrl=URL.createObjectURL(b.blob);
 const z=$("#selectedBeat");if(!z)return;z.innerHTML=`<div class="section-head"><h3>Beat actif</h3><span>${esc(b.name)}</span></div><div class="card">
 <audio id="beatAudio" controls src="${selectedBeatUrl}" ontimeupdate="beatTimeUpdate()"></audio>
 <div class="two-fields"><div class="field"><label>BPM</label><input id="beatBpm" type="number" min="55" max="200" value="${b.bpm||90}" onchange="updateBeatBpm(${b.id},this.value)"></div><div class="field"><label>Boucle</label><select id="loopBars"><option value="4">4 mesures</option><option value="8" selected>8 mesures</option><option value="16">16 mesures</option></select></div></div>
 <div class="row"><button class="btn purple" onclick="setLoop()">Boucler depuis la position</button><button class="btn" onclick="clearLoop()">Désactiver la boucle</button><button class="btn" onclick="tapTempoBeat()">Tap BPM</button></div><p id="loopInfo" class="small muted" style="margin-top:10px">Boucle désactivée</p></div>`;
 if(scroll)z.scrollIntoView({behavior:"smooth",block:"start"});
}
async function updateBeatBpm(id,v){const beats=await dbAll("beats"),b=beats.find(x=>x.id===id);if(!b)return;b.bpm=+v||90;await dbPut("beats",b);toast("BPM enregistré")}
function setLoop(){const a=$("#beatAudio"),bpm=+$("#beatBpm").value||90,bars=+$("#loopBars").value,start=a.currentTime,duration=bars*4*60/bpm;loopConfig={on:true,start,end:Math.min(a.duration||start+duration,start+duration)};$("#loopInfo").textContent=`Boucle : ${formatClock(start)} → ${formatClock(loopConfig.end)} (${bars} mesures)`}
function clearLoop(){loopConfig.on=false;if($("#loopInfo"))$("#loopInfo").textContent="Boucle désactivée"}
function beatTimeUpdate(){const a=$("#beatAudio");if(loopConfig.on&&a.currentTime>=loopConfig.end-.05)a.currentTime=loopConfig.start}
function formatClock(s){return `${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,"0")}`}
let beatTaps=[];
function tapTempoBeat(){const n=performance.now();beatTaps=beatTaps.filter(x=>n-x<2500);beatTaps.push(n);if(beatTaps.length<2)return toast("Tape encore");const g=beatTaps.slice(1).map((x,i)=>x-beatTaps[i]),b=Math.round(60000/(g.reduce((a,b)=>a+b,0)/g.length));$("#beatBpm").value=Math.max(55,Math.min(200,b));toast(`${$("#beatBpm").value} BPM estimés`)}
async function removeBeat(id){if(!confirm("Supprimer cette instrumentale ?"))return;await dbDelete("beats",id);if(selectedBeatId===id){selectedBeatId=null;$("#selectedBeat").innerHTML=""}loadBeatLibrary()}
async function toggleRecording(){
 if(mediaRecorder?.state==="recording"){mediaRecorder.stop();return}
 try{
  const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:false}});
  const opt={};if(MediaRecorder.isTypeSupported("audio/webm;codecs=opus"))opt.mimeType="audio/webm;codecs=opus";
  mediaRecorder=new MediaRecorder(stream,opt);recordChunks=[];
  mediaRecorder.ondataavailable=e=>{if(e.data.size)recordChunks.push(e.data)};
  mediaRecorder.onstop=async()=>{stream.getTracks().forEach(t=>t.stop());clearInterval(recordTicker);$("#wave")?.classList.remove("recording");$("#recordBtn").textContent="● Enregistrer";
   currentRecordBlob=new Blob(recordChunks,{type:mediaRecorder.mimeType||"audio/webm"});const name=`Prise ${new Date().toLocaleString("fr-FR",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"})}`;
   currentRecordId=await dbAdd("recordings",{name,blob:currentRecordBlob,type:currentRecordBlob.type,date:Date.now(),projectId:state.currentProjectId||null});
   const a=$("#lastRecordAudio");if(a){a.src=URL.createObjectURL(currentRecordBlob);a.classList.remove("hidden");$("#lastRecordActions").classList.remove("hidden")}
   state.stats.recordings++;state.stats.sessions++;addXp(15,"studio");save();};
  mediaRecorder.start();recordStart=Date.now();$("#wave").classList.add("recording");$("#recordBtn").textContent="■ Arrêter";
  recordTicker=setInterval(()=>{const s=Math.floor((Date.now()-recordStart)/1000);if($("#recordTimer"))$("#recordTimer").textContent=formatTime(s)},250);
 }catch(e){toast("Micro inaccessible. Autorise le microphone dans les réglages de l’application.")}
}
async function loadRecordings(){
 const box=$("#recordingsList");if(!box)return;let r=[];try{r=(await dbAll("recordings")).sort((a,b)=>b.date-a.date)}catch(e){}
 box.innerHTML=r.length?r.map(x=>`<div class="lesson"><div class="lesson-index">●</div><div><b>${esc(x.name)}</b><p class="small">${new Date(x.date).toLocaleString("fr-FR")}</p><audio controls src="${URL.createObjectURL(x.blob)}"></audio></div><div class="row"><button class="btn small" onclick="shareRecording(${x.id})">Partager</button><button class="btn small red" onclick="removeRecording(${x.id})">Suppr.</button></div></div>`).join(""):'<div class="empty">Aucune prise enregistrée.</div>';
}
async function shareRecording(id){const all=await dbAll("recordings"),x=all.find(v=>v.id===id);if(!x)return;shareBlob(x.blob,x.name)}
function shareCurrentRecord(){if(currentRecordBlob)shareBlob(currentRecordBlob,"prise-raplab")}
function shareBlob(blob,name){const ext=blob.type.includes("ogg")?"ogg":"webm",file=new File([blob],`${safeName(name)}.${ext}`,{type:blob.type});if(navigator.canShare?.({files:[file]}))navigator.share({title:name,files:[file]}).catch(()=>{});else downloadBlob(blob,file.name)}
async function renameCurrentRecord(){if(!currentRecordId)return;const all=await dbAll("recordings"),x=all.find(v=>v.id===currentRecordId),n=prompt("Nom de la prise :",x?.name||"Prise");if(n&&x){x.name=n;await dbPut("recordings",x);toast("Prise renommée")}}
async function removeRecording(id){if(!confirm("Supprimer cette prise ?"))return;await dbDelete("recordings",id);loadRecordings()}
function safeName(s){return s.normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9_-]+/gi,"_")}
function downloadBlob(blob,name){const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)}

function renderProfile(){
 const level=Math.floor(state.xp/100)+1,allBadges=BADGES.map(b=>({...b,ok:b.test(state)}));
 return `<section class="hero"><span class="eyebrow">Profil artistique</span><h1>${esc(state.profile.artistName||"Définis ton nom d’artiste")}</h1><p>${esc(state.profile.goal)}</p><div class="row"><span class="pill purple">Niveau ${level}</span><span class="pill">${esc(state.profile.level)}</span><span class="pill">🔥 ${state.streak} jours</span></div></section>
 <div class="section-head"><h3>Identité et objectif</h3><span>Programme adapté</span></div><div class="card">
 <div class="two-fields"><div class="field"><label>Nom d’artiste</label><input id="artistName" value="${escAttr(state.profile.artistName)}" placeholder="Ton blaze"></div><div class="field"><label>Niveau</label><select id="artistLevel">${["Débutant","Intermédiaire","Avancé"].map(x=>`<option ${state.profile.level===x?"selected":""}>${x}</option>`).join("")}</select></div></div>
 <div class="two-fields"><div class="field"><label>Style principal</label><select id="artistStyle">${["Boom bap","Trap","Drill","Mélodique","Afro","Cloud","Rap conscient","Old school"].map(x=>`<option ${state.profile.styles?.[0]===x?"selected":""}>${x}</option>`).join("")}</select></div><div class="field"><label>Minutes par jour</label><input id="dailyMinutes" type="number" min="5" max="180" value="${state.profile.dailyMinutes}"></div></div>
 <div class="field"><label>Objectif principal</label><input id="artistGoal" value="${escAttr(state.profile.goal)}"></div><button class="btn primary" onclick="saveProfile()">Enregistrer le profil</button></div>
 <div class="section-head"><h3>Statistiques</h3><span>Vue d’ensemble</span></div><div class="grid3">
 ${[["Sessions",state.stats.sessions],["Textes",state.stats.texts],["Mesures",state.stats.bars],["Freestyles",state.stats.freestyles],["Prises",state.stats.recordings],["Minutes",state.stats.minutes]].map(x=>`<div class="card"><span class="metric-label">${x[0]}</span><div class="metric">${x[1]}</div></div>`).join("")}</div>
 <div class="section-head"><h3>Compétences</h3><span>0 à 100</span></div><div class="card">${skillRows()}</div>
 <div class="section-head"><h3>Évolution</h3><span>Activité actuelle</span></div><div class="canvas-wrap"><canvas id="statsCanvas" width="700" height="260"></canvas></div>
 <div class="section-head"><h3>Badges</h3><span>${allBadges.filter(x=>x.ok).length}/${allBadges.length}</span></div><div class="badge-grid">${allBadges.map(b=>`<div class="badge ${b.ok?"":"locked"}"><b>${b.icon}</b><span>${esc(b.name)}</span></div>`).join("")}</div>
 <div class="section-head"><h3>Sauvegarde</h3><span>Données locales</span></div><div class="card"><p>Exporte ta progression, tes projets et tes textes. Les gros fichiers audio restent dans la bibliothèque locale et ne sont pas inclus dans le JSON.</p>
 <div class="row" style="margin-top:12px"><button class="btn" onclick="exportBackup()">Exporter</button><button class="btn" onclick="$('#backupPicker').click()">Importer</button><button class="btn red" onclick="resetApp()">Réinitialiser</button></div></div>
 <div class="section-head"><h3>À propos</h3></div><div class="card"><p><b>RapLab Pro 2.0 — Rap Academy</b><br>Application hors ligne. Les scores techniques servent à guider le travail, pas à juger la valeur artistique.</p></div>`;
}
function saveProfile(){state.profile.artistName=$("#artistName").value.trim();state.profile.level=$("#artistLevel").value;state.profile.styles=[$("#artistStyle").value];state.profile.dailyMinutes=+$("#dailyMinutes").value||20;state.profile.goal=$("#artistGoal").value.trim();save(true);toast("Profil enregistré")}
function drawStats(){
 const c=$("#statsCanvas");if(!c)return;const ctx=c.getContext("2d"),w=c.width,h=c.height;ctx.clearRect(0,0,w,h);
 const vals=Object.values(state.skills),labels=["Rythme","Écriture","Rimes","Flow","Diction","Freestyle","Souffle","Studio"],max=100,pad=38,barW=(w-pad*2)/vals.length*.62,gap=(w-pad*2)/vals.length;
 ctx.strokeStyle="rgba(255,255,255,.11)";ctx.fillStyle="#aaa6b3";ctx.font="12px sans-serif";
 for(let y=0;y<=4;y++){const py=20+(h-70)*y/4;ctx.beginPath();ctx.moveTo(pad,py);ctx.lineTo(w-pad,py);ctx.stroke()}
 vals.forEach((v,i)=>{const x=pad+i*gap+gap*.18,bh=(h-70)*v/max,y=h-50-bh;const grad=ctx.createLinearGradient(0,y,0,h-50);grad.addColorStop(0,"#ff3b6b");grad.addColorStop(1,"#8f5cff");ctx.fillStyle=grad;ctx.beginPath();ctx.roundRect(x,y,barW,bh,7);ctx.fill();ctx.fillStyle="#aaa6b3";ctx.save();ctx.translate(x+barW/2,h-30);ctx.rotate(-.45);ctx.textAlign="right";ctx.fillText(labels[i],0,0);ctx.restore()});
}
function unlockBadges(){state.badges=BADGES.filter(b=>b.test(state)).map(b=>b.id)}
function exportBackup(){
 const blob=new Blob([JSON.stringify({...state,exportedAt:new Date().toISOString()},null,2)],{type:"application/json"}),name=`raplab-pro-v2-${nowDate()}.json`,file=new File([blob],name,{type:"application/json"});
 if(navigator.canShare?.({files:[file]}))navigator.share({title:"Sauvegarde RapLab Pro",files:[file]}).catch(()=>{});else downloadBlob(blob,name);
}
function importBackup(e){const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{state=mergeState(JSON.parse(r.result));save(true);toast("Sauvegarde importée")}catch(err){toast("Fichier invalide")}};r.readAsText(f);e.target.value=""}
function resetApp(){if(!confirm("Effacer toute la progression, les textes et les projets ? Les fichiers audio devront être supprimés séparément."))return;localStorage.removeItem("raplab_v2_state");state=clone(DEFAULT_STATE);touchDay();go("home")}
function copyText(text){navigator.clipboard?.writeText(text).then(()=>toast("Copié")).catch(()=>{})}

touchDay();newFreestyle();renderRoute();
if("serviceWorker" in navigator&&location.protocol.startsWith("http"))window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
