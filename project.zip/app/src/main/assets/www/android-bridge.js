window.NativeAndroid = {
  available: function () { return typeof window.AndroidApp !== "undefined"; },
  toast: function (message) {
    if (this.available()) window.AndroidApp.showToast(String(message));
    else console.log(message);
  },
  share: async function (text) {
    if (this.available()) return window.AndroidApp.share(String(text));
    if (navigator.share) return navigator.share({text:String(text)});
  },
  copy: async function (text) {
    if (this.available()) return window.AndroidApp.copyText(String(text));
    return navigator.clipboard.writeText(String(text));
  },
  vibrate: function (milliseconds) {
    if (this.available()) return window.AndroidApp.vibrate(Number(milliseconds) || 100);
    if (navigator.vibrate) navigator.vibrate(Number(milliseconds) || 100);
  },
  openUrl: function (url) {
    if (this.available()) return window.AndroidApp.openUrl(String(url));
    window.open(String(url), "_blank", "noopener");
  },
  startBackgroundTask: function (title, message) {
    if (this.available() && window.AndroidApp.startBackgroundTask) {
      return window.AndroidApp.startBackgroundTask(String(title),String(message));
    }
  },
  updateBackgroundTask: function (message) {
    if (this.available() && window.AndroidApp.updateBackgroundTask) {
      return window.AndroidApp.updateBackgroundTask(String(message));
    }
  },
  getPermissionState: function () {
    try {
      if (this.available() && window.AndroidApp.getPermissionState) {
        return JSON.parse(window.AndroidApp.getPermissionState());
      }
    } catch (e) {}
    return {camera:false,microphone:false,notifications:false};
  },
  requestMediaPermissions: function () {
    if (this.available() && window.AndroidApp.requestMediaPermissions) {
      window.AndroidApp.requestMediaPermissions();
      return true;
    }
    return false;
  },
  openAppSettings: function () {
    if (this.available() && window.AndroidApp.openAppSettings) {
      window.AndroidApp.openAppSettings();
      return true;
    }
    return false;
  },
  finishBackgroundTask: function (message, success) {
    if (this.available() && window.AndroidApp.finishBackgroundTask) {
      return window.AndroidApp.finishBackgroundTask(String(message),!!success);
    }
  }
};
