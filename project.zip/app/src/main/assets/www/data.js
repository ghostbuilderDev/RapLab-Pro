
const ACADEMY_WEEKS = [
 {title:"Trouver le tempo",focus:"Rythme",desc:"Sentir les quatre temps et poser des syllabes sans courir.",
  lessons:[
   ["Pulsation 4/4","Tape les quatre temps avec la main pendant deux minutes."],
   ["Placement simple","Pose une syllabe forte sur chaque temps à 75 BPM."],
   ["Deux syllabes par temps","Alterner TA-ta sans accélérer."],
   ["Premier test","Enregistre huit mesures sur le métronome."]
  ]},
 {title:"Écrire 16 mesures",focus:"Écriture",desc:"Construire un couplet lisible, régulier et cohérent.",
  lessons:[
   ["Une idée centrale","Résume le couplet en une seule phrase."],
   ["Une mesure par ligne","Écris 16 lignes de longueur proche."],
   ["Respirations","Ajoute / aux endroits où reprendre de l’air."],
   ["Révision","Supprime les mots qui n’apportent rien."]
  ]},
 {title:"Construire les rimes",focus:"Rimes",desc:"Passer des rimes simples aux familles sonores.",
  lessons:[
   ["Rimes finales","Relie les fins de deux mesures successives."],
   ["Rimes internes","Ajoute un écho sonore au milieu de quatre lignes."],
   ["Assonances","Répète une voyelle dominante sans forcer le sens."],
   ["Multisyllabiques","Crée deux fins de phrases de plusieurs syllabes proches."]
  ]},
 {title:"Varier le flow",focus:"Flow",desc:"Utiliser silences, accélérations et accents.",
  lessons:[
   ["Accent déplacé","Accentue volontairement une syllabe faible."],
   ["Départ en retard","Commence la phrase après le premier temps."],
   ["Silence utile","Supprime des syllabes pour laisser respirer la mesure."],
   ["Double débit","Accélère seulement sur la fin de quatre mesures."]
  ]},
 {title:"Diction et précision",focus:"Diction",desc:"Rester compréhensible même lorsque le débit augmente.",
  lessons:[
   ["Consonnes","Exagère P, T, K, B, D et G pendant une minute."],
   ["Virelangue","Répète lentement, puis augmente le BPM."],
   ["Fins de mots","Ne mange pas les dernières consonnes."],
   ["Test 100 BPM","Lis huit mesures clairement à 100 BPM."]
  ]},
 {title:"Freestyle continu",focus:"Freestyle",desc:"Ne plus s’arrêter lorsque l’idée manque.",
  lessons:[
   ["Description","Décris ce qui est devant toi pendant 60 secondes."],
   ["Trois mots","Place trois mots imposés sans casser le rythme."],
   ["Reformulation","Répète une idée autrement plutôt que de t’arrêter."],
   ["Deux minutes","Tiens deux minutes avec un thème unique."]
  ]},
 {title:"Storytelling",focus:"Écriture",desc:"Faire vivre une scène et créer une progression.",
  lessons:[
   ["Le décor","Fais voir un lieu en quatre mesures."],
   ["Le personnage","Donne-lui un objectif et un défaut."],
   ["Le conflit","Ajoute une décision difficile."],
   ["La conséquence","Termine par une image qui reste en tête."]
  ]},
 {title:"Créer un refrain",focus:"Composition",desc:"Écrire une partie courte, claire et mémorisable.",
  lessons:[
   ["Phrase centrale","Trouve une phrase que l’on retient après une écoute."],
   ["Répétition","Répète-la avec une légère variation."],
   ["Contraste","Oppose le refrain au couplet en rythme ou en énergie."],
   ["Test mémoire","Écoute deux fois puis récite sans regarder."]
  ]},
 {title:"Interprétation",focus:"Voix",desc:"Donner une intention précise à chaque partie.",
  lessons:[
   ["Mots importants","Souligne les mots qui portent le sens."],
   ["Trois émotions","Enregistre calme, colère maîtrisée et détermination."],
   ["Volumes","Alterne proximité et projection."],
   ["Silences","Laisse vivre la dernière phrase avant de repartir."]
  ]},
 {title:"Studio mobile",focus:"Studio",desc:"Faire des prises propres et comparables.",
  lessons:[
   ["Préparation","Coupe les bruits et place le téléphone correctement."],
   ["Prise énergie","Enregistre sans chercher la perfection."],
   ["Prise précision","Recommence en soignant diction et placement."],
   ["Comparaison","Choisis une force à garder et un défaut à corriger."]
  ]},
 {title:"Construire un morceau",focus:"Projet",desc:"Assembler couplets, refrain, transitions et dynamique.",
  lessons:[
   ["Structure","Place intro, couplet, refrain, couplet et outro."],
   ["Progression","Chaque partie doit apporter une information nouvelle."],
   ["Transitions","Prépare les changements d’énergie."],
   ["Maquette","Enregistre une version complète sans couper."]
  ]},
 {title:"Projet final",focus:"Performance",desc:"Finaliser une démo et présenter son identité artistique.",
  lessons:[
   ["Réécriture finale","Coupe tout ce qui affaiblit le morceau."],
   ["Prise complète","Réalise au moins trois versions."],
   ["Présentation","Explique le thème et l’intention en trente secondes."],
   ["Bilan","Choisis trois progrès et le prochain objectif."]
  ]}
];

const FLOW_DRILLS = [
 ["Fondations","TA — TA — TA — TA —","Une syllabe exactement sur chaque pulsation."],
 ["Croches","TA ta — TA ta — TA ta — TA ta —","Deux syllabes par temps, la première plus forte."],
 ["Triolets","TA ta ta | TA ta ta | TA ta ta | TA ta ta","Trois syllabes régulières dans chaque groupe."],
 ["Contretemps","— ta TA ta | — ta TA ta","Commence après le temps et garde le silence initial."],
 ["Débit variable","TA ta-ta TA | ta — ta TA","Alterne débit rapide, espace et accents."],
 ["Double-croches","1 e & a | 2 — & a | 3 e — a | 4 e & —","Choisis précisément les positions occupées."]
];

const DICTION_EXERCISES = [
 ["Les consonnes sèches","Papa prépare peu à peu plusieurs plans précis.","Accentue chaque P sans serrer la mâchoire."],
 ["Le train des T","Trois très grands trains traversent trente tunnels.","Commence à 65 BPM puis monte de cinq BPM."],
 ["K et G","Quelques grands gars gardent quatre grosses caisses.","Garde chaque mot compréhensible."],
 ["S et CH","Six chanteurs cherchent chacun une chance sur scène.","Ne confonds pas les deux sons."],
 ["Fins de mots","Je prends le temps, je tends le plan, j’attends le moment.","Prononce clairement les consonnes finales."],
 ["Débit contrôlé","La vitesse ne vaut rien si le message disparaît.","Accélère sans avaler les mots."]
];

const FREESTYLE_TOPICS = [
 "Le dernier train de la nuit","Une ville qui ne dort jamais","Un message reçu du futur",
 "Le jour où tout a basculé","Une victoire que personne n’a vue","La pièce au fond du couloir",
 "Une promesse impossible","Le choix entre confort et liberté","Une journée sans écran",
 "Le bruit derrière le silence","La première scène","Le monde vu par un enfant"
];
const FREESTYLE_WORDS = [
 ["phare","béton","demain"],["miroir","orage","distance"],["signal","couronne","retard"],
 ["clé","fumée","mémoire"],["silence","moteur","vertige"],["verre","racine","vitesse"],
 ["horizon","cicatrice","lumière"],["montre","terrain","preuve"],["pluie","réseau","chance"]
];
const FREESTYLE_EMOTIONS = ["détermination","nostalgie","calme froid","urgence","espoir","ironie","fierté","colère maîtrisée"];

const RHYME_FAMILIES = {
 "eur":["cœur","peur","heure","fleur","chaleur","douleur","couleur","valeur","honneur","erreur","moteur","lueur","rêveur","meilleur","intérieur","extérieur"],
 "iere":["lumière","poussière","rivière","prière","frontière","matière","manière","derrière","première","dernière","carrière","barrière","solitaire"],
 "ance":["chance","distance","silence","violence","puissance","présence","absence","confiance","résistance","élégance","importance","avance"],
 "ique":["musique","unique","critique","public","mythique","magnifique","tragique","logique","pratique","électrique","artistique","politique"],
 "on":["maison","raison","saison","prison","vision","mission","frisson","horizon","poison","façon","garçon","leçon","son","nom"],
 "oir":["miroir","espoir","soir","couloir","pouvoir","savoir","devoir","mémoire","histoire","victoire","territoire","auditoire"],
 "age":["courage","visage","orage","voyage","message","passage","virage","mirage","image","partage","décalage","héritage"],
 "ite":["vite","suite","limite","élite","réussite","fuite","conduite","gratuite","petite","écrite","visite","mérite"],
 "ain":["demain","chemin","matin","terrain","destin","lointain","certain","humain","main","refrain","train","soudain"],
 "ame":["âme","flamme","drame","femme","programme","gramme","panorama","trame","lame","réclame"],
 "air":["air","clair","éclair","affaire","contraire","solitaire","nécessaire","imaginaire","populaire","vocabulaire","lumière"],
 "i":["vie","nuit","pluie","bruit","ennui","appui","produit","construit","poursuit","aujourd’hui","esprit"],
 "o":["mot","écho","niveau","réseau","tempo","micro","studio","héros","métro","photo","chaos","zéro"],
 "ar":["regard","départ","retard","hasard","rempart","brouillard","quelque part","art","gare","mémoire"],
 "ene":["scène","peine","reine","chaîne","haleine","semaine","humaine","lointaine","souterraine"],
 "oue":["route","doute","coûte","écoute","goutte","déroute","redoute","ajoute","bout","debout"],
 "asse":["trace","place","face","glace","espace","menace","audace","surface","efface","passe"],
 "if":["vif","actif","motif","objectif","collectif","positif","sportif","créatif","décisif"],
 "able":["capable","stable","coupable","incroyable","improbable","durable","inoubliable","redoutable"],
 "ment":["moment","mouvement","sentiment","changement","bâtiment","jugement","entraînement","vraiment","lentement"]
};

const WRITING_PROMPTS = [
 "Raconte une nuit où tu as dû choisir entre deux chemins.",
 "Décris ta ville comme si elle était une personne.",
 "Écris sur une victoire que personne n’a remarquée.",
 "Transforme une peur en moteur sans utiliser le mot peur.",
 "Oppose la version de toi d’hier à celle de demain.",
 "Raconte une scène depuis le point de vue de ton téléphone.",
 "Écris huit mesures autour du mot frontière.",
 "Décris un silence plus bruyant qu’une foule.",
 "Écris un refrain autour d’une phrase que tout le monde peut retenir."
];

const BADGES = [
 {id:"first_text",icon:"✍️",name:"Premier texte",test:s=>s.stats.texts>=1},
 {id:"week1",icon:"▤",name:"Semaine validée",test:s=>completedWeeks(s)>=1},
 {id:"streak7",icon:"🔥",name:"7 jours",test:s=>s.streak>=7},
 {id:"free5",icon:"⚡",name:"5 freestyles",test:s=>s.stats.freestyles>=5},
 {id:"studio3",icon:"🎙️",name:"3 prises",test:s=>s.stats.recordings>=3},
 {id:"project1",icon:"💿",name:"Premier projet",test:s=>s.projects.length>=1},
 {id:"xp500",icon:"★",name:"500 XP",test:s=>s.xp>=500},
 {id:"bars100",icon:"▥",name:"100 mesures",test:s=>s.stats.bars>=100},
 {id:"breath10",icon:"◯",name:"Souffle maîtrisé",test:s=>s.stats.breathSessions>=10}
];
