RAPLAB AI START V23

Nouveautés :
- tutoriel vocal guidé en 6 étapes ;
- surlignage de la zone à utiliser ;
- lecture par voix française du téléphone hors connexion selon Android ;
- studio permettant d’enregistrer la voix du créateur pour chaque étape ;
- enregistrements vocaux conservés localement dans IndexedDB ;
- aucune voix envoyée sur Internet.

Pour HTMLtoAPK : conserver JavaScript, IndexedDB, MediaRecorder, Web Speech API et getUserMedia.
