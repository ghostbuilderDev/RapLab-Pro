"use strict";

/* =====================================================
   RapLab Pro 3.0 — Expert Rap System
   Extension chargée après app.js et v25.js
   ===================================================== */

const V3_VERSION = "3.0";
const V3_oldRenderHome = renderHome;
const V3_oldRenderProfile = renderProfile;
const V3_oldAfterRender = afterRender;
const V3_oldMergeState = mergeState;

const V3_EXPERT_MODULES = [
  {id:"pocket",icon:"◫",title:"Pocket & microtiming",focus:"Rythme",desc:"Apprendre à rapper légèrement devant, sur ou derrière le temps sans perdre le groove.",drills:["Même texte sur le temps, puis légèrement derrière","Déplacer seulement les fins de phrases","Comparer trois prises au même BPM","Noter la position qui correspond le mieux à ton identité"]},
  {id:"cadence",icon:"⌁",title:"Cadences avancées",focus:"Flow",desc:"Construire des cellules rythmiques mémorables et les transformer sans perdre le motif.",drills:["Créer une cellule de deux temps","La répéter sur quatre mesures","Modifier la dernière cellule","Passer en double-time puis revenir au motif"]},
  {id:"poly",icon:"Ⅲ",title:"Triolets & polymétrie",focus:"Rythme",desc:"Maîtriser les triolets, les groupes de trois sur quatre temps et les décalages contrôlés.",drills:["Triolets à 70 BPM","Accent toutes les deux syllabes","Groupe de trois sur une grille à quatre temps","Résolution nette au premier temps suivant"]},
  {id:"multis",icon:"≋",title:"Rimes multisyllabiques",focus:"Rimes",desc:"Créer des chaînes sonores longues sans sacrifier la cohérence du texte.",drills:["Choisir une phrase de trois à cinq syllabes","Trouver cinq équivalents phonétiques","Écrire quatre mesures avec rimes internes","Changer le sens tout en gardant la chaîne"]},
  {id:"density",icon:"▦",title:"Densité & respiration",focus:"Écriture",desc:"Contrôler le nombre de syllabes, les accents et les reprises d’air selon l’intention.",drills:["Mesurer la densité de huit lignes","Marquer les respirations","Retirer 15 % des mots","Réenregistrer avec davantage d’espace"]},
  {id:"story",icon:"◈",title:"Storytelling cinématographique",focus:"Écriture",desc:"Écrire des scènes visibles avec tension, changement et conséquence.",drills:["Ouvrir sur une image concrète","Installer un objectif","Créer un point de rupture","Terminer par une image miroir"]},
  {id:"hook",icon:"∞",title:"Hooks professionnels",focus:"Composition",desc:"Tester la mémorisation, le contraste et la répétition d’un refrain.",drills:["Résumer le morceau en une phrase","Créer trois variantes de six mots maximum","Tester sans regarder après deux écoutes","Choisir la version la plus facile à retenir"]},
  {id:"delivery",icon:"◆",title:"Delivery & identité vocale",focus:"Voix",desc:"Développer une signature avec timbre, accents, articulation et niveaux d’énergie.",drills:["Prise calme et proche","Prise projetée et agressive","Prise avec accents minimaux","Construire un preset personnel à partir des meilleures qualités"]},
  {id:"adlibs",icon:"✦",title:"Doublages & ad-libs",focus:"Studio",desc:"Renforcer une prise sans masquer la voix principale.",drills:["Doubler seulement les mots forts","Créer des réponses en fin de mesure","Panoramiquer les ad-libs","Comparer avec et sans couches"]},
  {id:"arrangement",icon:"▤",title:"Arrangement dynamique",focus:"Projet",desc:"Faire évoluer le morceau et éviter la monotonie entre les sections.",drills:["Tracer l’énergie de chaque partie","Retirer un élément avant le refrain","Créer une transition sonore","Vérifier qu’une information nouvelle arrive à chaque section"]},
  {id:"stage",icon:"◎",title:"Présence scénique",focus:"Performance",desc:"Mémorisation, regard, respiration et contrôle de l’espace.",drills:["Interpréter sans regarder le texte","Fixer trois zones de regard","Prévoir une récupération après un trou de mémoire","Filmer une performance complète"]},
  {id:"portfolio",icon:"★",title:"Démo professionnelle",focus:"Carrière",desc:"Finaliser un mini-portfolio cohérent de trois morceaux.",drills:["Choisir trois titres complémentaires","Réviser textes et structures","Produire une maquette claire de chaque morceau","Rédiger une présentation artistique courte"]}
];

const V3_EAR_PATTERNS = [
  {id:"straight",label:"Croches droites",steps:[0,2,4,6,8,10,12,14],accent:[0,8]},
  {id:"sync",label:"Syncopes",steps:[0,3,6,8,11,14],accent:[0,8]},
  {id:"triplet",label:"Triolets",steps:[0,2,5,8,10,13],accent:[0,8]},
  {id:"sparse",label:"Flow aéré",steps:[0,5,8,12,15],accent:[0,8]},
  {id:"double",label:"Double-time",steps:[0,1,2,3,4,6,8,9,10,11,12,14],accent:[0,8]}
];

const V3_PUNCH_TEMPLATES = [
  "On me disait {LIMIT}, maintenant {REVERSAL}",
  "Je ne cherche pas {OBJECT}, je construis {REVERSAL}",
  "Ils voient {IMAGE}, ils ignorent {DEPTH}",
  "J’ai transformé {LIMIT} en {OBJECT}",
  "Tu comptes {OBJECT}, moi je mesure {DEPTH}",
  "Même {IMAGE} finit par refléter {REVERSAL}"
];

let V3_currentEar = null;
let V3_earAudio = null;
let V3_gridTimer = null;
let V3_gridStep = 0;
let V3_beatUrls = new Map();
let V3_lastBeatSave = 0;
let V3_beatFilter = {query:"",favorite:false,collection:"Toutes",style:"Tous"};

function v3Ensure(s){
  s.version = 3;
  s.expert ||= {completed:{},score:0,rank:"Apprenti",sessions:0};
  s.flowPatterns ||= [];
  s.beatCollections ||= ["Entraînement","Projets","Freestyle","Références"];
  s.expertLogs ||= [];
  s.storyMaps ||= [];
  s.punchlines ||= [];
  s.settings ||= {};
  s.settings.gridBpm ||= 90;
  s.settings.gridSwing ??= 0;
  s.stats ||= {};
  for(const k of ["expertSessions","earDrills","patterns","beatsImported","beatAnalyses","punchlines","storyMaps"]){
    if(typeof s.stats[k]!=="number")s.stats[k]=0;
  }
  return s;
}

mergeState = function(x){return v3Ensure(V3_oldMergeState(x));};
v3Ensure(state);
save();

/* Database v4: beats and all media stay in persistent IndexedDB. */
db = function(){
  return new Promise((resolve,reject)=>{
    const r=indexedDB.open("raplab_v2_db",4);
    r.onupgradeneeded=()=>{
      const d=r.result;
      if(!d.objectStoreNames.contains("recordings"))d.createObjectStore("recordings",{keyPath:"id",autoIncrement:true});
      if(!d.objectStoreNames.contains("beats"))d.createObjectStore("beats",{keyPath:"id",autoIncrement:true});
      if(!d.objectStoreNames.contains("performances"))d.createObjectStore("performances",{keyPath:"id",autoIncrement:true});
      if(!d.objectStoreNames.contains("expertSessions"))d.createObjectStore("expertSessions",{keyPath:"id",autoIncrement:true});
    };
    r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);
  });
};

function v3ExpertDone(){return Object.values(state.expert.completed||{}).filter(Boolean).length;}
function v3Rank(){
  const n=v3ExpertDone();
  return n>=48?"Artiste confirmé":n>=36?"Expert":n>=24?"Technicien":n>=12?"Intermédiaire +":"Apprenti";
}
function v3UpdateRank(){state.expert.rank=v3Rank();state.expert.score=Math.round(v3ExpertDone()/48*100);}

const V3_oldGo = go;
go = function(r){v3StopGrid();V3_oldGo(r);};

renderHome = function(){
  v3UpdateRank();
  return V3_oldRenderHome()+`
  <div class="section-head"><h2>Expert System 3.0</h2><span>${esc(state.expert.rank)} · ${state.expert.score}%</span></div>
  <div class="grid">
    <div class="card project-card expert-glow" onclick="route='academy';sub.academy='expert';renderRoute()"><span class="pill purple">V3</span><h3 style="margin-top:9px">Expert Academy</h3><p>12 modules de maîtrise : pocket, cadences, multisyllabiques, delivery, arrangement et scène.</p></div>
    <div class="card project-card" onclick="route='studio';sub.studio='beats';renderRoute()"><span class="pill good">Mémoire permanente</span><h3 style="margin-top:9px">Beat Vault</h3><p>Importe plusieurs beats et conserve fichiers, BPM, tonalité, tags, favoris et position de lecture.</p></div>
    <div class="card project-card" onclick="route='academy';sub.academy='flowgrid';renderRoute()"><h3>Flow Architect</h3><p>Compose des cellules sur une grille 16 pas, ajoute les accents et sauvegarde tes patterns.</p></div>
    <div class="card project-card" onclick="route='academy';sub.academy='ear';renderRoute()"><h3>Ear Training</h3><p>Reconnais croches, syncopes, triolets, flow aéré et double-time à l’oreille.</p></div>
  </div>
  <div class="section-head"><h2>Séance experte</h2><span>Générée selon tes compétences</span></div>
  <div class="card">${v3DailyExpertPlanHtml()}<button class="btn primary" style="margin-top:13px" onclick="v3StartExpertSession()">Lancer cette séance</button></div>`;
};

function v3DailyExpertPlan(){
  const skillMap={rythme:"pocket",flow:"cadence",rimes:"multis",ecriture:"density",diction:"delivery",freestyle:"story",souffle:"density",studio:"adlibs"};
  const weak=Object.entries(state.skills).sort((a,b)=>a[1]-b[1])[0][0];
  const module=V3_EXPERT_MODULES.find(m=>m.id===skillMap[weak])||V3_EXPERT_MODULES[0];
  return {weak,module,steps:[module.drills[0],module.drills[1],"Enregistrer ou analyser une prise de référence","Noter une correction précise pour la prochaine séance"]};
}
function v3DailyExpertPlanHtml(){
  const p=v3DailyExpertPlan();
  return `<div class="row"><div class="expert-medal">${p.module.icon}</div><div><b>Priorité : ${esc(p.module.title)}</b><p class="small">${esc(p.module.desc)}</p></div></div><div class="expert-plan">${p.steps.map((x,i)=>`<div><span>${i+1}</span>${esc(x)}</div>`).join("")}</div>`;
}
async function v3StartExpertSession(){
  const p=v3DailyExpertPlan();
  const entry={date:Date.now(),moduleId:p.module.id,steps:p.steps,completed:false};
  try{entry.id=await dbAdd("expertSessions",entry);}catch(e){}
  state.expert.sessions++;state.stats.expertSessions++;state.stats.sessions++;state.stats.minutes+=20;state.expertLogs.unshift(entry);state.expertLogs=state.expertLogs.slice(0,60);addXp(15,p.weak);save();
  route="academy";sub.academy="expert";renderRoute();toast("Séance experte lancée");
}

renderAcademy = function(){
  const t=tabs("academy",[["program","Programme"],["expert","Expert"],["flow","Flow"],["flowgrid","Flow Grid"],["ear","Oreille"],["technique","Technique"],["diction","Diction"],["souffle","Souffle"],["freestyle","Freestyle"],["battle","Battle"]]);
  let body="";
  if(sub.academy==="program")body=renderProgram();
  else if(sub.academy==="expert")body=v3RenderExpertAcademy();
  else if(sub.academy==="flow")body=renderFlowLab();
  else if(sub.academy==="flowgrid")body=v3RenderFlowGrid();
  else if(sub.academy==="ear")body=v3RenderEarTraining();
  else if(sub.academy==="technique")body=v3RenderTechniqueLab();
  else if(sub.academy==="diction")body=renderDiction();
  else if(sub.academy==="souffle")body=renderBreath();
  else if(sub.academy==="freestyle")body=renderFreestyle();
  else body=v25RenderBattle();
  return `<div class="section-head"><h2>Rap Academy 3.0</h2><span>Fondations jusqu’au niveau expert</span></div>${t}${body}`;
};

function v3RenderExpertAcademy(){
  v3UpdateRank();
  return `<div class="hero expert-hero"><span class="eyebrow">Parcours expert</span><h1>${esc(state.expert.rank)}</h1><p>Chaque module contient quatre validations pratiques. Les scores servent à organiser ton travail, jamais à limiter ton style.</p><div class="progress green"><i style="width:${state.expert.score}%"></i></div><p class="small">${v3ExpertDone()}/48 validations</p></div>
  <div class="section-head"><h3>Modules de maîtrise</h3><span>+12 XP par exercice</span></div>
  <div class="grid">${V3_EXPERT_MODULES.map(v3ExpertModuleCard).join("")}</div>`;
}
function v3ExpertModuleCard(m){
  const done=m.drills.filter((_,i)=>state.expert.completed[`${m.id}-${i}`]).length;
  return `<div class="card expert-module"><div class="row between"><div class="expert-medal">${m.icon}</div><span class="pill">${esc(m.focus)}</span></div><h3>${esc(m.title)}</h3><p>${esc(m.desc)}</p><div class="progress" style="margin:12px 0"><i style="width:${done/4*100}%"></i></div>${m.drills.map((d,i)=>`<div class="expert-drill"><button class="check ${state.expert.completed[`${m.id}-${i}`]?"done":""}" onclick="v3CompleteExpert('${m.id}',${i})">✓</button><span>${esc(d)}</span></div>`).join("")}</div>`;
}
function v3CompleteExpert(id,i){
  const key=`${id}-${i}`;if(state.expert.completed[key])return toast("Exercice déjà validé");
  state.expert.completed[key]=true;state.stats.expertSessions++;state.stats.sessions++;state.stats.minutes+=8;
  const m=V3_EXPERT_MODULES.find(x=>x.id===id),skill={Rythme:"rythme",Flow:"flow",Rimes:"rimes",Écriture:"ecriture",Voix:"diction",Studio:"studio",Performance:"studio",Composition:"ecriture",Projet:"ecriture",Carrière:"studio"}[m.focus]||"flow";
  v3UpdateRank();addXp(12,skill);save(true);
}

/* ================= Flow Architect ================= */
function v3DefaultPattern(){return {id:uid(),name:"Nouveau pattern",steps:[1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0],accents:[1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0],syllables:"TA . . . TA . . . TA . . . TA . . .",bpm:state.settings.gridBpm||90,swing:state.settings.gridSwing||0};}
function v3RenderFlowGrid(){
  const p=state.activeFlowPattern||v3DefaultPattern();state.activeFlowPattern=p;
  return `<div class="hero"><span class="eyebrow">Flow Architect</span><h1>Écris le rythme avant les mots.</h1><p>Active les 16 positions, ajoute des accents puis remplace les sons par ton texte.</p></div>
  <div class="card">
   <div class="two-fields"><div class="field"><label>Nom</label><input id="gridName" value="${escAttr(p.name)}"></div><div class="field"><label>BPM</label><input id="gridBpm" type="number" min="50" max="200" value="${p.bpm}" onchange="state.activeFlowPattern.bpm=+this.value;state.settings.gridBpm=+this.value;save()"></div></div>
   <div class="field"><label>Swing : <span id="swingValue">${p.swing}%</span></label><input id="gridSwing" type="range" min="0" max="60" value="${p.swing}" oninput="state.activeFlowPattern.swing=+this.value;state.settings.gridSwing=+this.value;$('#swingValue').textContent=this.value+'%';save()"></div>
   <div class="flow-grid" id="flowGrid">${p.steps.map((on,i)=>`<button class="grid-step ${on?"on":""} ${p.accents[i]?"accent":""}" onclick="v3ToggleGridStep(${i})"><b>${i+1}</b><small>${i%4===0?Math.floor(i/4)+1:"·"}</small></button>`).join("")}</div>
   <div class="field"><label>Syllabes / sons (16 éléments séparés par des espaces)</label><input id="gridSyllables" value="${escAttr(p.syllables)}" placeholder="TA . ta . TA . . ."></div>
   <div class="row"><button id="gridPlayBtn" class="btn primary" onclick="v3ToggleGridPlay()">▶ Lire</button><button class="btn" onclick="v3AccentMode()">Accentuer le prochain pas</button><button class="btn purple" onclick="v3SavePattern()">Sauvegarder</button><button class="btn" onclick="v3ClearPattern()">Effacer</button></div>
  </div>
  <div class="section-head"><h3>Patterns mémorisés</h3><span>${state.flowPatterns.length}</span></div>
  <div class="card">${state.flowPatterns.length?state.flowPatterns.map(p=>`<div class="lesson"><div class="lesson-index">≋</div><div><b>${esc(p.name)}</b><p class="small">${p.bpm} BPM · swing ${p.swing}%</p></div><div class="row"><button class="btn small" onclick="v3LoadPattern('${p.id}')">Ouvrir</button><button class="btn small red" onclick="v3DeletePattern('${p.id}')">Suppr.</button></div></div>`).join(""):'<div class="empty">Aucun pattern sauvegardé.</div>'}</div>`;
}
let V3_accentNext=false;
function v3ToggleGridStep(i){
  const p=state.activeFlowPattern;if(V3_accentNext){p.accents[i]=p.accents[i]?0:1;V3_accentNext=false;}else p.steps[i]=p.steps[i]?0:1;save(true);
}
function v3AccentMode(){V3_accentNext=true;toast("Appuie sur un pas pour activer ou retirer son accent");}
function v3ClearPattern(){const p=state.activeFlowPattern;p.steps=p.steps.map(()=>0);p.accents=p.accents.map(()=>0);save(true);}
function v3SavePattern(){
  const p=clone(state.activeFlowPattern);p.name=$("#gridName").value.trim()||"Pattern";p.syllables=$("#gridSyllables").value.trim();p.bpm=+$("#gridBpm").value||90;p.swing=+$("#gridSwing").value||0;
  const old=state.flowPatterns.find(x=>x.id===p.id);if(old)Object.assign(old,p);else state.flowPatterns.unshift(p);state.stats.patterns++;addXp(10,"flow");save(true);toast("Pattern mémorisé");
}
function v3LoadPattern(id){state.activeFlowPattern=clone(state.flowPatterns.find(x=>x.id===id));save(true);}
function v3DeletePattern(id){state.flowPatterns=state.flowPatterns.filter(x=>x.id!==id);if(state.activeFlowPattern?.id===id)state.activeFlowPattern=v3DefaultPattern();save(true);}
function v3ToggleGridPlay(){V3_gridTimer?v3StopGrid():v3StartGrid();}
function v3StartGrid(){
  const p=state.activeFlowPattern,bpm=+$("#gridBpm").value||90,interval=60000/bpm/4;audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();audioCtx.resume();V3_gridStep=0;$("#gridPlayBtn").textContent="■ Arrêter";
  const tick=()=>{const i=V3_gridStep%16;$$('.grid-step').forEach((x,j)=>x.classList.toggle('playing',j===i));if(p.steps[i])v3GridClick(p.accents[i]?1150:720);V3_gridStep++;const swing=(i%2?p.swing:0)/100*interval*.5;V3_gridTimer=setTimeout(tick,interval+swing)};tick();
}
function v3GridClick(freq){const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.frequency.value=freq;g.gain.setValueAtTime(.15,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+.055);o.connect(g).connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+.06);}
function v3StopGrid(){clearTimeout(V3_gridTimer);V3_gridTimer=null;$$('.grid-step').forEach(x=>x.classList.remove('playing'));if($("#gridPlayBtn"))$("#gridPlayBtn").textContent="▶ Lire";}

/* ================= Ear Training ================= */
function v3RenderEarTraining(){
  if(!V3_currentEar)V3_currentEar=V3_EAR_PATTERNS[Math.floor(Math.random()*V3_EAR_PATTERNS.length)];
  return `<div class="hero"><span class="eyebrow">Ear Training</span><h1>Reconnais le placement avant de l’écrire.</h1><p>Écoute le motif, identifie la famille rythmique puis vérifie la réponse.</p></div>
  <div class="card ear-card"><div class="ear-icon">♫</div><div id="earFeedback" class="prompt">Motif prêt</div><div class="row" style="justify-content:center"><button class="btn primary" onclick="v3PlayEarPattern()">▶ Écouter</button><button class="btn" onclick="v3NewEar()">Nouveau motif</button></div>
  <div class="ear-choices">${V3_EAR_PATTERNS.map(p=>`<button class="btn" onclick="v3AnswerEar('${p.id}')">${esc(p.label)}</button>`).join("")}</div></div>
  <div class="section-head"><h3>Méthode d’écoute</h3><span>${state.stats.earDrills} exercice(s)</span></div><div class="card"><p>Repère d’abord le premier temps, puis demande-toi si les attaques tombent régulièrement, par groupes de trois, entre les temps ou en rafale. Tape le motif avec la main avant de répondre.</p></div>`;
}
function v3NewEar(){V3_currentEar=V3_EAR_PATTERNS[Math.floor(Math.random()*V3_EAR_PATTERNS.length)];if($("#earFeedback"))$("#earFeedback").textContent="Nouveau motif prêt";}
function v3PlayEarPattern(){
  audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();audioCtx.resume();const bpm=82,step=60/bpm/4,start=audioCtx.currentTime+.15;
  for(let bar=0;bar<2;bar++)V3_currentEar.steps.forEach(i=>{const t=start+(bar*16+i)*step,o=audioCtx.createOscillator(),g=audioCtx.createGain();o.frequency.value=V3_currentEar.accent.includes(i)?980:630;g.gain.setValueAtTime(.12,t);g.gain.exponentialRampToValueAtTime(.001,t+.05);o.connect(g).connect(audioCtx.destination);o.start(t);o.stop(t+.055)});
}
function v3AnswerEar(id){const ok=id===V3_currentEar.id;state.stats.earDrills++;state.stats.sessions++;state.stats.minutes+=1;if(ok){addXp(8,"rythme");$("#earFeedback").textContent=`Correct : ${V3_currentEar.label}`;}else $("#earFeedback").textContent=`Réponse : ${V3_currentEar.label}. Réécoute et tape le motif.`;save();}

/* ================= Technique Lab ================= */
function v3RenderTechniqueLab(){
  return `<div class="hero"><span class="eyebrow">Technique Lab</span><h1>Analyse la mécanique de ton couplet.</h1><p>Densité, respirations, schéma de rimes et chaînes multisyllabiques.</p></div>
  <div class="card"><div class="field"><label>Texte à disséquer</label><textarea id="techText" style="min-height:260px" placeholder="Une mesure par ligne..."></textarea></div><div class="two-fields"><div class="field"><label>Syllabes avant respiration</label><input id="breathTarget" type="number" min="6" max="30" value="16"></div><div class="field"><label>Famille sonore cible</label><input id="multiTarget" placeholder="Ex. lumière / manière"></div></div><div class="row"><button class="btn primary" onclick="v3AnalyzeTechnique()">Analyser</button><button class="btn" onclick="v3BuildMultiChain()">Créer une chaîne</button></div></div><div id="techResult"></div>`;
}
function v3AnalyzeTechnique(){
  const text=$("#techText").value.trim();if(!text)return toast("Ajoute un texte");const lines=text.split("\n").map(x=>x.trim()).filter(Boolean),target=+$("#breathTarget").value||16;
  const s=lines.map(syllables),avg=s.reduce((a,b)=>a+b,0)/s.length,dense=s.filter(x=>x>target).length,ends=lines.map(ending),groups={};ends.forEach(x=>groups[x]=(groups[x]||0)+1);
  const scheme={};let letter=65;ends.forEach(e=>{if(!scheme[e])scheme[e]=String.fromCharCode(letter++);});
  const marked=lines.map((line,i)=>`${scheme[ends[i]]} · ${s[i]} syl. ${s[i]>target?"⚠ respiration":"✓"} — ${line}`).join("\n");
  const internal=lines.reduce((n,line)=>{const words=line.split(/\s+/).map(norm);const tails=words.map(w=>w.slice(-2));return n+tails.filter((x,i)=>tails.indexOf(x)!==i).length},0);
  $("#techResult").innerHTML=`<div class="section-head"><h3>Rapport expert</h3><span>Schéma ${ends.map(e=>scheme[e]).join("")}</span></div><div class="card"><div class="analysis-grid"><div class="analysis-cell"><b>${avg.toFixed(1)}</b><small>Syllabes moy.</small></div><div class="analysis-cell"><b>${dense}</b><small>Lignes denses</small></div><div class="analysis-cell"><b>${Object.values(groups).filter(x=>x>=2).length}</b><small>Familles liées</small></div><div class="analysis-cell"><b>${internal}</b><small>Échos internes</small></div></div><div class="rhyme-preview" style="margin-top:12px">${esc(marked)}</div><div class="advice">${dense?`Allège ${dense} ligne(s) ou place une respiration interne.`:"La densité est respirable. Travaille maintenant les accents et le contraste entre les lignes."}</div></div>`;
  addXp(8,"ecriture");
}
function v3BuildMultiChain(){
  const raw=$("#multiTarget").value.trim()||"lumière",words=raw.split(/[\s/]+/).filter(Boolean),last=words.at(-1),e=ending(last),family=RHYME_FAMILIES[e]||Object.values(RHYME_FAMILIES).find(a=>a.some(w=>norm(w).slice(-2)===norm(last).slice(-2)))||[];
  const starters=["changer de","marcher dans","garder la","revenir en","chercher la","traverser la"];
  const chain=family.slice(0,10).map((w,i)=>`${starters[i%starters.length]} ${w}`);
  $("#techResult").innerHTML=`<div class="section-head"><h3>Chaîne multisyllabique</h3><span>Point de départ : ${esc(raw)}</span></div><div class="card"><div class="word-cloud">${chain.map(x=>`<button class="word" onclick="copyWord('${escAttr(x)}')">${esc(x)}</button>`).join("")||"<p>Essaie une fin plus courante pour obtenir davantage de propositions.</p>"}</div></div>`;
}

/* ================= Create: Punchline and Story ================= */
renderCreate = function(){
  const t=tabs("create",[["projects","Projets"],["write","Écriture"],["rhymes","Rimes"],["refrain","Refrain"],["punch","Punchlines"],["story","Story Map"],["notes","Carnet"]]);
  let body="";
  if(sub.create==="projects")body=renderProjects();else if(sub.create==="editor")body=renderProjectEditor();else if(sub.create==="write")body=renderWriting();else if(sub.create==="rhymes")body=renderRhymes();else if(sub.create==="refrain")body=v25RenderRefrain();else if(sub.create==="punch")body=v3RenderPunchLab();else if(sub.create==="story")body=v3RenderStoryMap();else body=renderNotes();
  return `<div class="section-head"><h2>Créer 3.0</h2><span>Technique, sens et mémorisation</span></div>${t}${body}`;
};
function v3RenderPunchLab(){
  return `<div class="hero"><span class="eyebrow">Punchline Lab</span><h1>Prépare l’idée, puis place la chute.</h1><p>Le générateur propose une structure. La force réelle vient de ton image et de ta vérité.</p></div><div class="card"><div class="two-fields"><div class="field"><label>Limite ou obstacle</label><input id="pLimit" placeholder="le doute"></div><div class="field"><label>Objet / symbole</label><input id="pObject" placeholder="une couronne"></div></div><div class="two-fields"><div class="field"><label>Image visible</label><input id="pImage" placeholder="un miroir fissuré"></div><div class="field"><label>Renversement / vérité</label><input id="pReverse" placeholder="la preuve que j’avance"></div></div><div class="row"><button class="btn primary" onclick="v3GeneratePunches()">Générer les structures</button><button class="btn" onclick="v3ScorePunch()">Évaluer ma phrase</button></div><div class="field"><label>Ta punchline</label><textarea id="pOwn" style="min-height:100px"></textarea></div></div><div id="punchResult"></div>`;
}
function v3GeneratePunches(){
  const vals={LIMIT:$("#pLimit").value.trim()||"mes limites",OBJECT:$("#pObject").value.trim()||"les chiffres",IMAGE:$("#pImage").value.trim()||"la poussière",DEPTH:$("#pReverse").value.trim()||"le chemin",REVERSAL:$("#pReverse").value.trim()||"mon propre passage"};
  const lines=V3_PUNCH_TEMPLATES.map(t=>t.replace(/\{(\w+)\}/g,(_,k)=>vals[k]));
  $("#punchResult").innerHTML=`<div class="section-head"><h3>Structures proposées</h3><span>À réécrire avec ton vocabulaire</span></div><div class="card"><div class="list">${lines.map(x=>`<div class="list-item"><div class="list-icon">◆</div><div class="list-copy"><b>${esc(x)}</b></div><button class="btn small" onclick="$('#pOwn').value='${escAttr(x)}'">Utiliser</button></div>`).join("")}</div></div>`;
}
function v3ScorePunch(){
  const x=$("#pOwn").value.trim();if(!x)return toast("Écris une punchline");const words=(x.match(/[A-Za-zÀ-ÿœŒ'-]+/g)||[]),contrast=/mais|pourtant|alors|pendant|quand|sans|même/i.test(x),image=/miroir|feu|nuit|train|béton|ciel|couronne|route|mur|lumière|ombre/i.test(x),length=Math.max(0,100-Math.abs(words.length-12)*7),endingWord=words.at(-1)||"",endingStrength=Math.min(100,endingWord.length*12),score=Math.round(length*.3+(contrast?100:35)*.25+(image?100:40)*.25+endingStrength*.2);
  state.punchlines.unshift({id:uid(),text:x,score,date:Date.now()});state.punchlines=state.punchlines.slice(0,50);state.stats.punchlines++;addXp(8,"ecriture");save();
  $("#punchResult").innerHTML=`<div class="section-head"><h3>Diagnostic de chute</h3><span>${score}/100</span></div><div class="card"><div class="analysis-grid"><div class="analysis-cell"><b>${words.length}</b><small>Mots</small></div><div class="analysis-cell"><b>${contrast?"Oui":"Non"}</b><small>Contraste</small></div><div class="analysis-cell"><b>${image?"Oui":"Non"}</b><small>Image</small></div><div class="analysis-cell"><b>${esc(endingWord)}</b><small>Mot final</small></div></div><div class="advice">${score>=75?"Base percutante. Teste maintenant le silence juste avant le dernier mot.":"Rends l’image plus concrète, raccourcis la préparation et garde le mot le plus fort pour la fin."}</div></div>`;
}
function v3RenderStoryMap(){
  return `<div class="hero"><span class="eyebrow">Story Map</span><h1>Construis une scène qui avance.</h1><p>Lieu, désir, obstacle, décision et conséquence : une ossature simple pour éviter les couplets statiques.</p></div><div class="card">${[["storyPlace","Lieu et instant"],["storyHero","Personnage et désir"],["storyObstacle","Obstacle"],["storyDecision","Décision / point de rupture"],["storyEnd","Conséquence / image finale"]].map(x=>`<div class="field"><label>${x[1]}</label><textarea id="${x[0]}" style="min-height:75px"></textarea></div>`).join("")}<div class="two-fields"><div class="field"><label>Projet cible</label><select id="storyProject"><option value="">Aucun</option>${state.projects.map(p=>`<option value="${p.id}">${esc(p.title)}</option>`).join("")}</select></div><div class="field"><label>Point de vue</label><select id="storyPov"><option>Je</option><option>Il / elle</option><option>Tu</option><option>Objet témoin</option></select></div></div><button class="btn primary" onclick="v3SaveStoryMap()">Créer le plan</button></div><div id="storyResult"></div>`;
}
function v3SaveStoryMap(){
  const vals=[$("#storyPlace").value.trim(),$("#storyHero").value.trim(),$("#storyObstacle").value.trim(),$("#storyDecision").value.trim(),$("#storyEnd").value.trim()];if(vals.filter(Boolean).length<3)return toast("Complète au moins trois étapes");
  const labels=["OUVERTURE","DÉSIR","OBSTACLE","RUPTURE","CONSÉQUENCE"],text=vals.map((x,i)=>`[${labels[i]}]\n${x||"À développer"}`).join("\n\n"),map={id:uid(),date:Date.now(),pov:$("#storyPov").value,text,projectId:$("#storyProject").value||null};state.storyMaps.unshift(map);state.storyMaps=state.storyMaps.slice(0,30);state.stats.storyMaps++;addXp(10,"ecriture");
  if(map.projectId){const p=state.projects.find(x=>x.id===map.projectId);if(p){p.notes=(p.notes?`${p.notes}\n\n`:"")+`STORY MAP\n${text}`;p.updated=Date.now();}}
  save();$("#storyResult").innerHTML=`<div class="section-head"><h3>Plan narratif</h3><span>${esc(map.pov)}</span></div><div class="card"><div class="rhyme-preview">${esc(text)}</div></div>`;
}

/* ================= Beat Vault ================= */
renderStudio = function(){
  const t=tabs("studio",[["beats","Beat Vault"],["record","Enregistrer"],["flowcheck","Flow Scan"],["mixer","Mixeur"],["compare","Comparer"],["performance","Performance"],["takes","Prises"]]);
  let body="";if(sub.studio==="beats")body=v3RenderBeatVault();else if(sub.studio==="record")body=renderRecorder();else if(sub.studio==="flowcheck")body=v25RenderFlowScan();else if(sub.studio==="mixer")body=v25RenderMixer();else if(sub.studio==="compare")body=v25RenderCompare();else if(sub.studio==="performance")body=v25RenderPerformance();else body=renderTakesOnly();
  return `<div class="section-head"><h2>Studio Expert 3.0</h2><span>Bibliothèque persistante et production locale</span></div>${t}${body}`;
};
function v3RenderBeatVault(){
  const collections=["Toutes",...state.beatCollections];
  return `<div class="hero beat-vault-hero"><span class="eyebrow">Beat Vault</span><h1>Tes beats restent dans l’application.</h1><p>Les fichiers sont mémorisés dans IndexedDB avec leurs métadonnées. Ils restent disponibles hors connexion tant que les données de l’application ne sont pas effacées.</p><div class="row"><button class="btn primary" onclick="$('#beatFilePicker').click()">+ Ajouter des beats</button><button class="btn" onclick="v3RequestPersistentStorage()">Verrouiller le stockage</button><button class="btn" onclick="v3StorageReport()">Espace utilisé</button></div></div>
  <div class="section-head"><h3>Recherche et classement</h3><span id="beatCountLabel">Chargement…</span></div>
  <div class="card"><div class="two-fields"><div class="field"><label>Recherche</label><input id="beatSearch" placeholder="Nom, tag, humeur..." value="${escAttr(V3_beatFilter.query)}" oninput="V3_beatFilter.query=this.value;loadBeatLibrary()"></div><div class="field"><label>Collection</label><select id="beatCollectionFilter" onchange="V3_beatFilter.collection=this.value;loadBeatLibrary()">${collections.map(x=>`<option ${V3_beatFilter.collection===x?"selected":""}>${esc(x)}</option>`).join("")}</select></div></div><div class="row"><label class="pill"><input type="checkbox" style="width:auto" ${V3_beatFilter.favorite?"checked":""} onchange="V3_beatFilter.favorite=this.checked;loadBeatLibrary()"> Favoris uniquement</label><button class="btn small" onclick="v3NewCollection()">+ Collection</button></div></div>
  <div id="selectedBeat"></div><div class="section-head"><h3>Bibliothèque</h3><span>Import multiple accepté</span></div><div id="beatLibrary" class="card"><div class="empty">Chargement…</div></div>`;
}

/* Override original importer: supports multiple files and stores blobs in IndexedDB. */
importBeat = async function(event){
  const files=[...event.target.files];if(!files.length)return;let ok=0;
  for(const file of files){
    if(!file.type.startsWith("audio/")&& !/\.(mp3|wav|m4a|aac|ogg|webm|flac)$/i.test(file.name)){toast(`Format ignoré : ${file.name}`);continue;}
    if(file.size>180*1024*1024){toast(`Trop lourd : ${file.name}`);continue;}
    try{
      const beat={name:file.name.replace(/\.[^.]+$/,"")||"Beat",blob:file,type:file.type||"audio/*",bpm:90,key:"",style:"Non classé",mood:"",tags:"",favorite:false,collection:"Entraînement",date:Date.now(),updated:Date.now(),size:file.size,duration:0,lastPosition:0,playCount:0,peaks:[],analyzed:false};
      beat.id=await dbAdd("beats",beat);ok++;state.stats.beatsImported++;
    }catch(e){toast(`Mémoire insuffisante pour ${file.name}`);}
  }
  state.stats.sessions++;save();event.target.value="";toast(`${ok} beat${ok>1?"s":""} mémorisé${ok>1?"s":""}`);if(route==="studio"&&sub.studio==="beats")loadBeatLibrary();
};

async function v3NormalizeBeat(b){
  let changed=false;const defaults={bpm:90,key:"",style:"Non classé",mood:"",tags:"",favorite:false,collection:"Entraînement",updated:b.date||Date.now(),size:b.blob?.size||0,duration:0,lastPosition:0,playCount:0,peaks:[],analyzed:false};for(const [k,v] of Object.entries(defaults))if(b[k]===undefined){b[k]=v;changed=true;}if(changed)await dbPut("beats",b);return b;
}
loadBeatLibrary = async function(){
  const box=$("#beatLibrary");if(!box)return;let beats=[];try{beats=await dbAll("beats");for(const b of beats)await v3NormalizeBeat(b);}catch(e){box.innerHTML='<div class="empty">Bibliothèque inaccessible.</div>';return;}
  beats.sort((a,b)=>(b.favorite-a.favorite)||(b.updated-a.updated));const q=norm(V3_beatFilter.query);beats=beats.filter(b=>(!q||norm(`${b.name} ${b.tags} ${b.mood} ${b.style}`).includes(q))&&(!V3_beatFilter.favorite||b.favorite)&&(V3_beatFilter.collection==="Toutes"||b.collection===V3_beatFilter.collection));
  if($("#beatCountLabel"))$("#beatCountLabel").textContent=`${beats.length} beat${beats.length>1?"s":""}`;
  box.innerHTML=beats.length?beats.map(v3BeatCard).join(""):'<div class="empty">Aucun beat dans ce filtre. Utilise « Ajouter des beats ».</div>';
};
function v3BeatCard(b){
  const tags=(b.tags||"").split(",").map(x=>x.trim()).filter(Boolean).slice(0,3);
  return `<div class="beat-card"><button class="beat-fav ${b.favorite?"on":""}" onclick="v3ToggleBeatFavorite(${b.id})">★</button><div class="beat-cover">♫</div><div class="beat-main"><b>${esc(b.name)}</b><p class="small">${b.bpm||90} BPM · ${esc(b.key||"Tonalité —")} · ${esc(b.style||"Non classé")}</p><div class="word-cloud">${tags.map(x=>`<span class="mini-tag">${esc(x)}</span>`).join("")}<span class="mini-tag">${esc(b.collection||"Entraînement")}</span></div></div><div class="beat-actions"><button class="btn small primary" onclick="selectBeat(${b.id})">Ouvrir</button><button class="btn small" onclick="v3EditBeat(${b.id})">Modifier</button><button class="btn small red" onclick="removeBeat(${b.id})">Suppr.</button></div></div>`;
}
selectBeat = async function(id,scroll=true){
  const beats=await dbAll("beats"),b=beats.find(x=>x.id===id);if(!b)return;await v3NormalizeBeat(b);selectedBeatId=id;if(V3_beatUrls.has(id))URL.revokeObjectURL(V3_beatUrls.get(id));const url=URL.createObjectURL(b.blob);V3_beatUrls.set(id,url);selectedBeatUrl=url;b.playCount=(b.playCount||0)+1;b.updated=Date.now();await dbPut("beats",b);
  const z=$("#selectedBeat");if(!z)return;z.innerHTML=`<div class="section-head"><h3>Beat actif</h3><span>${esc(b.name)}</span></div><div class="card beat-player"><audio id="beatAudio" controls src="${url}" onloadedmetadata="v3BeatLoaded(${b.id})" ontimeupdate="v3BeatTime(${b.id})" onpause="v3RememberBeatPosition(${b.id})" onended="v3BeatEnded(${b.id})"></audio><canvas id="beatWaveCanvas" width="900" height="130"></canvas><div class="beat-meta-grid"><div><b>${b.bpm||90}</b><small>BPM</small></div><div><b>${esc(b.key||"—")}</b><small>Tonalité</small></div><div><b>${esc(b.style||"—")}</b><small>Style</small></div><div><b>${formatClock(b.duration||0)}</b><small>Durée</small></div></div><div class="two-fields"><div class="field"><label>Vitesse d’entraînement</label><input id="beatRate" type="range" min="0.65" max="1.25" step="0.05" value="1" oninput="$('#beatAudio').playbackRate=+this.value;$('#rateLabel').textContent=Math.round(this.value*100)+'%'"><span id="rateLabel" class="small">100%</span></div><div class="field"><label>Boucle</label><select id="loopBars"><option value="2">2 mesures</option><option value="4">4 mesures</option><option value="8" selected>8 mesures</option><option value="16">16 mesures</option></select></div></div><div class="row"><button class="btn purple" onclick="setLoop()">Boucler depuis ici</button><button class="btn" onclick="clearLoop()">Retirer boucle</button><button class="btn" onclick="v3AnalyzeBeat(${b.id})">Analyser BPM</button><button class="btn" onclick="v3AssignBeatProject(${b.id})">Associer à un projet</button><button class="btn green" onclick="v3ExportBeat(${b.id})">Exporter</button></div><p id="loopInfo" class="small muted" style="margin-top:10px">Reprise mémorisée à ${formatClock(b.lastPosition||0)}</p></div>`;
  setTimeout(()=>v3DrawBeatWave(b),20);if(scroll)z.scrollIntoView({behavior:"smooth",block:"start"});
};
async function v3BeatLoaded(id){const a=$("#beatAudio"),beats=await dbAll("beats"),b=beats.find(x=>x.id===id);if(!a||!b)return;if(b.lastPosition>0&&b.lastPosition<a.duration-2)a.currentTime=b.lastPosition;if(!b.duration||Math.abs(b.duration-a.duration)>1){b.duration=a.duration;b.updated=Date.now();await dbPut("beats",b);}v3DrawBeatWave(b);}
function v3BeatTime(id){const a=$("#beatAudio");if(!a)return;beatTimeUpdate();if(Date.now()-V3_lastBeatSave>6000){V3_lastBeatSave=Date.now();v3RememberBeatPosition(id);}}
async function v3RememberBeatPosition(id){const a=$("#beatAudio");if(!a)return;const all=await dbAll("beats"),b=all.find(x=>x.id===id);if(b){b.lastPosition=a.currentTime||0;b.updated=Date.now();await dbPut("beats",b);}}
async function v3BeatEnded(id){const all=await dbAll("beats"),b=all.find(x=>x.id===id);if(b){b.lastPosition=0;await dbPut("beats",b);}}
function v3DrawBeatWave(b){const c=$("#beatWaveCanvas");if(!c)return;const x=c.getContext("2d"),w=c.width,h=c.height;x.clearRect(0,0,w,h);x.strokeStyle="rgba(255,255,255,.12)";x.beginPath();x.moveTo(0,h/2);x.lineTo(w,h/2);x.stroke();const peaks=b.peaks?.length?b.peaks:Array.from({length:100},(_,i)=>.08+Math.abs(Math.sin(i*.31))*.12);const g=x.createLinearGradient(0,0,w,0);g.addColorStop(0,"#ff3b6b");g.addColorStop(1,"#8f5cff");x.fillStyle=g;const bw=w/peaks.length;peaks.forEach((p,i)=>{const bh=Math.max(2,p*h*.9);x.fillRect(i*bw,(h-bh)/2,Math.max(1,bw-1),bh)});}
async function v3AnalyzeBeat(id){
  const z=$("#loopInfo");if(z)z.textContent="Analyse du beat en cours…";try{const all=await dbAll("beats"),b=all.find(x=>x.id===id),ctx=new (window.AudioContext||window.webkitAudioContext)(),buf=await ctx.decodeAudioData((await b.blob.arrayBuffer()).slice(0)),data=buf.getChannelData(0),sr=buf.sampleRate,maxSamples=Math.min(data.length,sr*120),hop=1024,env=[];for(let i=0;i<maxSamples;i+=hop){let sum=0;for(let j=i;j<Math.min(maxSamples,i+hop);j++)sum+=Math.abs(data[j]);env.push(sum/hop);}const mean=env.reduce((a,v)=>a+v,0)/env.length,onsets=[];for(let i=1;i<env.length;i++)if(env[i]>mean*1.65&&env[i]>env[i-1]*1.25)onsets.push(i*hop/sr);let best={bpm:90,score:-1};for(let bpm=60;bpm<=180;bpm++){const beat=60/bpm;let score=0;for(let i=1;i<onsets.length;i++){const d=onsets[i]-onsets[i-1],r=d/beat;score+=Math.max(0,1-Math.abs(r-Math.round(r))*.8);}if(score>best.score)best={bpm,score};}const count=140,chunk=Math.max(1,Math.floor(maxSamples/count)),peaks=[];for(let i=0;i<count;i++){let peak=0;for(let j=i*chunk;j<Math.min(maxSamples,(i+1)*chunk);j++)peak=Math.max(peak,Math.abs(data[j]));peaks.push(peak);}b.bpm=best.bpm;b.duration=buf.duration;b.peaks=peaks;b.analyzed=true;b.updated=Date.now();await dbPut("beats",b);await ctx.close();state.stats.beatAnalyses++;addXp(8,"rythme");save();toast(`BPM estimé : ${best.bpm}`);selectBeat(id,false);loadBeatLibrary();}catch(e){toast("Analyse impossible pour ce format audio");if(z)z.textContent="Analyse non disponible.";}
}
function v3EditBeat(id){dbAll("beats").then(all=>{const b=all.find(x=>x.id===id);if(!b)return;openModal(`${modalHead("Modifier le beat")}<div class="field"><label>Nom</label><input id="editBeatName" value="${escAttr(b.name)}"></div><div class="two-fields"><div class="field"><label>BPM</label><input id="editBeatBpm" type="number" value="${b.bpm||90}"></div><div class="field"><label>Tonalité</label><input id="editBeatKey" value="${escAttr(b.key||"")}" placeholder="Ex. F#m"></div></div><div class="two-fields"><div class="field"><label>Style</label><select id="editBeatStyle">${["Non classé","Boom bap","Trap","Drill","Mélodique","Afro","Cloud","Old school","Jersey","Expérimental"].map(x=>`<option ${b.style===x?"selected":""}>${x}</option>`).join("")}</select></div><div class="field"><label>Humeur</label><input id="editBeatMood" value="${escAttr(b.mood||"")}" placeholder="Sombre, énergique..."></div></div><div class="two-fields"><div class="field"><label>Collection</label><select id="editBeatCollection">${state.beatCollections.map(x=>`<option ${b.collection===x?"selected":""}>${esc(x)}</option>`).join("")}</select></div><div class="field"><label>Tags séparés par virgules</label><input id="editBeatTags" value="${escAttr(b.tags||"")}"></div></div><button class="btn primary" onclick="v3SaveBeatMeta(${id})">Enregistrer</button>`);});}
async function v3SaveBeatMeta(id){const all=await dbAll("beats"),b=all.find(x=>x.id===id);if(!b)return;Object.assign(b,{name:$("#editBeatName").value.trim()||"Beat",bpm:+$("#editBeatBpm").value||90,key:$("#editBeatKey").value.trim(),style:$("#editBeatStyle").value,mood:$("#editBeatMood").value.trim(),collection:$("#editBeatCollection").value,tags:$("#editBeatTags").value.trim(),updated:Date.now()});await dbPut("beats",b);closeModal();loadBeatLibrary();if(selectedBeatId===id)selectBeat(id,false);toast("Beat mis à jour");}
async function v3ToggleBeatFavorite(id){const all=await dbAll("beats"),b=all.find(x=>x.id===id);if(b){b.favorite=!b.favorite;b.updated=Date.now();await dbPut("beats",b);loadBeatLibrary();}}
function v3NewCollection(){const n=prompt("Nom de la collection :");if(!n)return;if(!state.beatCollections.includes(n.trim()))state.beatCollections.push(n.trim());save(true);}
async function v3AssignBeatProject(id){if(!state.projects.length)return toast("Crée d’abord un projet");openModal(`${modalHead("Associer le beat")}<div class="field"><label>Projet</label><select id="assignBeatProject">${state.projects.map(p=>`<option value="${p.id}">${esc(p.title)}</option>`).join("")}</select></div><button class="btn primary" onclick="v3ConfirmAssignBeat(${id})">Associer</button>`);}
async function v3ConfirmAssignBeat(id){const pid=$("#assignBeatProject").value,p=state.projects.find(x=>x.id===pid),all=await dbAll("beats"),b=all.find(x=>x.id===id);if(p&&b){p.beatId=id;p.bpm=b.bpm;p.notes=(p.notes?`${p.notes}\n`:"")+`Beat : ${b.name} · ${b.bpm} BPM · ${b.key||"tonalité non définie"}`;p.updated=Date.now();state.currentProjectId=p.id;save();closeModal();toast("Beat associé au projet");}}
async function v3ExportBeat(id){const all=await dbAll("beats"),b=all.find(x=>x.id===id);if(!b)return;const ext=(b.blob.type.split("/")[1]||"audio").replace("mpeg","mp3").replace("x-m4a","m4a"),file=new File([b.blob],`${safeName(b.name)}.${ext}`,{type:b.blob.type});if(navigator.canShare?.({files:[file]}))navigator.share({title:b.name,files:[file]}).catch(()=>downloadBlob(b.blob,file.name));else downloadBlob(b.blob,file.name);}
async function v3RequestPersistentStorage(){try{if(!navigator.storage?.persist)return toast("Stockage durable géré automatiquement par Android");const ok=await navigator.storage.persist();toast(ok?"Stockage durable activé":"Android décidera de la conservation selon l’espace disponible");}catch(e){toast("Stockage durable non disponible");}}
async function v3StorageReport(){try{const e=await navigator.storage.estimate(),used=e.usage||0,quota=e.quota||0,mb=n=>`${(n/1024/1024).toFixed(1)} Mo`;toast(`${mb(used)} utilisés sur ${mb(quota)} disponibles`);}catch(e){toast("Estimation du stockage indisponible");}}

/* Keep old removal but cleanup selected view. */
const V3_oldRemoveBeat=removeBeat;
removeBeat=async function(id){await V3_oldRemoveBeat(id);if(selectedBeatId===id){selectedBeatId=null;if($("#selectedBeat"))$("#selectedBeat").innerHTML="";}loadBeatLibrary();};

/* ================= Profile V3 ================= */
renderProfile = function(){
  v3UpdateRank();return V3_oldRenderProfile()+`<div class="section-head"><h3>Maîtrise experte</h3><span>${state.expert.rank}</span></div><div class="card"><div class="row between"><div><div class="metric">${state.expert.score}%</div><p>Progression Expert Academy</p></div><div class="expert-medal large">★</div></div><div class="progress green"><i style="width:${state.expert.score}%"></i></div></div><div class="section-head"><h3>Activité V3</h3><span>Entraînement avancé</span></div><div class="grid3">${[["Expert",state.stats.expertSessions],["Oreille",state.stats.earDrills],["Patterns",state.stats.patterns],["Beats",state.stats.beatsImported],["BPM analysés",state.stats.beatAnalyses],["Punchlines",state.stats.punchlines]].map(x=>`<div class="card"><span class="metric-label">${x[0]}</span><div class="metric">${x[1]}</div></div>`).join("")}</div><div class="section-head"><h3>Mémoire média</h3><span>Beats et prises hors ligne</span></div><div class="card"><p>Les beats sont enregistrés dans la mémoire privée de l’application. Ils ne sont pas inclus dans la sauvegarde JSON pour éviter des fichiers énormes.</p><div class="row" style="margin-top:12px"><button class="btn" onclick="v3StorageReport()">Voir l’espace utilisé</button><button class="btn" onclick="v3RequestPersistentStorage()">Demander la conservation durable</button></div></div>`;
};

afterRender = function(){
  V3_oldAfterRender();
  if(route==="studio"&&sub.studio==="beats")setTimeout(loadBeatLibrary,20);
};

/* Upgrade input for multiple beat imports. */
const beatPicker=$("#beatFilePicker");if(beatPicker)beatPicker.multiple=true;

v3Ensure(state);v3UpdateRank();save();renderRoute();
